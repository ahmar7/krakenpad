import Logo from "../assets/img/logo.png";
import One from "../assets/img/1.png";
import Two from "../assets/img/2.png";
import Three from "../assets/img/3.png";
import Four from "../assets/img/4.png";
import Five from "../assets/img/5.png";
import Six from "../assets/img/6.png";
import Banner from "../assets/img/banner.png";
import Ico from "../assets/img/ico.png";
import Dp from "../assets/img/dp.png";

export { Logo, One, Two, Three, Four, Five, Six, Banner, Ico, Dp };
