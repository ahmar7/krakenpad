(this.webpackJsonpuniverseworldcup =
  this.webpackJsonpuniverseworldcup || []).push([
  [0],
  {
    33: function (e, n, t) {
      "use strict";
      t.d(n, "q", function () {
        return o;
      }),
        t.d(n, "r", function () {
          return p;
        }),
        t.d(n, "i", function () {
          return u;
        }),
        t.d(n, "e", function () {
          return l;
        }),
        t.d(n, "f", function () {
          return c;
        }),
        t.d(n, "j", function () {
          return d;
        }),
        t.d(n, "k", function () {
          return y;
        }),
        t.d(n, "g", function () {
          return m;
        }),
        t.d(n, "h", function () {
          return b;
        }),
        t.d(n, "l", function () {
          return f;
        }),
        t.d(n, "b", function () {
          return T;
        }),
        t.d(n, "c", function () {
          return x;
        }),
        t.d(n, "a", function () {
          return h;
        }),
        t.d(n, "m", function () {
          return j;
        }),
        t.d(n, "n", function () {
          return g;
        }),
        t.d(n, "o", function () {
          return O;
        }),
        t.d(n, "d", function () {
          return _;
        }),
        t.d(n, "p", function () {
          return A;
        });
      var a,
        i = t(11),
        s = t(10);
      !(function (e) {
        (e[(e.MAINNET = 56)] = "MAINNET"), (e[(e.TESTNET = 97)] = "TESTNET");
      })(a || (a = {}));
      var r = Object(i.a)(function e(n, t, a, i, r, o) {
          Object(s.a)(this, e),
            (this.chainId = void 0),
            (this.address = void 0),
            (this.decimals = void 0),
            (this.name = void 0),
            (this.symbol = void 0),
            (this.projectLink = void 0),
            (this.chainId = n),
            (this.address = t),
            (this.decimals = a),
            (this.symbol = i),
            (this.name = r),
            (this.projectLink = o);
        }),
        o = "0xffc4c02C6BB187cE473Fb00458EF6CF80503D189",
        p = "",
        u = Object({
          NODE_ENV: "production",
          PUBLIC_URL: "",
          WDS_SOCKET_HOST: void 0,
          WDS_SOCKET_PATH: void 0,
          WDS_SOCKET_PORT: void 0,
          FAST_REFRESH: !0,
          REACT_APP_ENV: "production",
          REACT_APP_DOMAIN: "https://universeworldcup.com",
          REACT_APP_DOMAIN_NETWORK: "https://bscscan.com",
          REACT_APP_DOMAIN_SWAP: "",
          REACT_APP_API: "",
          REACT_APP_API_CONFIG: "",
          REACT_APP_BINANCE_API: "https://api.binance.com",
          REACT_APP_API_TIMEOUT: "20000",
          REACT_APP_TOKEN: "0xffc4c02C6BB187cE473Fb00458EF6CF80503D189",
          REACT_APP_TOKEN_NFT: "",
          REACT_APP_CONTRACT_STAKING:
            "0x457bDD9cD161538EdB0B6d83127c328bA8713E6C",
          REACT_APP_PANCAKE_ROUTE: "0x10ed43c718714eb63d5aa57b78b54704e256024e",
          REACT_APP_PANCAKE_FACTORY:
            "0xca143ce32fe78f1f7019d7d551a6402fc5350c73",
          REACT_APP_BNB_BUSD_PAIR: "0x58f876857a02d6762e0101bb5c46a8c1ed44dc16",
          REACT_APP_TOKEN_BNB: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
          REACT_APP_TOKEN_USDT: "0x55d398326f99059fF775485246999027B3197955",
          REACT_APP_TOKEN_BUSD: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56",
          REACT_APP_CHAIN_ID: "56",
          REACT_APP_NETWORK_URL: "https://bsc-dataseed.binance.org/",
          REACT_APP_GITHUB_PRIVATE_KEY: "",
          REACT_APP_ORGANIZATION: "",
          REACT_APP_REPOS: "",
          REACT_APP_ROOT_FOLDER: "root",
          REACT_APP_BOT_TOKEN: "",
          REACT_APP_BOT_ID: "",
          REACT_APP_FIREBASE_API_KEY: "",
          REACT_APP_FIREBASE_AUTH_DOMAIN: "",
          REACT_APP_FIREBASE_DATABASE_URL: "",
          REACT_APP_FIREBASE_STORAGE_BUCKET: "",
          REACT_APP_FIREBASE_MESSAGING_SENDER_ID: "",
          REACT_APP_FIREBASE_APP_ID: "",
          REACT_APP_FIREBASE_MEASUREMENT_ID: "",
        }).REACT_APP_CONTRACT_MARKETPLACE,
        l = Object({
          NODE_ENV: "production",
          PUBLIC_URL: "",
          WDS_SOCKET_HOST: void 0,
          WDS_SOCKET_PATH: void 0,
          WDS_SOCKET_PORT: void 0,
          FAST_REFRESH: !0,
          REACT_APP_ENV: "production",
          REACT_APP_DOMAIN: "https://universeworldcup.com",
          REACT_APP_DOMAIN_NETWORK: "https://bscscan.com",
          REACT_APP_DOMAIN_SWAP: "",
          REACT_APP_API: "",
          REACT_APP_API_CONFIG: "",
          REACT_APP_BINANCE_API: "https://api.binance.com",
          REACT_APP_API_TIMEOUT: "20000",
          REACT_APP_TOKEN: "0xffc4c02C6BB187cE473Fb00458EF6CF80503D189",
          REACT_APP_TOKEN_NFT: "",
          REACT_APP_CONTRACT_STAKING:
            "0x457bDD9cD161538EdB0B6d83127c328bA8713E6C",
          REACT_APP_PANCAKE_ROUTE: "0x10ed43c718714eb63d5aa57b78b54704e256024e",
          REACT_APP_PANCAKE_FACTORY:
            "0xca143ce32fe78f1f7019d7d551a6402fc5350c73",
          REACT_APP_BNB_BUSD_PAIR: "0x58f876857a02d6762e0101bb5c46a8c1ed44dc16",
          REACT_APP_TOKEN_BNB: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
          REACT_APP_TOKEN_USDT: "0x55d398326f99059fF775485246999027B3197955",
          REACT_APP_TOKEN_BUSD: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56",
          REACT_APP_CHAIN_ID: "56",
          REACT_APP_NETWORK_URL: "https://bsc-dataseed.binance.org/",
          REACT_APP_GITHUB_PRIVATE_KEY: "",
          REACT_APP_ORGANIZATION: "",
          REACT_APP_REPOS: "",
          REACT_APP_ROOT_FOLDER: "root",
          REACT_APP_BOT_TOKEN: "",
          REACT_APP_BOT_ID: "",
          REACT_APP_FIREBASE_API_KEY: "",
          REACT_APP_FIREBASE_AUTH_DOMAIN: "",
          REACT_APP_FIREBASE_DATABASE_URL: "",
          REACT_APP_FIREBASE_STORAGE_BUCKET: "",
          REACT_APP_FIREBASE_MESSAGING_SENDER_ID: "",
          REACT_APP_FIREBASE_APP_ID: "",
          REACT_APP_FIREBASE_MEASUREMENT_ID: "",
        }).REACT_APP_CONTRACT_AUCTION,
        c = Object({
          NODE_ENV: "production",
          PUBLIC_URL: "",
          WDS_SOCKET_HOST: void 0,
          WDS_SOCKET_PATH: void 0,
          WDS_SOCKET_PORT: void 0,
          FAST_REFRESH: !0,
          REACT_APP_ENV: "production",
          REACT_APP_DOMAIN: "https://universeworldcup.com",
          REACT_APP_DOMAIN_NETWORK: "https://bscscan.com",
          REACT_APP_DOMAIN_SWAP: "",
          REACT_APP_API: "",
          REACT_APP_API_CONFIG: "",
          REACT_APP_BINANCE_API: "https://api.binance.com",
          REACT_APP_API_TIMEOUT: "20000",
          REACT_APP_TOKEN: "0xffc4c02C6BB187cE473Fb00458EF6CF80503D189",
          REACT_APP_TOKEN_NFT: "",
          REACT_APP_CONTRACT_STAKING:
            "0x457bDD9cD161538EdB0B6d83127c328bA8713E6C",
          REACT_APP_PANCAKE_ROUTE: "0x10ed43c718714eb63d5aa57b78b54704e256024e",
          REACT_APP_PANCAKE_FACTORY:
            "0xca143ce32fe78f1f7019d7d551a6402fc5350c73",
          REACT_APP_BNB_BUSD_PAIR: "0x58f876857a02d6762e0101bb5c46a8c1ed44dc16",
          REACT_APP_TOKEN_BNB: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
          REACT_APP_TOKEN_USDT: "0x55d398326f99059fF775485246999027B3197955",
          REACT_APP_TOKEN_BUSD: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56",
          REACT_APP_CHAIN_ID: "56",
          REACT_APP_NETWORK_URL: "https://bsc-dataseed.binance.org/",
          REACT_APP_GITHUB_PRIVATE_KEY: "",
          REACT_APP_ORGANIZATION: "",
          REACT_APP_REPOS: "",
          REACT_APP_ROOT_FOLDER: "root",
          REACT_APP_BOT_TOKEN: "",
          REACT_APP_BOT_ID: "",
          REACT_APP_FIREBASE_API_KEY: "",
          REACT_APP_FIREBASE_AUTH_DOMAIN: "",
          REACT_APP_FIREBASE_DATABASE_URL: "",
          REACT_APP_FIREBASE_STORAGE_BUCKET: "",
          REACT_APP_FIREBASE_MESSAGING_SENDER_ID: "",
          REACT_APP_FIREBASE_APP_ID: "",
          REACT_APP_FIREBASE_MEASUREMENT_ID: "",
        }).REACT_APP_CONTRACT_CLAIM_BOX,
        d = Object({
          NODE_ENV: "production",
          PUBLIC_URL: "",
          WDS_SOCKET_HOST: void 0,
          WDS_SOCKET_PATH: void 0,
          WDS_SOCKET_PORT: void 0,
          FAST_REFRESH: !0,
          REACT_APP_ENV: "production",
          REACT_APP_DOMAIN: "https://universeworldcup.com",
          REACT_APP_DOMAIN_NETWORK: "https://bscscan.com",
          REACT_APP_DOMAIN_SWAP: "",
          REACT_APP_API: "",
          REACT_APP_API_CONFIG: "",
          REACT_APP_BINANCE_API: "https://api.binance.com",
          REACT_APP_API_TIMEOUT: "20000",
          REACT_APP_TOKEN: "0xffc4c02C6BB187cE473Fb00458EF6CF80503D189",
          REACT_APP_TOKEN_NFT: "",
          REACT_APP_CONTRACT_STAKING:
            "0x457bDD9cD161538EdB0B6d83127c328bA8713E6C",
          REACT_APP_PANCAKE_ROUTE: "0x10ed43c718714eb63d5aa57b78b54704e256024e",
          REACT_APP_PANCAKE_FACTORY:
            "0xca143ce32fe78f1f7019d7d551a6402fc5350c73",
          REACT_APP_BNB_BUSD_PAIR: "0x58f876857a02d6762e0101bb5c46a8c1ed44dc16",
          REACT_APP_TOKEN_BNB: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
          REACT_APP_TOKEN_USDT: "0x55d398326f99059fF775485246999027B3197955",
          REACT_APP_TOKEN_BUSD: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56",
          REACT_APP_CHAIN_ID: "56",
          REACT_APP_NETWORK_URL: "https://bsc-dataseed.binance.org/",
          REACT_APP_GITHUB_PRIVATE_KEY: "",
          REACT_APP_ORGANIZATION: "",
          REACT_APP_REPOS: "",
          REACT_APP_ROOT_FOLDER: "root",
          REACT_APP_BOT_TOKEN: "",
          REACT_APP_BOT_ID: "",
          REACT_APP_FIREBASE_API_KEY: "",
          REACT_APP_FIREBASE_AUTH_DOMAIN: "",
          REACT_APP_FIREBASE_DATABASE_URL: "",
          REACT_APP_FIREBASE_STORAGE_BUCKET: "",
          REACT_APP_FIREBASE_MESSAGING_SENDER_ID: "",
          REACT_APP_FIREBASE_APP_ID: "",
          REACT_APP_FIREBASE_MEASUREMENT_ID: "",
        }).REACT_APP_CONTRACT_SHOP,
        y = "0x457bDD9cD161538EdB0B6d83127c328bA8713E6C",
        m = Object({
          NODE_ENV: "production",
          PUBLIC_URL: "",
          WDS_SOCKET_HOST: void 0,
          WDS_SOCKET_PATH: void 0,
          WDS_SOCKET_PORT: void 0,
          FAST_REFRESH: !0,
          REACT_APP_ENV: "production",
          REACT_APP_DOMAIN: "https://universeworldcup.com",
          REACT_APP_DOMAIN_NETWORK: "https://bscscan.com",
          REACT_APP_DOMAIN_SWAP: "",
          REACT_APP_API: "",
          REACT_APP_API_CONFIG: "",
          REACT_APP_BINANCE_API: "https://api.binance.com",
          REACT_APP_API_TIMEOUT: "20000",
          REACT_APP_TOKEN: "0xffc4c02C6BB187cE473Fb00458EF6CF80503D189",
          REACT_APP_TOKEN_NFT: "",
          REACT_APP_CONTRACT_STAKING:
            "0x457bDD9cD161538EdB0B6d83127c328bA8713E6C",
          REACT_APP_PANCAKE_ROUTE: "0x10ed43c718714eb63d5aa57b78b54704e256024e",
          REACT_APP_PANCAKE_FACTORY:
            "0xca143ce32fe78f1f7019d7d551a6402fc5350c73",
          REACT_APP_BNB_BUSD_PAIR: "0x58f876857a02d6762e0101bb5c46a8c1ed44dc16",
          REACT_APP_TOKEN_BNB: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
          REACT_APP_TOKEN_USDT: "0x55d398326f99059fF775485246999027B3197955",
          REACT_APP_TOKEN_BUSD: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56",
          REACT_APP_CHAIN_ID: "56",
          REACT_APP_NETWORK_URL: "https://bsc-dataseed.binance.org/",
          REACT_APP_GITHUB_PRIVATE_KEY: "",
          REACT_APP_ORGANIZATION: "",
          REACT_APP_REPOS: "",
          REACT_APP_ROOT_FOLDER: "root",
          REACT_APP_BOT_TOKEN: "",
          REACT_APP_BOT_ID: "",
          REACT_APP_FIREBASE_API_KEY: "",
          REACT_APP_FIREBASE_AUTH_DOMAIN: "",
          REACT_APP_FIREBASE_DATABASE_URL: "",
          REACT_APP_FIREBASE_STORAGE_BUCKET: "",
          REACT_APP_FIREBASE_MESSAGING_SENDER_ID: "",
          REACT_APP_FIREBASE_APP_ID: "",
          REACT_APP_FIREBASE_MEASUREMENT_ID: "",
        }).REACT_APP_CONTRACT_INO,
        b = Object({
          NODE_ENV: "production",
          PUBLIC_URL: "",
          WDS_SOCKET_HOST: void 0,
          WDS_SOCKET_PATH: void 0,
          WDS_SOCKET_PORT: void 0,
          FAST_REFRESH: !0,
          REACT_APP_ENV: "production",
          REACT_APP_DOMAIN: "https://universeworldcup.com",
          REACT_APP_DOMAIN_NETWORK: "https://bscscan.com",
          REACT_APP_DOMAIN_SWAP: "",
          REACT_APP_API: "",
          REACT_APP_API_CONFIG: "",
          REACT_APP_BINANCE_API: "https://api.binance.com",
          REACT_APP_API_TIMEOUT: "20000",
          REACT_APP_TOKEN: "0xffc4c02C6BB187cE473Fb00458EF6CF80503D189",
          REACT_APP_TOKEN_NFT: "",
          REACT_APP_CONTRACT_STAKING:
            "0x457bDD9cD161538EdB0B6d83127c328bA8713E6C",
          REACT_APP_PANCAKE_ROUTE: "0x10ed43c718714eb63d5aa57b78b54704e256024e",
          REACT_APP_PANCAKE_FACTORY:
            "0xca143ce32fe78f1f7019d7d551a6402fc5350c73",
          REACT_APP_BNB_BUSD_PAIR: "0x58f876857a02d6762e0101bb5c46a8c1ed44dc16",
          REACT_APP_TOKEN_BNB: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
          REACT_APP_TOKEN_USDT: "0x55d398326f99059fF775485246999027B3197955",
          REACT_APP_TOKEN_BUSD: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56",
          REACT_APP_CHAIN_ID: "56",
          REACT_APP_NETWORK_URL: "https://bsc-dataseed.binance.org/",
          REACT_APP_GITHUB_PRIVATE_KEY: "",
          REACT_APP_ORGANIZATION: "",
          REACT_APP_REPOS: "",
          REACT_APP_ROOT_FOLDER: "root",
          REACT_APP_BOT_TOKEN: "",
          REACT_APP_BOT_ID: "",
          REACT_APP_FIREBASE_API_KEY: "",
          REACT_APP_FIREBASE_AUTH_DOMAIN: "",
          REACT_APP_FIREBASE_DATABASE_URL: "",
          REACT_APP_FIREBASE_STORAGE_BUCKET: "",
          REACT_APP_FIREBASE_MESSAGING_SENDER_ID: "",
          REACT_APP_FIREBASE_APP_ID: "",
          REACT_APP_FIREBASE_MEASUREMENT_ID: "",
        }).REACT_APP_CONTRACT_KILL_BOSS,
        f = Object({
          NODE_ENV: "production",
          PUBLIC_URL: "",
          WDS_SOCKET_HOST: void 0,
          WDS_SOCKET_PATH: void 0,
          WDS_SOCKET_PORT: void 0,
          FAST_REFRESH: !0,
          REACT_APP_ENV: "production",
          REACT_APP_DOMAIN: "https://universeworldcup.com",
          REACT_APP_DOMAIN_NETWORK: "https://bscscan.com",
          REACT_APP_DOMAIN_SWAP: "",
          REACT_APP_API: "",
          REACT_APP_API_CONFIG: "",
          REACT_APP_BINANCE_API: "https://api.binance.com",
          REACT_APP_API_TIMEOUT: "20000",
          REACT_APP_TOKEN: "0xffc4c02C6BB187cE473Fb00458EF6CF80503D189",
          REACT_APP_TOKEN_NFT: "",
          REACT_APP_CONTRACT_STAKING:
            "0x457bDD9cD161538EdB0B6d83127c328bA8713E6C",
          REACT_APP_PANCAKE_ROUTE: "0x10ed43c718714eb63d5aa57b78b54704e256024e",
          REACT_APP_PANCAKE_FACTORY:
            "0xca143ce32fe78f1f7019d7d551a6402fc5350c73",
          REACT_APP_BNB_BUSD_PAIR: "0x58f876857a02d6762e0101bb5c46a8c1ed44dc16",
          REACT_APP_TOKEN_BNB: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
          REACT_APP_TOKEN_USDT: "0x55d398326f99059fF775485246999027B3197955",
          REACT_APP_TOKEN_BUSD: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56",
          REACT_APP_CHAIN_ID: "56",
          REACT_APP_NETWORK_URL: "https://bsc-dataseed.binance.org/",
          REACT_APP_GITHUB_PRIVATE_KEY: "",
          REACT_APP_ORGANIZATION: "",
          REACT_APP_REPOS: "",
          REACT_APP_ROOT_FOLDER: "root",
          REACT_APP_BOT_TOKEN: "",
          REACT_APP_BOT_ID: "",
          REACT_APP_FIREBASE_API_KEY: "",
          REACT_APP_FIREBASE_AUTH_DOMAIN: "",
          REACT_APP_FIREBASE_DATABASE_URL: "",
          REACT_APP_FIREBASE_STORAGE_BUCKET: "",
          REACT_APP_FIREBASE_MESSAGING_SENDER_ID: "",
          REACT_APP_FIREBASE_APP_ID: "",
          REACT_APP_FIREBASE_MEASUREMENT_ID: "",
        }).REACT_APP_CONTRACT_UPGRADE_BOSS,
        T = new r(a.MAINNET, o, 18, "UWC", "UWC Token"),
        x =
          (new r(
            a.MAINNET,
            "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
            18,
            "BNB",
            "Wrapper BNB"
          ),
          new r(
            a.MAINNET,
            "0x55d398326f99059fF775485246999027B3197955",
            18,
            "USDT",
            "USDT Token"
          )),
        h = new r(
          a.MAINNET,
          "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56",
          18,
          "BUSD",
          "BUSD Token"
        ),
        j = "",
        g = "",
        O = "root",
        _ = "auth",
        A = "NETWORK";
    },
    352: function (e) {
      e.exports = JSON.parse('{"Home":"Home"}');
    },
    353: function (e) {
      e.exports = JSON.parse('{"Home":"Home"}');
    },
    356: function (e) {
      e.exports = JSON.parse(
        '[{"inputs":[{"internalType":"address payable","name":"_feeWallet","type":"address"},{"internalType":"address","name":"_nft","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"address","name":"seller","type":"address"}],"name":"CancelOrder","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"address","name":"buyer","type":"address"},{"indexed":false,"internalType":"uint256","name":"fee","type":"uint256"}],"name":"FeeSale","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"address","name":"seller","type":"address"}],"name":"FillOrder","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[],"name":"Pause","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"address","name":"seller","type":"address"},{"indexed":false,"internalType":"uint256","name":"price","type":"uint256"}],"name":"PlaceOrder","type":"event"},{"anonymous":false,"inputs":[],"name":"Unpause","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"address","name":"seller","type":"address"},{"indexed":false,"internalType":"uint256","name":"newPrice","type":"uint256"}],"name":"UpdatePrice","type":"event"},{"inputs":[],"name":"PERCENTS_DIVIDER","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"},{"internalType":"address","name":"_token","type":"address"}],"name":"cancelOrder","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"},{"internalType":"address","name":"userAddress","type":"address"}],"name":"cancelOrderOwner","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"feeMarket","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"feeWallet","outputs":[{"internalType":"address payable","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"},{"internalType":"address","name":"_token","type":"address"}],"name":"fillOrder","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"getSale","outputs":[{"components":[{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"address","name":"owner","type":"address"},{"internalType":"uint256","name":"price","type":"uint256"},{"internalType":"address","name":"token","type":"address"}],"internalType":"struct NFTMarket.ItemSale","name":"","type":"tuple"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"coinAddress","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"},{"internalType":"address payable","name":"to","type":"address"}],"name":"handleForfeitedBalance","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"marketsSize","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"migrateIds","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"nft","outputs":[{"internalType":"contract IERC721","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"nftCore","outputs":[{"internalType":"contract INFTCore","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_seller","type":"address"}],"name":"orders","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pause","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"paused","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"},{"internalType":"uint256","name":"_price","type":"uint256"},{"internalType":"address","name":"_token","type":"address"}],"name":"placeOrder","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_fee","type":"uint256"}],"name":"setFeeMarket","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"_wallet","type":"address"}],"name":"setFeeWallet","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"index","type":"uint256"}],"name":"tokenSaleByIndex","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_seller","type":"address"},{"internalType":"uint256","name":"index","type":"uint256"}],"name":"tokenSaleOfOwnerByIndex","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"unpause","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"},{"internalType":"uint256","name":"_price","type":"uint256"},{"internalType":"address","name":"_token","type":"address"}],"name":"updatePrice","outputs":[],"stateMutability":"nonpayable","type":"function"}]'
      );
    },
    357: function (e) {
      e.exports = JSON.parse(
        '[{"inputs":[{"internalType":"address","name":"_nftAddr","type":"address"},{"internalType":"uint256","name":"_cut","type":"uint256"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"address","name":"winner","type":"address"}],"name":"AuctionClaimedNFT","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"address","name":"winner","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"AuctionClaimedToken","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"startingPrice","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"duration","type":"uint256"},{"indexed":false,"internalType":"address","name":"currentBidder","type":"address"},{"indexed":false,"internalType":"uint256","name":"startAt","type":"uint256"},{"indexed":false,"internalType":"address","name":"seller","type":"address"}],"name":"AuctionCreated","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"totalPrice","type":"uint256"},{"indexed":false,"internalType":"address","name":"bidder","type":"address"}],"name":"AuctionSuccessful","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[],"name":"Pause","type":"event"},{"anonymous":false,"inputs":[],"name":"Unpause","type":"event"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"},{"internalType":"uint256","name":"_amount","type":"uint256"},{"internalType":"address","name":"_bidder","type":"address"}],"name":"bid","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"},{"internalType":"address","name":"userAddress","type":"address"}],"name":"cancelAuctionOwner","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_cut","type":"uint256"}],"name":"changeCut","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"claimAmount","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"claimNFT","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"},{"internalType":"uint256","name":"_startingPrice","type":"uint256"},{"internalType":"uint256","name":"_duration","type":"uint256"},{"internalType":"address","name":"_seller","type":"address"}],"name":"createAuction","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"feeBid","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"feeWallet","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"getAuction","outputs":[{"components":[{"internalType":"address","name":"seller","type":"address"},{"internalType":"uint256","name":"startingPrice","type":"uint256"},{"internalType":"uint256","name":"endingPrice","type":"uint256"},{"internalType":"uint64","name":"duration","type":"uint64"},{"internalType":"uint256","name":"startAt","type":"uint256"},{"internalType":"address","name":"currentBidder","type":"address"},{"internalType":"bool","name":"claimNFT","type":"bool"},{"internalType":"bool","name":"claimToken","type":"bool"}],"internalType":"struct ClockAuctionBase.Auction","name":"auction","type":"tuple"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getBalance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"getCurrentPrice","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"getHistories","outputs":[{"components":[{"internalType":"uint256","name":"tokenId","type":"uint256"},{"components":[{"internalType":"address","name":"userAddress","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"timeBid","type":"uint256"}],"internalType":"struct ClockAuctionBase.Bidder[]","name":"bidders","type":"tuple[]"}],"internalType":"struct ClockAuctionBase.History","name":"history","type":"tuple"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"histories","outputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"isSaleClockAuction","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"minAuctionPrice","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"nftToken","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"nonFungibleContract","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"ownerCut","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pause","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"paused","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_fee","type":"uint256"}],"name":"setFeeBid","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_feeWallet","type":"address"}],"name":"setFeeWallet","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_price","type":"uint256"}],"name":"setMinAuctionPrice","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"setNFT","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"setNFTToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_percent","type":"uint256"}],"name":"setStepBid","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"tokenIdToAuction","outputs":[{"internalType":"address","name":"seller","type":"address"},{"internalType":"uint256","name":"startingPrice","type":"uint256"},{"internalType":"uint256","name":"endingPrice","type":"uint256"},{"internalType":"uint64","name":"duration","type":"uint64"},{"internalType":"uint256","name":"startAt","type":"uint256"},{"internalType":"address","name":"currentBidder","type":"address"},{"internalType":"bool","name":"claimNFT","type":"bool"},{"internalType":"bool","name":"claimToken","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"unpause","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"withdrawBalance","outputs":[],"stateMutability":"nonpayable","type":"function"}]'
      );
    },
    358: function (e) {
      e.exports = JSON.parse(
        '[{"inputs":[{"internalType":"address payable","name":"_feeWallet","type":"address"},{"internalType":"address payable","name":"_saleWallet","type":"address"},{"internalType":"address","name":"_nft","type":"address"},{"internalType":"contract IERC20","name":"_nftToken","type":"address"},{"internalType":"address","name":"_randManager","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"address","name":"buyer","type":"address"},{"indexed":false,"internalType":"uint256","name":"fee","type":"uint256"}],"name":"FeeSale","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"address","name":"buyer","type":"address"},{"indexed":false,"internalType":"uint256","name":"boxId","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"typeBox","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"dogeId","type":"uint256"}],"name":"OpenBox","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[],"name":"Pause","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"address","name":"buyer","type":"address"},{"indexed":false,"internalType":"uint256","name":"price","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"typeBox","type":"uint256"},{"indexed":false,"internalType":"bool","name":"success","type":"bool"}],"name":"Sale","type":"event"},{"anonymous":false,"inputs":[],"name":"Unpause","type":"event"},{"inputs":[],"name":"CURRENT_BOX","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"FEE_OPEN","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"LIMIT_ADDRESS_BOX","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"PERCENTS_DIVIDER","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"TIME_STEP","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"TOTAL_BOX","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"claimNormal","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"claimNormals","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"claimWithFee","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"claimWithoutFee","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"deadAddress","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"feeSale","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"feeWallet","outputs":[{"internalType":"address payable","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_typeBox","type":"uint256"}],"name":"getNFTPrice","outputs":[{"internalType":"uint256","name":"priceSale","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_typeBox","type":"uint256"}],"name":"getSaleStore","outputs":[{"components":[{"internalType":"uint256","name":"typeBox","type":"uint256"},{"internalType":"uint256","name":"price","type":"uint256"},{"internalType":"uint256","name":"startSale","type":"uint256"},{"internalType":"uint256","name":"endSale","type":"uint256"},{"internalType":"uint256","name":"fourRarePercent","type":"uint256"},{"internalType":"uint256","name":"thirdRarePercent","type":"uint256"},{"internalType":"uint256","name":"secondRarePercent","type":"uint256"},{"internalType":"uint256","name":"successPercent","type":"uint256"}],"internalType":"struct NFTClaimBox.SaleBox","name":"_saleStore","type":"tuple"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"coinAddress","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"},{"internalType":"address payable","name":"to","type":"address"}],"name":"handleForfeitedBalance","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"limitDoges","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"limitRares","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"nft","outputs":[{"internalType":"contract IERC721","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"nftCore","outputs":[{"internalType":"contract INFTCore","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"nftToken","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"boxId","type":"uint256"},{"internalType":"uint256","name":"nftCommonId","type":"uint256"}],"name":"openBox","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"openBoxs","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pause","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"paused","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"randManager","outputs":[{"internalType":"contract RandInterface","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"saleBoxs","outputs":[{"internalType":"uint256","name":"typeBox","type":"uint256"},{"internalType":"uint256","name":"price","type":"uint256"},{"internalType":"uint256","name":"startSale","type":"uint256"},{"internalType":"uint256","name":"endSale","type":"uint256"},{"internalType":"uint256","name":"fourRarePercent","type":"uint256"},{"internalType":"uint256","name":"thirdRarePercent","type":"uint256"},{"internalType":"uint256","name":"secondRarePercent","type":"uint256"},{"internalType":"uint256","name":"successPercent","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"saleWallet","outputs":[{"internalType":"address payable","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"typeBox","type":"uint256"},{"internalType":"uint256","name":"time","type":"uint256"}],"name":"setEndSale","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_fee","type":"uint256"}],"name":"setFeeOpen","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_fee","type":"uint256"}],"name":"setFeeSale","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"_wallet","type":"address"}],"name":"setFeeWallet","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_box","type":"uint256"}],"name":"setLimitBox","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"rare","type":"uint256"},{"internalType":"uint256","name":"limit","type":"uint256"}],"name":"setLimitRare","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"_address","type":"address"}],"name":"setNFTToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"typeBox","type":"uint256"},{"internalType":"uint256","name":"fourRarePercent","type":"uint256"},{"internalType":"uint256","name":"thirdRarePercent","type":"uint256"},{"internalType":"uint256","name":"secondRarePercent","type":"uint256"}],"name":"setPercentBox","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"typeBox","type":"uint256"},{"internalType":"uint256","name":"price","type":"uint256"}],"name":"setPriceBox","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"_wallet","type":"address"}],"name":"setSaleWallet","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"typeBox","type":"uint256"},{"internalType":"uint256","name":"time","type":"uint256"}],"name":"setStartSale","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_time","type":"uint256"}],"name":"setTimeStep","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_box","type":"uint256"}],"name":"setTotalBox","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"components":[{"internalType":"uint256","name":"lastClaim","type":"uint256"},{"internalType":"uint256","name":"totalClaim","type":"uint256"}],"internalType":"struct NFTClaimBox.UserInfo","name":"userInfo","type":"tuple"},{"internalType":"address","name":"userAddress","type":"address"}],"name":"setUserInfo","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"unpause","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"userInfos","outputs":[{"internalType":"uint256","name":"lastClaim","type":"uint256"},{"internalType":"uint256","name":"totalClaim","type":"uint256"}],"stateMutability":"view","type":"function"}]'
      );
    },
    359: function (e) {
      e.exports = JSON.parse(
        '[{"inputs":[{"internalType":"address payable","name":"_feeWallet","type":"address"},{"internalType":"address payable","name":"_saleWallet","type":"address"},{"internalType":"address","name":"_nft","type":"address"},{"internalType":"address","name":"_nftToken","type":"address"},{"internalType":"address","name":"_randManager","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"address","name":"buyer","type":"address"},{"indexed":false,"internalType":"uint256","name":"fee","type":"uint256"}],"name":"FeeSale","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[],"name":"Pause","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"address","name":"buyer","type":"address"},{"indexed":false,"internalType":"uint256","name":"price","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"typeBox","type":"uint256"}],"name":"Sale","type":"event"},{"anonymous":false,"inputs":[],"name":"Unpause","type":"event"},{"inputs":[],"name":"CURRENT_BOX","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"PERCENTS_DIVIDER","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"TOTAL_BOX","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amount","type":"uint256"},{"internalType":"address","name":"token","type":"address"}],"name":"buyBox","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"feeSale","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"feeWallet","outputs":[{"internalType":"address payable","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_typeBox","type":"uint256"},{"internalType":"address","name":"token","type":"address"}],"name":"getNFTPrice","outputs":[{"internalType":"uint256","name":"priceSale","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_typeBox","type":"uint256"}],"name":"getSaleStore","outputs":[{"components":[{"internalType":"uint256","name":"typeBox","type":"uint256"},{"internalType":"uint256","name":"startSale","type":"uint256"},{"internalType":"uint256","name":"endSale","type":"uint256"},{"internalType":"uint256","name":"fourRarePercent","type":"uint256"},{"internalType":"uint256","name":"thirdRarePercent","type":"uint256"},{"internalType":"uint256","name":"secondRarePercent","type":"uint256"}],"internalType":"struct NFTBox.SaleBox","name":"_saleStore","type":"tuple"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"coinAddress","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"},{"internalType":"address payable","name":"to","type":"address"}],"name":"handleForfeitedBalance","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"nft","outputs":[{"internalType":"contract IERC721","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"nftCore","outputs":[{"internalType":"contract INFTCore","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pause","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"paused","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"randManager","outputs":[{"internalType":"contract RandInterface","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"removeToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"address","name":"","type":"address"}],"name":"saleBoxTokenPrices","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"saleBoxs","outputs":[{"internalType":"uint256","name":"typeBox","type":"uint256"},{"internalType":"uint256","name":"startSale","type":"uint256"},{"internalType":"uint256","name":"endSale","type":"uint256"},{"internalType":"uint256","name":"fourRarePercent","type":"uint256"},{"internalType":"uint256","name":"thirdRarePercent","type":"uint256"},{"internalType":"uint256","name":"secondRarePercent","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"saleTokens","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"saleWallet","outputs":[{"internalType":"address payable","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"typeBox","type":"uint256"},{"internalType":"uint256","name":"time","type":"uint256"}],"name":"setEndSale","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_fee","type":"uint256"}],"name":"setFeeSale","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"_wallet","type":"address"}],"name":"setFeeWallet","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"typeBox","type":"uint256"},{"internalType":"uint256","name":"fourRarePercent","type":"uint256"},{"internalType":"uint256","name":"thirdRarePercent","type":"uint256"},{"internalType":"uint256","name":"secondRarePercent","type":"uint256"}],"name":"setPercentBox","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"typeBox","type":"uint256"},{"internalType":"uint256","name":"price","type":"uint256"},{"internalType":"address","name":"token","type":"address"}],"name":"setPriceBox","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"_wallet","type":"address"}],"name":"setSaleWallet","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"typeBox","type":"uint256"},{"internalType":"uint256","name":"time","type":"uint256"}],"name":"setStartSale","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"setToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_box","type":"uint256"}],"name":"setTotalBox","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"unpause","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"}]'
      );
    },
    360: function (e) {
      e.exports = JSON.parse(
        '[{"inputs":[{"internalType":"contract IERC20","name":"_cake","type":"address"},{"internalType":"uint256","name":"_cakePerBlock","type":"uint256"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Deposit","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"totalAmount","type":"uint256"}],"name":"FeePayed","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"LeaveStaking","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[],"name":"Pause","type":"event"},{"anonymous":false,"inputs":[],"name":"Unpause","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Withdraw","type":"event"},{"inputs":[],"name":"BONUS_MULTIPLIER","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"PERCENTS_DIVIDER","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"UNSTAKE_FEE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"WIHDRAW_FEE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"WIHDRAW_FEE_BNB","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_allocPoint","type":"uint256"},{"internalType":"contract IERC20","name":"_lpToken","type":"address"},{"internalType":"bool","name":"_withUpdate","type":"bool"},{"internalType":"uint256","name":"_startBlock","type":"uint256"},{"internalType":"uint256","name":"_endBlock","type":"uint256"},{"internalType":"bool","name":"_isLocked","type":"bool"}],"name":"add","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"addressList","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"cake","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"cakePerBlock","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"commissionWallet","outputs":[{"internalType":"address payable","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"},{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"deposit","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_from","type":"uint256"},{"internalType":"uint256","name":"_to","type":"uint256"}],"name":"getMultiplier","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"coinAddress","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"},{"internalType":"address payable","name":"to","type":"address"}],"name":"handleForfeitedBalance","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"}],"name":"leaveStaking","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"massUpdatePools","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pause","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"paused","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"},{"internalType":"address","name":"_user","type":"address"}],"name":"pendingCake","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"poolInfo","outputs":[{"internalType":"contract IERC20","name":"lpToken","type":"address"},{"internalType":"uint256","name":"allocPoint","type":"uint256"},{"internalType":"uint256","name":"lastRewardBlock","type":"uint256"},{"internalType":"uint256","name":"accCakePerShare","type":"uint256"},{"internalType":"uint256","name":"startBlock","type":"uint256"},{"internalType":"uint256","name":"endBlock","type":"uint256"},{"internalType":"uint256","name":"totalLpSupply","type":"uint256"},{"internalType":"bool","name":"isLocked","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"poolLength","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"},{"internalType":"uint256","name":"_allocPoint","type":"uint256"},{"internalType":"bool","name":"_withUpdate","type":"bool"}],"name":"set","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_fee","type":"uint256"}],"name":"setCakePerBlock","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"_addr","type":"address"}],"name":"setCommissionsWallet","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_fee","type":"uint256"}],"name":"setUnStakeFee","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_fee","type":"uint256"}],"name":"setWithdrawFee","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_fee","type":"uint256"}],"name":"setWithdrawFeeBnb","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"totalAllocPoint","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"unpause","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"multiplierNumber","type":"uint256"}],"name":"updateMultiplier","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"}],"name":"updatePool","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"address","name":"","type":"address"}],"name":"userInfo","outputs":[{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"rewardDebt","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"}],"name":"withdraw","outputs":[],"stateMutability":"payable","type":"function"}]'
      );
    },
    361: function (e) {
      e.exports = JSON.parse(
        '[{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"totalAmount","type":"uint256"}],"name":"FeePayed","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint8","name":"plan","type":"uint8"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"start","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"finish","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"fee","type":"uint256"}],"name":"NewDeposit","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"start","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"NewDepositNFT","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"registerTime","type":"uint256"}],"name":"Newbie","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"account","type":"address"}],"name":"Paused","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"start","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"UnStake","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"start","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"UnlockNFT","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"account","type":"address"}],"name":"Unpaused","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"start","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Withdrawn","type":"event"},{"inputs":[],"name":"PERCENTS_DIVIDER","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"PROJECT_FEE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"TIME_STAKE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"TIME_STEP","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"TOTAL_CLAIMED","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"TOTAL_LOCKED","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"TOTAL_STAKED","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"UNLOCK_FEE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"commissionWallet","outputs":[{"internalType":"address payable","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"nft","outputs":[{"internalType":"contract IERC721","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"nftCore","outputs":[{"internalType":"contract INFTCore","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"paused","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"rares","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"stakingToken","outputs":[{"internalType":"contract IERC20Upgradeable","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"timePlans","outputs":[{"internalType":"uint256","name":"start","type":"uint256"},{"internalType":"uint256","name":"finish","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"_saleWallet","type":"address"},{"internalType":"address","name":"_nft","type":"address"},{"internalType":"contract IERC20Upgradeable","name":"_nftToken","type":"address"}],"name":"initialize","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint8","name":"plan","type":"uint8"},{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"invest","outputs":[],"stateMutability":"payable","type":"function","payable":true},{"inputs":[{"internalType":"uint256","name":"start","type":"uint256"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"depositNFT","outputs":[],"stateMutability":"payable","type":"function","payable":true},{"inputs":[{"internalType":"uint256","name":"start","type":"uint256"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"unlockNFT","outputs":[],"stateMutability":"payable","type":"function","payable":true},{"inputs":[{"internalType":"uint256","name":"start","type":"uint256"}],"name":"unStake","outputs":[],"stateMutability":"payable","type":"function","payable":true},{"inputs":[{"internalType":"uint256","name":"start","type":"uint256"}],"name":"withdraw","outputs":[],"stateMutability":"payable","type":"function","payable":true},{"inputs":[{"internalType":"address","name":"userAddress","type":"address"},{"internalType":"uint256","name":"start","type":"uint256"}],"name":"calculateStake","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"uint256","name":"_fee","type":"uint256"}],"name":"setFeeSystem","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_nft","type":"address"}],"name":"setNFT","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_fee","type":"uint256"}],"name":"setUnlockFeeSystem","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_timeStep","type":"uint256"}],"name":"setTime_Step","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_timeStake","type":"uint256"}],"name":"setTime_Stake","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"_addr","type":"address"}],"name":"setCommissionsWallet","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"planId","type":"uint256"},{"components":[{"internalType":"uint256","name":"time","type":"uint256"},{"internalType":"uint256","name":"percentBlock","type":"uint256"},{"internalType":"uint256","name":"totalAmountStake","type":"uint256"}],"internalType":"struct NFTStaking.Plan","name":"plan","type":"tuple"}],"name":"updatePlan","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"planId","type":"uint256"},{"components":[{"internalType":"uint256","name":"start","type":"uint256"},{"internalType":"uint256","name":"finish","type":"uint256"}],"internalType":"struct NFTStaking.TimePlan","name":"plan","type":"tuple"}],"name":"updateTimePlan","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"rare","type":"uint256"},{"internalType":"uint256","name":"percent","type":"uint256"}],"name":"updateRares","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_totalLocked","type":"uint256"}],"name":"setTotalLocked","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"coinAddress","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"},{"internalType":"address payable","name":"to","type":"address"}],"name":"handleForfeitedBalance","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint8","name":"plan","type":"uint8"}],"name":"getResult","outputs":[{"internalType":"uint256","name":"finish","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"address","name":"userAddress","type":"address"}],"name":"getUserInfo","outputs":[{"components":[{"components":[{"internalType":"uint8","name":"plan","type":"uint8"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"uint256","name":"rare","type":"uint256"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"start","type":"uint256"},{"internalType":"uint256","name":"finish","type":"uint256"},{"internalType":"address","name":"userAddress","type":"address"},{"internalType":"uint256","name":"fee","type":"uint256"},{"internalType":"bool","name":"isUnStake","type":"bool"},{"internalType":"uint256","name":"checkpoint","type":"uint256"}],"internalType":"struct NFTStaking.Deposit[]","name":"deposits","type":"tuple[]"},{"internalType":"address","name":"owner","type":"address"},{"internalType":"uint256","name":"checkpoint","type":"uint256"},{"internalType":"uint256","name":"registerTime","type":"uint256"},{"internalType":"uint256","name":"lastStake","type":"uint256"}],"internalType":"struct NFTStaking.User","name":"userInfo","type":"tuple"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"address","name":"userAddress","type":"address"}],"name":"getUserTotalDeposits","outputs":[{"internalType":"uint256","name":"amount","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"uint8","name":"planId","type":"uint8"}],"name":"getPlanInfo","outputs":[{"components":[{"internalType":"uint256","name":"time","type":"uint256"},{"internalType":"uint256","name":"percentBlock","type":"uint256"},{"internalType":"uint256","name":"totalAmountStake","type":"uint256"}],"internalType":"struct NFTStaking.Plan","name":"plan","type":"tuple"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"uint8","name":"planId","type":"uint8"}],"name":"getTimePlanInfo","outputs":[{"components":[{"internalType":"uint256","name":"start","type":"uint256"},{"internalType":"uint256","name":"finish","type":"uint256"}],"internalType":"struct NFTStaking.TimePlan","name":"plan","type":"tuple"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"address","name":"userAddress","type":"address"},{"internalType":"uint256","name":"start","type":"uint256"}],"name":"isUnStake","outputs":[{"internalType":"bool","name":"_isUnStake","type":"bool"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"address","name":"userAddress","type":"address"}],"name":"getAllDepositsByAddress","outputs":[{"components":[{"internalType":"uint8","name":"plan","type":"uint8"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"uint256","name":"rare","type":"uint256"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"start","type":"uint256"},{"internalType":"uint256","name":"finish","type":"uint256"},{"internalType":"address","name":"userAddress","type":"address"},{"internalType":"uint256","name":"fee","type":"uint256"},{"internalType":"bool","name":"isUnStake","type":"bool"},{"internalType":"uint256","name":"checkpoint","type":"uint256"}],"internalType":"struct NFTStaking.Deposit[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function","constant":true}]'
      );
    },
    362: function (e) {
      e.exports = JSON.parse(
        '[{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"account","type":"address"}],"name":"Paused","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"class","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"rare","type":"uint256"},{"indexed":false,"internalType":"string","name":"name","type":"string"}],"name":"Sale","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"account","type":"address"}],"name":"Unpaused","type":"event"},{"inputs":[],"name":"BUY_TOKEN","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"CURRENT_BOX","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"END_SALE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"LIMIT_BOX","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"PERCENTS_DIVIDER","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"SALE_PRICE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"SALE_WALLET","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"START_SALE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"TOTAL_BOX","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"nftCore","outputs":[{"internalType":"contract INFTCore","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"nftRates","outputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"uint256","name":"class","type":"uint256"},{"internalType":"uint256","name":"rare","type":"uint256"},{"internalType":"string","name":"name","type":"string"},{"internalType":"string","name":"description","type":"string"},{"internalType":"uint256","name":"bornTime","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"paused","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"quantityBox","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"}],"name":"tierRates","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"_saleWallet","type":"address"},{"internalType":"address","name":"_nft","type":"address"},{"internalType":"address","name":"_buyToken","type":"address"}],"name":"initialize","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_box","type":"uint256"}],"name":"setTotalBox","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_buyToken","type":"address"}],"name":"setBuyToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_saleWallet","type":"address"}],"name":"setSaleWallet","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_salePrice","type":"uint256"}],"name":"setSalePrice","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_box","type":"uint256"}],"name":"setLimitBox","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"buyBox","outputs":[],"stateMutability":"payable","type":"function","payable":true}]'
      );
    },
    363: function (e) {
      e.exports = JSON.parse(
        '[{"inputs":[],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"userAddress","type":"address"},{"indexed":false,"internalType":"uint256","name":"damage","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"typeBoss","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"bossId","type":"uint256"}],"name":"Attack","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"userAddress","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"fee","type":"uint256"}],"name":"FeeClaim","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[],"name":"Pause","type":"event"},{"anonymous":false,"inputs":[],"name":"Unpause","type":"event"},{"inputs":[],"name":"ATTACK","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"ATTACK_MISSION","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"CLAIM_FEE_ADV","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"CLAIM_FEE_NOR","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"FEE_ATTACK","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"FEE_TOKEN","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"REWARD_NOT_DIE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"REWARD_TOKEN","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"SALE_WALLET","outputs":[{"internalType":"address payable","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"bossId","type":"uint256"},{"internalType":"uint256[]","name":"heros","type":"uint256[]"}],"name":"attackBoss","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"attackCounts","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"bossId","type":"uint256"}],"name":"bossInfo","outputs":[{"components":[{"internalType":"uint256","name":"id","type":"uint256"},{"internalType":"uint256","name":"typeBoss","type":"uint256"},{"internalType":"uint256","name":"blood","type":"uint256"},{"internalType":"uint256","name":"startTime","type":"uint256"},{"internalType":"uint256","name":"endTime","type":"uint256"},{"internalType":"uint256","name":"minHero","type":"uint256"},{"internalType":"uint256","name":"maxHero","type":"uint256"},{"internalType":"bool","name":"died","type":"bool"},{"internalType":"uint256","name":"currentDamage","type":"uint256"},{"internalType":"uint256","name":"totalReward","type":"uint256"}],"internalType":"struct AttachBoss.Boss","name":"boss","type":"tuple"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"bossId","type":"uint256"}],"name":"claimReward","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"bossId","type":"uint256"},{"internalType":"address","name":"userAddress","type":"address"}],"name":"getUserInfo","outputs":[{"components":[{"internalType":"uint256","name":"damage","type":"uint256"},{"internalType":"bool","name":"claimed","type":"bool"}],"internalType":"struct AttachBoss.UserInfo","name":"user","type":"tuple"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"coinAddress","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"},{"internalType":"address payable","name":"to","type":"address"}],"name":"handleForfeitedBalance","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"components":[{"internalType":"uint256","name":"id","type":"uint256"},{"internalType":"uint256","name":"typeBoss","type":"uint256"},{"internalType":"uint256","name":"blood","type":"uint256"},{"internalType":"uint256","name":"startTime","type":"uint256"},{"internalType":"uint256","name":"endTime","type":"uint256"},{"internalType":"uint256","name":"minHero","type":"uint256"},{"internalType":"uint256","name":"maxHero","type":"uint256"},{"internalType":"bool","name":"died","type":"bool"},{"internalType":"uint256","name":"currentDamage","type":"uint256"},{"internalType":"uint256","name":"totalReward","type":"uint256"}],"internalType":"struct AttachBoss.Boss[]","name":"bossArr","type":"tuple[]"}],"name":"modifyBoss","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address[]","name":"newAddr","type":"address[]"},{"internalType":"address[]","name":"removedAddr","type":"address[]"}],"name":"modifyWhiteList","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"nft","outputs":[{"internalType":"contract IERC721","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"nftCore","outputs":[{"internalType":"contract INFTCore","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pause","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"paused","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"attack","type":"uint256"}],"name":"setAttack","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"mission","type":"uint256"}],"name":"setAttackMission","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_fee","type":"uint256"}],"name":"setClaimFeeAdv","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_fee","type":"uint256"}],"name":"setClaimFeeNor","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_fee","type":"uint256"}],"name":"setFeeAttack","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"setFeeToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"setNFT","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"reward","type":"uint256"}],"name":"setRewardNoDie","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"setRewardToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"_address","type":"address"}],"name":"setSaleWallet","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"unpause","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"address","name":"","type":"address"}],"name":"userInfos","outputs":[{"internalType":"uint256","name":"damage","type":"uint256"},{"internalType":"bool","name":"claimed","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"whiteList","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"}]'
      );
    },
    364: function (e) {
      e.exports = JSON.parse(
        '[{"inputs":[{"internalType":"address payable","name":"_feeWallet","type":"address"},{"internalType":"address","name":"_nft","type":"address"},{"internalType":"contract IERC20","name":"_nftToken","type":"address"},{"internalType":"address","name":"_randManager","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"address","name":"buyer","type":"address"},{"indexed":false,"internalType":"uint256","name":"fee","type":"uint256"}],"name":"FeeSale","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"address","name":"merger","type":"address"},{"indexed":false,"internalType":"bool","name":"isSuccess","type":"bool"}],"name":"Merge","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[],"name":"Pause","type":"event"},{"anonymous":false,"inputs":[],"name":"Unpause","type":"event"},{"inputs":[],"name":"BOSST_RATE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"FEE_MERGE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"MAX_DOGE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"MIN_DOGE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"PERCENTS_DIVIDER","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"PERCENT_ADD","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"PERCENT_BOOST","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"deadAddress","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"feeWallet","outputs":[{"internalType":"address payable","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"coinAddress","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"},{"internalType":"address payable","name":"to","type":"address"}],"name":"handleForfeitedBalance","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256[]","name":"tokenIds","type":"uint256[]"},{"internalType":"bool","name":"isBoost","type":"bool"}],"name":"mergeNFT","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"nft","outputs":[{"internalType":"contract IERC721","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"nftCore","outputs":[{"internalType":"contract INFTCore","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"nftToken","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pause","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"paused","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"randManager","outputs":[{"internalType":"contract RandInterface","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_min","type":"uint256"},{"internalType":"uint256","name":"_max","type":"uint256"}],"name":"setDoge","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_fee","type":"uint256"}],"name":"setFeeMerge","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"_wallet","type":"address"}],"name":"setFeeWallet","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"setNFT","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"_address","type":"address"}],"name":"setNFTToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_add","type":"uint256"},{"internalType":"uint256","name":"_boost","type":"uint256"}],"name":"setPercent","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"unpause","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"}]'
      );
    },
    365: function (e) {
      e.exports = JSON.parse(
        '[{"inputs":[],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"spender","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[],"name":"PERCENTS_DIVIDER","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"_feeTransfer","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"_feeWallet","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"antiBotEnabled","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"blackList","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"burn","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"feeTransfer","type":"uint256"}],"name":"changeFee","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"feeWallet","type":"address"}],"name":"changeFeeWallet","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"subtractedValue","type":"uint256"}],"name":"decreaseAllowance","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"_pmintable","type":"bool"}],"name":"enableMint","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"geUnlockTime","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"addedValue","type":"uint256"}],"name":"increaseAllowance","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"isBlackList","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"isExcludedFromBot","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"isExcludedFromFee","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"isExcludedFromPool","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"isExcludedToFee","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"time","type":"uint256"}],"name":"lock","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"maxSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"mint","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address[]","name":"newWhiteList","type":"address[]"},{"internalType":"address[]","name":"removedWhiteList","type":"address[]"}],"name":"modifyBlackList","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address[]","name":"newWhiteList","type":"address[]"},{"internalType":"address[]","name":"removedWhiteList","type":"address[]"}],"name":"modifyWhiteListBot","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address[]","name":"newWhiteList","type":"address[]"},{"internalType":"address[]","name":"removedWhiteList","type":"address[]"}],"name":"modifyWhiteListPool","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address[]","name":"newWhiteList","type":"address[]"},{"internalType":"address[]","name":"removedWhiteList","type":"address[]"}],"name":"modifyWhiteListReceiver","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address[]","name":"newWhiteList","type":"address[]"},{"internalType":"address[]","name":"removedWhiteList","type":"address[]"}],"name":"modifyWhiteListSender","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"_enable","type":"bool"}],"name":"setAntiBot","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"_enable","type":"bool"}],"name":"setSwapWhiteList","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"swapWhiteList","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"sender","type":"address"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"coinAddress","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"},{"internalType":"address payable","name":"to","type":"address"}],"name":"transferToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"uniswapV2Pair","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"uniswapV2Router","outputs":[{"internalType":"contract IUniswapV2Router02","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"unlock","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"whiteListBot","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"whiteListPool","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"whiteListReceiver","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"whiteListSender","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"stateMutability":"payable","type":"receive"}]'
      );
    },
    366: function (e) {
      e.exports = JSON.parse(
        '[{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"approved","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"operator","type":"address"},{"indexed":false,"internalType":"bool","name":"approved","type":"bool"}],"name":"ApprovalForAll","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[{"internalType":"bytes4","name":"interfaceId","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"balance","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"ownerOf","outputs":[{"internalType":"address","name":"owner","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"transferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"approve","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"getApproved","outputs":[{"internalType":"address","name":"operator","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"operator","type":"address"},{"internalType":"bool","name":"_approved","type":"bool"}],"name":"setApprovalForAll","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"operator","type":"address"}],"name":"isApprovedForAll","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"}]'
      );
    },
    373: function (e, n, t) {
      "use strict";
      (function (e) {
        var a = t(27),
          i = t(10),
          s = t(11),
          r = t(5),
          o = t.n(r),
          p = t(235),
          u = t.n(p),
          l = t(33),
          c = "https://api.github.com",
          d = l.o,
          y = l.m,
          m = l.n,
          b = (function () {
            function n() {
              Object(i.a)(this, n), (this.repos = []), (this.tree = []);
            }
            return (
              Object(s.a)(n, [
                {
                  key: "getRepoTreeAtOrgan",
                  value: (function () {
                    var e = Object(a.a)(
                      o.a.mark(function e() {
                        var n,
                          t,
                          i,
                          s,
                          r = this,
                          p = arguments;
                        return o.a.wrap(function (e) {
                          for (;;)
                            switch ((e.prev = e.next)) {
                              case 0:
                                return (
                                  (n =
                                    p.length > 0 && void 0 !== p[0] ? p[0] : y),
                                  (t =
                                    p.length > 1 && void 0 !== p[1] ? p[1] : m),
                                  (i =
                                    p.length > 2 && void 0 !== p[2]
                                      ? p[2]
                                      : null),
                                  (s = i
                                    ? ""
                                        .concat(c, "/repos/")
                                        .concat(n, "/")
                                        .concat(
                                          t,
                                          "/git/trees/main?access_token="
                                        )
                                        .concat(i, "&recursive=1")
                                    : ""
                                        .concat(c, "/repos/")
                                        .concat(n, "/")
                                        .concat(
                                          t,
                                          "/git/trees/main?recursive=1"
                                        )),
                                  e.abrupt(
                                    "return",
                                    new Promise(function (e, n) {
                                      Object(a.a)(
                                        o.a.mark(function t() {
                                          return o.a.wrap(
                                            function (t) {
                                              for (;;)
                                                switch ((t.prev = t.next)) {
                                                  case 0:
                                                    return (
                                                      (t.prev = 0),
                                                      (t.next = 3),
                                                      u()({
                                                        method: "get",
                                                        url: s,
                                                        headers: {
                                                          "content-type":
                                                            "application/json;charset=UTF-8",
                                                          Accept:
                                                            "application/vnd.github.v3+json",
                                                        },
                                                      }).then(function (t) {
                                                        200 === t.status &&
                                                          ((r.tree =
                                                            t.data.tree),
                                                          e(t.data.tree)),
                                                          n(
                                                            new Error(
                                                              "Error!!!"
                                                            )
                                                          );
                                                      })
                                                    );
                                                  case 3:
                                                    n(new Error("Error!!!")),
                                                      (t.next = 9);
                                                    break;
                                                  case 6:
                                                    (t.prev = 6),
                                                      (t.t0 = t.catch(0)),
                                                      n(new Error("Error!!!"));
                                                  case 9:
                                                  case "end":
                                                    return t.stop();
                                                }
                                            },
                                            t,
                                            null,
                                            [[0, 6]]
                                          );
                                        })
                                      )();
                                    })
                                  )
                                );
                              case 5:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                      })
                    );
                    return function () {
                      return e.apply(this, arguments);
                    };
                  })(),
                },
                {
                  key: "getFileData",
                  value: (function () {
                    var n = Object(a.a)(
                      o.a.mark(function n(t) {
                        var i,
                          s = this,
                          r = arguments;
                        return o.a.wrap(function (n) {
                          for (;;)
                            switch ((n.prev = n.next)) {
                              case 0:
                                return (
                                  (i =
                                    r.length > 1 && void 0 !== r[1]
                                      ? r[1]
                                      : null),
                                  n.abrupt(
                                    "return",
                                    new Promise(function (n, r) {
                                      Object(a.a)(
                                        o.a.mark(function a() {
                                          var p, l, c, y, m;
                                          return o.a.wrap(
                                            function (a) {
                                              for (;;)
                                                switch ((a.prev = a.next)) {
                                                  case 0:
                                                    if (
                                                      ((a.prev = 0),
                                                      (l = ""
                                                        .concat(d, "/")
                                                        .concat(t)),
                                                      null,
                                                      void 0 !== p)
                                                    ) {
                                                      a.next = 14;
                                                      break;
                                                    }
                                                    if (
                                                      !(y =
                                                        null === (c = s.tree) ||
                                                        void 0 === c
                                                          ? void 0
                                                          : c.find(function (
                                                              e
                                                            ) {
                                                              return (
                                                                e.path.toLowerCase() ===
                                                                l.toLowerCase()
                                                              );
                                                            })) ||
                                                      !y.url
                                                    ) {
                                                      a.next = 13;
                                                      break;
                                                    }
                                                    return (
                                                      (a.next = 9),
                                                      u()({
                                                        method: "get",
                                                        url: ""
                                                          .concat(y.url)
                                                          .concat(
                                                            i
                                                              ? "?access_token=".concat(
                                                                  i
                                                                )
                                                              : ""
                                                          ),
                                                        headers: {
                                                          "content-type":
                                                            "application/json;charset=UTF-8",
                                                          Accept:
                                                            "application/vnd.github.v3+json",
                                                        },
                                                      })
                                                    );
                                                  case 9:
                                                    200 === (m = a.sent).status
                                                      ? (p = JSON.parse(
                                                          e
                                                            .from(
                                                              m.data.content,
                                                              "base64"
                                                            )
                                                            .toString("ascii")
                                                        ))
                                                      : r(
                                                          new Error(
                                                            "An error occurred!"
                                                          )
                                                        ),
                                                      (a.next = 14);
                                                    break;
                                                  case 13:
                                                    r(
                                                      new Error(
                                                        "Path file is not correct!"
                                                      )
                                                    );
                                                  case 14:
                                                    n(p), (a.next = 20);
                                                    break;
                                                  case 17:
                                                    (a.prev = 17),
                                                      (a.t0 = a.catch(0)),
                                                      r(a.t0.message);
                                                  case 20:
                                                  case "end":
                                                    return a.stop();
                                                }
                                            },
                                            a,
                                            null,
                                            [[0, 17]]
                                          );
                                        })
                                      )();
                                    })
                                  )
                                );
                              case 2:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                      })
                    );
                    return function (e) {
                      return n.apply(this, arguments);
                    };
                  })(),
                },
              ]),
              n
            );
          })();
        n.a = b;
      }.call(this, t(17).Buffer));
    },
    402: function (e, n) {},
    424: function (e, n) {},
    427: function (e, n) {},
    431: function (e, n) {},
    450: function (e, n) {},
    452: function (e, n) {},
    461: function (e, n) {},
    463: function (e, n) {},
    473: function (e, n) {},
    475: function (e, n) {},
    589: function (e, n) {},
    591: function (e, n) {},
    598: function (e, n) {},
    599: function (e, n) {},
    740: function (e, n, t) {},
    805: function (e, n, t) {
      "use strict";
      t.r(n);
      var a,
        i,
        s = t(0),
        r = t.n(s),
        o = t(38),
        p = t.n(o),
        u = t(816),
        l = t(377),
        c = t(378),
        d = t(18),
        y = t(16),
        m = Object(y.b)(
          a ||
            (a = Object(d.a)([
              '\n  /* prettier-ignore */\n  html, body, div, span, applet, object, iframe,\n  h1, h2, h3, h4, h5, h6, p, blockquote, pre,\n  a, abbr, acronym, address, big, cite, code,\n  del, dfn, em, img, ins, kbd, q, s, samp,\n  small, strike, strong, sub, sup, tt, var, \n  b, u, i, center,\n  dl, dt, dd, ol, ul, li,\n  fieldset, form, label, legend,\n  table, caption, tbody, tfoot, thead, tr, th, td,\n  article, aside, canvas, details, embed, \n  figure, figcaption, footer, header, hgroup, \n  menu, nav, output, ruby, section, summary,\n  time, mark, audio, video { \n    margin: 0;\n    padding: 0;\n    border: 0;\n    font-size: 100%;\n    vertical-align: middle;\n  }\n  /* HTML5 display-role reset for older browsers */\n  /* prettier-ignore */\n  article, aside, details, figcaption, figure, \n  footer, header, hgroup, menu, nav, section {\n    display: block;\n  } \n  ol,\n  ul {\n    list-style: disc;\n    list-style-position: inside;\n  }\n  blockquote,\n  q {\n    quotes: none;\n  }\n  blockquote:before,\n  blockquote:after,\n  q:before,\n  q:after {\n    content: "";\n    content: none;\n  }\n  table {\n    border-collapse: collapse;\n    border-spacing: 0;\n  }\n  a {\n    color: inherit;\n    text-decoration: none;\n  }\n  [role="button"] {\n    cursor: pointer;\n  }\n  /* Slider */ \n  input[type=range] {\n    -webkit-appearance: none; /* Hides the slider so that custom slider can be made */\n    width: 100%; /* Specific width is required for Firefox. */\n    background: transparent; /* Otherwise white in Chrome */\n  }\n  input[type=range]::-webkit-slider-thumb {\n    -webkit-appearance: none;\n  }\n  input[type=range]:focus {\n    outline: none; /* Removes the blue border. You should probably do some kind of focus styling for accessibility reasons though. */\n  }\n  input[type=range]::-ms-track {\n    width: 100%;\n    cursor: pointer;\n    /* Hides the slider so custom styles can be added */\n    background: transparent; \n    border-color: transparent;\n    color: transparent;\n  }  \n',
            ]))
        ),
        b = Object(y.b)(
          i ||
            (i = Object(d.a)([
              " \n  * {\n    font-family: Roboto;\n    -webkit-font-smoothing: antialiased;\n    -moz-osx-font-smoothing: grayscale; \n  } \n  *, \n  *::before,\n  *::after {\n    box-sizing: border-box;\n  }\n\n  /* Scrollbar */\n  ::-webkit-scrollbar { \n    width: 5px;\n  }\n  ::-webkit-scrollbar-thumb {\n    background: ",
              "; \n    border-radius: 8px;\n  }\n  ::-webkit-scrollbar-track {\n    box-shadow: inset 0 0 5px #FFF1C1; \n    border-radius: 10px;\n  }\n\n  html {\n    scroll-behavior: smooth;\n  }\n\n  body {\n    color:#fff; \n    line-height: 1;\n    font-size: 16px;\n    overflow-x: hidden;\n    background: #101724;\n    \n    @media (max-width: 576px) {\n      width: 100% !important; \n    } \n\n    .ant-layout {\n      background: #101724;\n    }\n\n    & > iframe {\n      display: none; \n    }\n\n    img {\n      height: auto;\n      max-width: 100%;\n\n      image-rendering: -moz-crisp-edges;\n      image-rendering: -o-crisp-edges;\n      image-rendering: -webkit-optimize-contrast;\n      image-rendering: crisp-edges;\n      -ms-interpolation-mode: nearest-neighbor;\n    }\n  }\n\n  .Toastify__toast-body {\n    font-family: 'Helvetica';\n  }\n\n  .box-error {\n    color: red;\n    font-family: 'Helvetica';\n    font-size: 12px;\n    padding: 5px;\n    text-align:center;\n  }\n \n  .modal-confirm {\n    width: 448px !important;\n    max-width: 100% !important;\n    .ant-modal-body {\n      padding: 0 !important;\n    }\n\n    .ant-modal-content {\n      border: none;\n    }\n  }\n\n  .ant-modal-content {\n    background-color: #030303;\n    overflow: hidden;\n    border: 1px solid #ffffff;\n    \n\n    .ant-modal-close {\n      top: 14px;\n      right: 20px;\n      ",
              " {\n        top: 20px;\n        right: 20px;\n      }\n      img {\n        width: 26px;\n        ",
              " {\n          width: 36px;\n        }\n      }\n    }\n    .ant-modal-header {\n      background-color: unset;\n      border-bottom: unset;\n      padding-top: 32px;\n      padding-left: 34px;\n \n      .ant-modal-title {\n        color: #fff; \n        font-weight: 500;\n        font-size: 20px;\n        line-height: 22px;\n        letter-spacing: 0.04em;\n        text-shadow: 1px 7px 4px rgba(111, 27, 47, 0.35), 0px -1px 0px #B64034;\n        ",
              " {\n          font-size: 32px;\n          line-height: 100%;\n        }\n      }\n    }\n    .ant-modal-body {\n      padding: 0 32px 0;\n    }\n\n    .ant-empty-description {\n      color: #fff;\n    }\n  } \n  \n\n  // ant select dropdown\n  .ant-select-dropdown {\n    padding: 0; \n    background: #512a2e; \n    border-radius: 4px; \n    overflow: hidden;\n  }\n  .ant-select-item {\n    color: rgb(230 247 255); \n  }\n  .ant-select-item-option-active:not(.ant-select-item-option-disabled) {\n    color: rgb(230 247 255); \n    background: #512a2e; \n  }\n  .ant-select-item-option-selected:not(.ant-select-item-option-disabled) {\n    color: #fff; \n    background: #83ccf045; \n  }\n\n  input::-webkit-outer-spin-button,\n  input::-webkit-inner-spin-button {\n    -webkit-appearance: none;\n    margin: 0;\n  }\n\n  input[type='number'] {\n    -moz-appearance: textfield;\n  }\n\n  .public-layout{\n    overflow: hidden;\n  }\n  \n  .ant-select-dropdown{\n    background: #101724;\n    width: 190px !important;\n    left: auto !important;\n    right: 10px !important;\n  }\n\n  .modal-connect-wallet{\n    background: #191034;\n    box-shadow: 0px 20px 36px -8px rgb(14 14 44 / 10%), 0px 1px 1px rgb(0 0 0 / 5%);\n    border: 1px solid rgba(255,255,255,0.2);\n    border-radius: 15px;\n    width: 387px !important;\n\n    .ant-modal-body{\n      padding 0 !important;\n\n      >div {\n        padding 0 !important;\n      }\n    }\n\n    .ant-modal-content {\n      border-radius: 15px;\n      border: none;\n\n      .ant-modal-close{\n        top: 0;\n        right: 10px;\n\n        @media (min-width: 576px) {\n          img {\n            width: 30px;\n          }\n        }\n      }\n\n      .content-modal{\n        background: #1A1034;\n\n        .title {\n          padding: 12px 24px;\n          border-bottom: 1px solid #e9eaeb;\n          line-height: 32px;\n          margin-bottom: 0;\n          background: #1A1034;\n        }\n\n        .ant-row{\n          padding: 24px;\n          flex-direction: column;\n          row-gap: 24px;\n\n          .ant-col{\n            width: 100%;\n            max-width: 100%;\n\n            > div {\n              border: 1px solid #c92dff;\n              background: transparent;\n              display: flex;\n              flex-direction: row;\n              justify-content: space-between;\n              height: 48px;\n\n              &:hover {\n                opacity: 0.65;\n\n                .modal-title{\n                  font-size: 16px;\n                }\n              }\n\n              svg {\n                width: 32px;\n              }\n            }\n          }\n\n          .modal-title{\n            font-weight: bold;\n          }\n        }\n      }\n    }\n  }\n",
            ])),
          function (e) {
            return e.theme.colors.primary;
          },
          function (e) {
            return e.theme.mediaQueries.sm;
          },
          function (e) {
            return e.theme.mediaQueries.sm;
          },
          function (e) {
            return e.theme.mediaQueries.sm;
          }
        ),
        f = t(43),
        T = t(66),
        x = t(27),
        h = t(2),
        j = t(6),
        g = t(5),
        O = t.n(g),
        _ = { locale: "en-US", language: "English", code: "en" },
        A = { locale: "vi-VN", language: "Ti\u1ebfng Vi\u1ec7t", code: "vi" },
        C = {
          "ar-SA": {
            locale: "ar-SA",
            language: "\u0627\u0644\u0639\u0631\u0628\u064a\u0629",
            code: "ar",
          },
          "bn-BD": {
            locale: "bn-BD",
            language: "\u09ac\u09be\u0982\u09b2\u09be",
            code: "bn",
          },
          "en-US": _,
          "de-DE": { locale: "de-DE", language: "Deutsch", code: "de" },
          "el-GR": {
            locale: "el-GR",
            language: "\u0395\u03bb\u03bb\u03b7\u03bd\u03b9\u03ba\u03ac",
            code: "el",
          },
          "es-ES": { locale: "es-ES", language: "Espa\xf1ol", code: "es-ES" },
          "fi-FI": { locale: "fi-FI", language: "Suomalainen", code: "fi" },
          "fil-PH": { locale: "fil-PH", language: "Filipino", code: "fil" },
          "fr-FR": { locale: "fr-FR", language: "Fran\xe7ais", code: "fr" },
          "hi-IN": {
            locale: "hi-IN",
            language: "\u0939\u093f\u0902\u0926\u0940",
            code: "hi",
          },
          "hu-HU": { locale: "hu-HU", language: "Magyar", code: "hu" },
          "id-ID": {
            locale: "id-ID",
            language: "Bahasa Indonesia",
            code: "id",
          },
          "it-IT": { locale: "it-IT", language: "Italiano", code: "it" },
          "ja-JP": {
            locale: "ja-JP",
            language: "\u65e5\u672c\u8a9e",
            code: "ja",
          },
          "ko-KR": {
            locale: "ko-KR",
            language: "\ud55c\uad6d\uc5b4",
            code: "ko",
          },
          "nl-NL": { locale: "nl-NL", language: "Nederlands", code: "nl" },
          "pl-PL": { locale: "pl-PL", language: "Polski", code: "pl" },
          "pt-BR": {
            locale: "pt-BR",
            language: "Portugu\xeas (Brazil)",
            code: "pt-br",
          },
          "pt-PT": { locale: "pt-PT", language: "Portugu\xeas", code: "pt-pt" },
          "ro-RO": { locale: "ro-RO", language: "Rom\xe2n\u0103", code: "ro" },
          "ru-RU": {
            locale: "ru-RU",
            language: "\u0420\u0443\u0441\u0441\u043a\u0438\u0439",
            code: "ru",
          },
          "sv-SE": { locale: "sv-SE", language: "Svenska", code: "sv" },
          "ta-IN": {
            locale: "ta-IN",
            language: "\u0ba4\u0bae\u0bbf\u0bb4\u0bcd",
            code: "ta",
          },
          "tr-TR": { locale: "tr-TR", language: "T\xfcrk\xe7e", code: "tr" },
          "uk-UA": {
            locale: "uk-UA",
            language:
              "\u0423\u043a\u0440\u0430\u0457\u043d\u0441\u044c\u043a\u0430",
            code: "uk",
          },
          "vi-VN": A,
          "zh-CN": {
            locale: "zh-CN",
            language: "\u7b80\u4f53\u4e2d\u6587",
            code: "zh-cn",
          },
          "zh-TW": {
            locale: "zh-TW",
            language: "\u7e41\u9ad4\u4e2d\u6587",
            code: "zh-tw",
          },
        },
        v = (Object.values(C), "app_language"),
        E = t(352),
        w = t(353),
        P = t(1),
        M = { currentLanguage: A },
        R = new Map();
      R.set(_.locale, E), R.set(A.locale, w);
      var I = Object(s.createContext)(void 0),
        k = function (e) {
          var n = e.children,
            t = Object(s.useState)(function () {
              var e = (function () {
                try {
                  return localStorage.getItem(v) || _.locale;
                } catch (e) {
                  return _.locale;
                }
              })();
              return Object(h.a)(
                Object(h.a)({}, M),
                {},
                { currentLanguage: C[e] }
              );
            }),
            a = Object(j.a)(t, 2),
            i = a[0],
            r = a[1],
            o = i.currentLanguage,
            p = Object(s.useCallback)(
              (function () {
                var e = Object(x.a)(
                  O.a.mark(function e(n) {
                    return O.a.wrap(function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            R.has(n.locale),
                              localStorage.setItem(v, n.locale),
                              r(function (e) {
                                return Object(h.a)(
                                  Object(h.a)({}, e),
                                  {},
                                  { currentLanguage: n }
                                );
                              });
                          case 1:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                  })
                );
                return function (n) {
                  return e.apply(this, arguments);
                };
              })(),
              []
            ),
            u = Object(s.useCallback)(
              function (e, n) {
                var t,
                  a = R.has(o.locale) ? R.get(o.locale) : R.get(_.locale);
                if (a && (t = a[e] || e).match(/%\S+?%/gm) && n) {
                  var i = t;
                  return (
                    Object.keys(n).forEach(function (e) {
                      var t = new RegExp("%".concat(e, "%"), "g");
                      i = i.replace(t, n[e].toString());
                    }),
                    i
                  );
                }
                return t;
              },
              [o]
            );
          return Object(P.jsx)(I.Provider, {
            value: Object(h.a)(
              Object(h.a)({}, i),
              {},
              { setLanguage: p, t: u }
            ),
            children: n,
          });
        },
        N = function () {
          var e = Object(s.useContext)(I);
          if (void 0 === e) throw new Error("Language context is undefined");
          return e;
        },
        B = t(33),
        S = t(13),
        L = t(26),
        D = t(231),
        F = "IS_DARK";
      var U = Object(L.b)("global/updateVersion"),
        K = Object(L.b)("global/setGithubConfig"),
        W = {
          githubConfig: { airdropToken: void 0, whiteListAirdropToken: {} },
        },
        z = Object(L.c)(W, function (e) {
          return e.addCase(K, function (e, n) {
            var t = n.payload;
            e.githubConfig = t;
          });
        }),
        H = Object(L.b)("market/setNFTMarketToState"),
        Z = Object(L.c)(
          { nftMarket: { data: [], total: 0, page: 0 } },
          function (e) {
            return e.addCase(H, function (e, n) {
              var t = n.payload;
              e.nftMarket = t;
            });
          }
        ),
        V = Object(L.b)("market/setModalConnect"),
        G = Object(L.c)(
          { modalConnect: { toggle: !1, dataModal: null } },
          function (e) {
            return e.addCase(V, function (e, n) {
              var t = n.payload;
              e.modalConnect = t;
            });
          }
        ),
        Y = Object(L.b)("market/setNFTMarketToState"),
        J = Object(L.b)("assets/deleteItemMarket"),
        q = { nftMarket: { data: void 0, total: 0, page: 0 } },
        X = Object(L.c)(q, function (e) {
          return e
            .addCase(Y, function (e, n) {
              var t = n.payload;
              e.nftMarket = t;
            })
            .addCase(J, function (e, n) {
              var t = n.payload;
              if (e.nftMarket.data && t) {
                var a =
                  "object" ===
                  typeof (null === t || void 0 === t ? void 0 : t.items)
                    ? t.items
                    : [(null === t || void 0 === t ? void 0 : t.items) || t];
                e.nftMarket = Object(h.a)(
                  Object(h.a)({}, e.nftMarket),
                  {},
                  {
                    data: e.nftMarket.data.filter(function (e) {
                      return !a.includes(e.id);
                    }),
                  }
                );
              }
            });
        }),
        Q = Object(L.b)("market/setAuctionListToState"),
        $ = Object(L.b)("assets/deleteItemAuction"),
        ee = { lists: { data: void 0, total: 0, page: 0 } },
        ne = Object(L.c)(ee, function (e) {
          return e
            .addCase(Q, function (e, n) {
              var t = n.payload;
              e.lists = t;
            })
            .addCase($, function (e, n) {
              var t = n.payload;
              if (e.lists.data && t) {
                var a =
                  "object" ===
                  typeof (null === t || void 0 === t ? void 0 : t.items)
                    ? t.items
                    : [(null === t || void 0 === t ? void 0 : t.items) || t];
                e.lists = Object(h.a)(
                  Object(h.a)({}, e.lists),
                  {},
                  {
                    data: e.lists.data.filter(function (e) {
                      return !a.includes(e.id);
                    }),
                  }
                );
              }
            });
        }),
        te = Object(L.b)("assets/setAssetsListToStore"),
        ae = Object(L.b)("assets/deleteItemAsset"),
        ie = { lists: { data: void 0, total: 0, page: 0 } },
        se = Object(L.c)(ie, function (e) {
          return e
            .addCase(te, function (e, n) {
              var t = n.payload;
              e.lists = t;
            })
            .addCase(ae, function (e, n) {
              var t = n.payload;
              if (e.lists.data && t) {
                var a =
                  "object" ===
                  typeof (null === t || void 0 === t ? void 0 : t.items)
                    ? t.items
                    : [(null === t || void 0 === t ? void 0 : t.items) || t];
                e.lists = Object(h.a)(
                  Object(h.a)({}, e.lists),
                  {},
                  {
                    data: e.lists.data.filter(function (e) {
                      return !a.includes(e.id);
                    }),
                  }
                );
              }
            });
        }),
        re = Object(L.b)("wallet/setProfileWalletToState"),
        oe = { walletInfo: void 0 },
        pe = Object(L.c)(oe, function (e) {
          return e.addCase(re, function (e, n) {
            var t = n.payload;
            e.walletInfo = t;
          });
        }),
        ue = Object(L.b)("transactions/setTransactionHistoryData"),
        le = { txHistory: { data: void 0, page: 0, total: 0 } },
        ce = Object(L.c)(le, function (e) {
          return e.addCase(ue, function (e, n) {
            var t = n.payload;
            e.txHistory = t;
          });
        }),
        de = ["user"],
        ye = Object(D.load)({ states: de });
      ye.user &&
        (ye.user.userDarkMode = (function () {
          var e = null;
          try {
            var n = localStorage.getItem(F);
            n && (e = JSON.parse(n));
          } catch (t) {
            console.error("E0003", t);
          }
          return e;
        })());
      var me = Object(L.a)({
        reducer: {
          global: z,
          user: Z,
          modal: G,
          market: X,
          auction: ne,
          assets: se,
          wallet: pe,
          transactions: ce,
        },
        middleware: [].concat(Object(S.a)(Object(L.d)({ thunk: !1 })), [
          Object(D.save)({ states: de }),
        ]),
        preloadedState: ye,
      });
      me.dispatch(U());
      var be = me,
        fe = t(817);
      function Te(e) {
        var n = new fe.a(e);
        return (n.pollingInterval = 15e3), n;
      }
      var xe = { xs: 370, sm: 576, md: 768, lg: 992, xl: 1200, xxl: 1600 },
        he = {
          siteWidth: 1200,
          breakpoints: Object.values(xe).map(function (e) {
            return "".concat(e, "px");
          }),
          mediaQueries: {
            xs: "@media screen and (min-width: ".concat(xe.xs, "px)"),
            sm: "@media screen and (min-width: ".concat(xe.sm, "px)"),
            md: "@media screen and (min-width: ".concat(xe.md, "px)"),
            lg: "@media screen and (min-width: ".concat(xe.lg, "px)"),
            xl: "@media screen and (min-width: ".concat(xe.xl, "px)"),
            xxl: "@media screen and (min-width: ".concat(xe.xxl, "px)"),
          },
          spacing: [0, 4, 8, 16, 24, 32, 48, 64],
          shadows: {
            level1:
              "0px 2px 12px -8px rgba(25, 19, 38, 0.1), 0px 1px 1px rgba(25, 19, 38, 0.05)",
            active:
              "0px 0px 0px 1px #0098A1, 0px 0px 4px 8px rgba(31, 199, 212, 0.4)",
            success:
              "0px 0px 0px 1px #31D0AA, 0px 0px 0px 4px rgba(49, 208, 170, 0.2)",
            warning:
              "0px 0px 0px 1px #ED4B9E, 0px 0px 0px 4px rgba(237, 75, 158, 0.2)",
            focus:
              "0px 0px 0px 1px #7645D9, 0px 0px 0px 4px rgba(118, 69, 217, 0.6)",
            inset: "inset 0px 2px 2px -1px rgba(74, 74, 104, 0.1)",
          },
          radii: { small: "4px", default: "16px", card: "32px", circle: "50%" },
          zIndices: { dropdown: 10, modal: 100 },
        },
        je = {
          failure: "#ED4B9E",
          primary: "#ffffff",
          primaryBright: "#53DEE9",
          primaryDark: "#0098A1",
          secondary: "#A85F16",
          success: "#31D0AA",
          warning: "#ff4d4f",
        },
        ge = { binance: "#F0B90B" },
        Oe = Object(h.a)(
          Object(h.a)(Object(h.a)({}, je), ge),
          {},
          {
            background: "#10183D",
            backgroundDisabled: "#CDECF8",
            contrast: "#191326",
            invertedContrast: "#FFFFFF",
            input: "#CDECF8",
            inputSecondary: "#d7caec",
            tertiary: "#EFF4F5",
            text: "#ffffff",
            textGradient: "linear-gradient(190deg,#50E3C2 0%,#17B4EB 100%)",
            textDisabled: "#BDC2C4",
            textSubtle: "#B1AFCD",
            borderColor: "#E9EAEB",
            card: "#b3c7ff",
            gradient:
              "linear-gradient(90deg,#384cff 0%,#2486f9 0.01%,#3ddcec 100%)",
            gradients: {
              common: "#ffffff",
              bubblegum: "linear-gradient(139.73deg,#9df978 0%,#d5e8cd 100%)",
            },
          }
        ),
        _e = Object(h.a)(
          Object(h.a)(Object(h.a)({}, je), ge),
          {},
          {
            secondary: "#9A6AFF",
            background: "#10183D",
            backgroundDisabled: "#3c3742",
            contrast: "#FFFFFF",
            invertedContrast: "#191326",
            input: "#483f5a",
            inputSecondary: "#66578D",
            primaryDark: "#0098A1",
            tertiary: "#353547",
            text: "#EAE2FC",
            textGradient: "linear-gradient(190deg,#16B4EB 0%,#23E73C 100%)",
            textDisabled: "#666171",
            textSubtle: "#B1AFCD",
            borderColor: "#524B63",
            card: "#27262c",
            gradient:
              "linear-gradient(90deg,#384cff 0%,#2486f9 0.01%,#3ddcec 100%)",
            gradients: {
              common:
                "linear-gradient(90deg,#384cff 0%,#2486f9 0.01%,#3ddcec 100%)",
              bubblegum:
                "linear-gradient(90deg,#384cff 0%,#2486f9 0.01%,#3ddcec 100%)",
            },
          }
        ),
        Ae = { handleBackground: Oe.card },
        Ce = { handleBackground: _e.card },
        ve = Object(h.a)(
          Object(h.a)({}, he),
          {},
          { isDark: !0, colors: _e, radio: Ae }
        ),
        Ee = Object(h.a)(
          Object(h.a)({}, he),
          {},
          { isDark: !1, colors: Oe, radio: Ce }
        ),
        we = "IS_DARK",
        Pe = r.a.createContext({
          isDark: !1,
          toggleTheme: function () {
            return null;
          },
        }),
        Me = function (e) {
          var n = e.children,
            t = Object(s.useState)(function () {
              var e = localStorage.getItem(we);
              return !!e && JSON.parse(e);
            }),
            a = Object(j.a)(t, 2),
            i = a[0],
            r = a[1];
          return Object(P.jsx)(Pe.Provider, {
            value: {
              isDark: i,
              toggleTheme: function () {
                r(function (e) {
                  return localStorage.setItem(we, JSON.stringify(!e)), !e;
                });
              },
            },
            children: Object(P.jsx)(y.a, { theme: i ? ve : Ee, children: n }),
          });
        },
        Re = Object(f.c)(B.p),
        Ie = function (e) {
          var n = e.children;
          return Object(P.jsx)(f.b, {
            getLibrary: Te,
            children: Object(P.jsx)(Re, {
              getLibrary: Te,
              children: Object(P.jsx)(T.a, {
                store: be,
                children: Object(P.jsx)(Me, {
                  children: Object(P.jsx)(k, { children: n }),
                }),
              }),
            }),
          });
        },
        ke = t(20),
        Ne = t(40),
        Be = t(90),
        Se = t(96),
        Le = t(355),
        De = t.n(Le),
        Fe = t(191),
        Ue = t(192),
        Ke = t.n(Ue),
        We =
          (t(356),
          t(357),
          t(358),
          t(359),
          t(360),
          t(361),
          t(362),
          t(363),
          t(364),
          t(365));
      t(366);
      function ze() {
        return He.apply(this, arguments);
      }
      function He() {
        return (He = Object(x.a)(
          O.a.mark(function e() {
            return O.a.wrap(function (e) {
              for (;;)
                switch ((e.prev = e.next)) {
                  case 0:
                    if (!window.ethereum) {
                      e.next = 3;
                      break;
                    }
                    return (
                      (window.web3 = new Ke.a(window.ethereum)),
                      e.abrupt("return", !0)
                    );
                  case 3:
                    if (!window.web3) {
                      e.next = 6;
                      break;
                    }
                    return (
                      (window.web3 = new Ke.a(window.web3.currentProvider)),
                      e.abrupt("return", !0)
                    );
                  case 6:
                    if (!window.BinanceChain) {
                      e.next = 9;
                      break;
                    }
                    return (
                      (window.web3 = new Ke.a(window.BinanceChain)),
                      e.abrupt("return", !0)
                    );
                  case 9:
                    return e.abrupt("return", null);
                  case 10:
                  case "end":
                    return e.stop();
                }
            }, e);
          })
        )).apply(this, arguments);
      }
      function Ze(e) {
        return Ve.apply(this, arguments);
      }
      function Ve() {
        return (Ve = Object(x.a)(
          O.a.mark(function e(n) {
            var t, a, i, s;
            return O.a.wrap(function (e) {
              for (;;)
                switch ((e.prev = e.next)) {
                  case 0:
                    return (
                      (t = window),
                      (a = t.web3),
                      (e.next = 3),
                      a.eth.getBalance(n)
                    );
                  case 3:
                    return (i = e.sent), (e.next = 6), a.eth.net.getId();
                  case 6:
                    return (
                      (s = e.sent),
                      18,
                      e.abrupt("return", {
                        name: "BNB Token",
                        symbol: "BNB",
                        address: n,
                        balance: i,
                        chainId: s,
                        decimals: 18,
                      })
                    );
                  case 9:
                  case "end":
                    return e.stop();
                }
            }, e);
          })
        )).apply(this, arguments);
      }
      function Ge(e, n) {
        var t = window.web3;
        return Object(s.useMemo)(
          function () {
            if (null === t || void 0 === t || !t.eth || !e || !n) return null;
            try {
              return new t.eth.Contract(n, e);
            } catch (a) {
              return console.error("Failed to get contract", a), null;
            }
          },
          [t, e, n]
        );
      }
      function Ye(e, n) {
        return Ge(e || B.q, n || We);
      }
      var Je = function (e) {
        return new Promise(function (n) {
          return setTimeout(n, e);
        });
      };
      function qe(e, n, t) {
        return Xe.apply(this, arguments);
      }
      function Xe() {
        return (Xe = Object(x.a)(
          O.a.mark(function e(n, t, a) {
            return O.a.wrap(function (e) {
              for (;;)
                switch ((e.prev = e.next)) {
                  case 0:
                    return (
                      a || (a = {}),
                      e.abrupt(
                        "return",
                        new Promise(function (e, i) {
                          Object(x.a)(
                            O.a.mark(function s() {
                              var r, o, p;
                              return O.a.wrap(function (s) {
                                for (;;)
                                  switch ((s.prev = s.next)) {
                                    case 0:
                                      if (!n) {
                                        s.next = 11;
                                        break;
                                      }
                                      return (
                                        (s.next = 3),
                                        n.methods.balanceOf(t).call()
                                      );
                                    case 3:
                                      return (
                                        (r = s.sent),
                                        (s.next = 6),
                                        n.methods.decimals().call()
                                      );
                                    case 6:
                                      (o = s.sent),
                                        (p = new Fe.BigNumber(r)
                                          .shiftedBy(-o)
                                          .toNumber()),
                                        e(Object(h.a)({ balance: p }, a)),
                                        (s.next = 12);
                                      break;
                                    case 11:
                                      i(
                                        new Error(
                                          "Cannot read contract, please try again later."
                                        )
                                      );
                                    case 12:
                                    case "end":
                                      return s.stop();
                                  }
                              }, s);
                            })
                          )();
                        })
                      )
                    );
                  case 2:
                  case "end":
                    return e.stop();
                }
            }, e);
          })
        )).apply(this, arguments);
      }
      function Qe(e, n) {
        return $e.apply(this, arguments);
      }
      function $e() {
        return ($e = Object(x.a)(
          O.a.mark(function e(n, t) {
            return O.a.wrap(function (e) {
              for (;;)
                switch ((e.prev = e.next)) {
                  case 0:
                    return e.abrupt(
                      "return",
                      new Promise(function (e, a) {
                        Object(x.a)(
                          O.a.mark(function i() {
                            return O.a.wrap(function (i) {
                              for (;;)
                                switch ((i.prev = i.next)) {
                                  case 0:
                                    if (!n) {
                                      i.next = 5;
                                      break;
                                    }
                                    return (
                                      (i.next = 3),
                                      Promise.all([
                                        n.methods.balanceOf(t).call(),
                                        n.methods.symbol().call(),
                                        n.methods.name().call(),
                                        n.methods.decimals().call(),
                                      ])
                                        .then(function (t) {
                                          var a = Object(j.a)(t, 4),
                                            i = a[0],
                                            s = a[1],
                                            r = a[2],
                                            o = a[3],
                                            p = {
                                              name: r,
                                              symbol: s,
                                              decimals: o,
                                              chainId: 56,
                                              balance: new Fe.BigNumber(i)
                                                .shiftedBy(-o)
                                                .toNumber(),
                                              address: n._address,
                                            };
                                          e(p);
                                        })
                                        .catch(a)
                                    );
                                  case 3:
                                    i.next = 6;
                                    break;
                                  case 5:
                                    a(
                                      new Error(
                                        "Cannot read contract, please try again later."
                                      )
                                    );
                                  case 6:
                                  case "end":
                                    return i.stop();
                                }
                            }, i);
                          })
                        )();
                      })
                    );
                  case 1:
                  case "end":
                    return e.stop();
                }
            }, e);
          })
        )).apply(this, arguments);
      }
      function en() {
        var e = Object(T.b)(),
          n = Object(f.d)().account,
          t = Object(s.useReducer)(function (e) {
            return e + 1;
          }, 0),
          a = Object(j.a)(t, 2)[1],
          i = Object(s.useState)(!1),
          r = Object(j.a)(i, 2),
          o = r[0],
          p = r[1],
          u = Ye(B.b.address),
          l = Ye(B.c.address),
          c = Ye(B.a.address),
          d = Object(s.useCallback)(
            Object(x.a)(
              O.a.mark(function t() {
                var i, s, r, o, p;
                return O.a.wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (null !== u && void 0 !== u && u.methods) {
                            t.next = 4;
                            break;
                          }
                          return a(), (t.next = 4), Je(1e3);
                        case 4:
                          if (!n || !u) {
                            t.next = 25;
                            break;
                          }
                          return (t.prev = 5), (t.next = 8), Ze(n);
                        case 8:
                          return (i = t.sent), (t.next = 11), Qe(u, n);
                        case 11:
                          return (s = t.sent), (t.next = 14), qe(l, n, B.c);
                        case 14:
                          return (r = t.sent), (t.next = 17), qe(c, n, B.a);
                        case 17:
                          (o = t.sent),
                            (p = Object(h.a)(
                              Object(h.a)({}, i),
                              {},
                              {
                                balance: new Fe.BigNumber(i.balance)
                                  .shiftedBy(-18)
                                  .toNumber(),
                                baseToken: s,
                                assets: [s, r, o],
                              }
                            )),
                            e(re(p)),
                            (t.next = 25);
                          break;
                        case 22:
                          (t.prev = 22),
                            (t.t0 = t.catch(5)),
                            console.error("E0001", t.t0);
                        case 25:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  null,
                  [[5, 22]]
                );
              })
            ),
            [n, u, c, l, e]
          ),
          y = Object(s.useCallback)(
            Object(x.a)(
              O.a.mark(function e() {
                return O.a.wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (ze()) {
                          e.next = 7;
                          break;
                        }
                        return a(), (e.next = 5), Je(1e3);
                      case 5:
                        e.next = 8;
                        break;
                      case 7:
                        p(!0);
                      case 8:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            ),
            []
          );
        Object(s.useEffect)(
          function () {
            o ? d() : y();
          },
          [y, o]
        ),
          (function (e, n) {
            var t =
                !(arguments.length > 2 && void 0 !== arguments[2]) ||
                arguments[2],
              a = Object(s.useRef)();
            Object(s.useEffect)(
              function () {
                a.current = e;
              },
              [e]
            ),
              Object(s.useEffect)(
                function () {
                  function e() {
                    var e = a.current;
                    e && e();
                  }
                  if (null !== n) {
                    t && e();
                    var i = setInterval(e, n);
                    return function () {
                      return clearInterval(i);
                    };
                  }
                },
                [n, t]
              );
          })(
            Object(x.a)(
              O.a.mark(function e() {
                return O.a.wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        o && d();
                      case 1:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            ),
            7e3
          );
      }
      var nn,
        tn,
        an = t(7),
        sn = t(145),
        rn = t(146),
        on = t(367),
        pn = t(176),
        un = t(368),
        ln = t(11),
        cn = t(10),
        dn = t(14),
        yn = t(15),
        mn = t(383),
        bn = t(77),
        fn = t(37),
        Tn = (function (e) {
          Object(dn.a)(t, e);
          var n = Object(yn.a)(t);
          function t(e, a, i) {
            var s;
            return (
              Object(cn.a)(this, t),
              ((s = n.call(this, e)).code = a),
              (s.data = i),
              s
            );
          }
          return Object(ln.a)(t);
        })(Object(mn.a)(Error)),
        xn = Object(ln.a)(function e(n, t, a) {
          var i = this;
          Object(cn.a)(this, e),
            (this.isMetaMask = !1),
            (this.chainId = void 0),
            (this.url = void 0),
            (this.host = void 0),
            (this.path = void 0),
            (this.batchWaitTimeMs = void 0),
            (this.nextId = 1),
            (this.batchTimeoutId = null),
            (this.batch = []),
            (this.clearBatch = Object(x.a)(
              O.a.mark(function e() {
                var n, t, a, s, r, o, p, u, l, c, d, y, m, b;
                return O.a.wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (n = i.batch),
                            (i.batch = []),
                            (i.batchTimeoutId = null),
                            (e.prev = 3),
                            (e.next = 6),
                            fetch(i.url, {
                              method: "POST",
                              headers: {
                                "content-type": "application/json",
                                accept: "application/json",
                              },
                              body: JSON.stringify(
                                n.map(function (e) {
                                  return e.request;
                                })
                              ),
                            })
                          );
                        case 6:
                          (t = e.sent), (e.next = 13);
                          break;
                        case 9:
                          return (
                            (e.prev = 9),
                            (e.t0 = e.catch(3)),
                            n.forEach(function (e) {
                              return (0,
                              e.reject)(new Error("Failed to send batch call"));
                            }),
                            e.abrupt("return")
                          );
                        case 13:
                          if (t.ok) {
                            e.next = 16;
                            break;
                          }
                          return (
                            n.forEach(function (e) {
                              return (0,
                              e.reject)(new Tn("".concat(t.status, ": ").concat(t.statusText), -32e3));
                            }),
                            e.abrupt("return")
                          );
                        case 16:
                          return (e.prev = 16), (e.next = 19), t.json();
                        case 19:
                          (a = e.sent), (e.next = 26);
                          break;
                        case 22:
                          return (
                            (e.prev = 22),
                            (e.t1 = e.catch(16)),
                            n.forEach(function (e) {
                              return (0,
                              e.reject)(new Error("Failed to parse JSON response"));
                            }),
                            e.abrupt("return")
                          );
                        case 26:
                          (s = n.reduce(function (e, n) {
                            return (e[n.request.id] = n), e;
                          }, {})),
                            (r = Object(un.a)(a));
                          try {
                            for (r.s(); !(o = r.n()).done; )
                              (p = o.value),
                                (u = s[p.id]),
                                (l = u.resolve),
                                (c = u.reject),
                                (d = u.request.method),
                                "error" in p
                                  ? c(
                                      new Tn(
                                        null === p ||
                                        void 0 === p ||
                                        null === (y = p.error) ||
                                        void 0 === y
                                          ? void 0
                                          : y.message,
                                        null === p ||
                                        void 0 === p ||
                                        null === (m = p.error) ||
                                        void 0 === m
                                          ? void 0
                                          : m.code,
                                        null === p ||
                                        void 0 === p ||
                                        null === (b = p.error) ||
                                        void 0 === b
                                          ? void 0
                                          : b.data
                                      )
                                    )
                                  : "result" in p
                                  ? l(p.result)
                                  : c(
                                      new Tn(
                                        "Received unexpected JSON-RPC response to ".concat(
                                          d,
                                          " request."
                                        ),
                                        -32e3,
                                        p
                                      )
                                    );
                          } catch (f) {
                            r.e(f);
                          } finally {
                            r.f();
                          }
                        case 29:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  null,
                  [
                    [3, 9],
                    [16, 22],
                  ]
                );
              })
            )),
            (this.sendAsync = function (e, n) {
              i.request(e.method, e.params)
                .then(function (t) {
                  return n(null, { jsonrpc: "2.0", id: e.id, result: t });
                })
                .catch(function (e) {
                  return n(e, null);
                });
            }),
            (this.request = (function () {
              var e = Object(x.a)(
                O.a.mark(function e(n, t) {
                  var a, s;
                  return O.a.wrap(function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if ("string" === typeof n) {
                            e.next = 2;
                            break;
                          }
                          return e.abrupt(
                            "return",
                            i.request(n.method, n.params)
                          );
                        case 2:
                          if ("eth_chainId" !== n) {
                            e.next = 4;
                            break;
                          }
                          return e.abrupt(
                            "return",
                            "0x".concat(i.chainId.toString(16))
                          );
                        case 4:
                          return (
                            (s = new Promise(function (e, a) {
                              i.batch.push({
                                request: {
                                  jsonrpc: "2.0",
                                  id: i.nextId++,
                                  method: n,
                                  params: t,
                                },
                                resolve: e,
                                reject: a,
                              });
                            })),
                            (i.batchTimeoutId =
                              null !== (a = i.batchTimeoutId) && void 0 !== a
                                ? a
                                : setTimeout(i.clearBatch, i.batchWaitTimeMs)),
                            e.abrupt("return", s)
                          );
                        case 7:
                        case "end":
                          return e.stop();
                      }
                  }, e);
                })
              );
              return function (n, t) {
                return e.apply(this, arguments);
              };
            })()),
            (this.chainId = n),
            (this.url = t);
          var s = new URL(t);
          (this.host = s.host),
            (this.path = s.pathname),
            (this.batchWaitTimeMs = null !== a && void 0 !== a ? a : 50);
        }),
        hn = (function (e) {
          Object(dn.a)(t, e);
          var n = Object(yn.a)(t);
          function t(e) {
            var a,
              i = e.urls,
              s = e.defaultChainId;
            return (
              Object(cn.a)(this, t),
              Object(fn.a)(
                s || 1 === Object.keys(i).length,
                "defaultChainId is a required argument with >1 url"
              ),
              ((a = n.call(this, {
                supportedChainIds: Object.keys(i).map(function (e) {
                  return Number(e);
                }),
              })).providers = void 0),
              (a.currentChainId = void 0),
              (a.currentChainId = s || Number(Object.keys(i)[0])),
              (a.providers = Object.keys(i).reduce(function (e, n) {
                return (e[Number(n)] = new xn(Number(n), i[Number(n)])), e;
              }, {})),
              a
            );
          }
          return (
            Object(ln.a)(t, [
              {
                key: "provider",
                get: function () {
                  return this.providers[this.currentChainId];
                },
              },
              {
                key: "activate",
                value: (function () {
                  var e = Object(x.a)(
                    O.a.mark(function e() {
                      return O.a.wrap(
                        function (e) {
                          for (;;)
                            switch ((e.prev = e.next)) {
                              case 0:
                                return e.abrupt("return", {
                                  provider: this.providers[this.currentChainId],
                                  chainId: this.currentChainId,
                                  account: null,
                                });
                              case 1:
                              case "end":
                                return e.stop();
                            }
                        },
                        e,
                        this
                      );
                    })
                  );
                  return function () {
                    return e.apply(this, arguments);
                  };
                })(),
              },
              {
                key: "getProvider",
                value: (function () {
                  var e = Object(x.a)(
                    O.a.mark(function e() {
                      return O.a.wrap(
                        function (e) {
                          for (;;)
                            switch ((e.prev = e.next)) {
                              case 0:
                                return e.abrupt(
                                  "return",
                                  this.providers[this.currentChainId]
                                );
                              case 1:
                              case "end":
                                return e.stop();
                            }
                        },
                        e,
                        this
                      );
                    })
                  );
                  return function () {
                    return e.apply(this, arguments);
                  };
                })(),
              },
              {
                key: "getChainId",
                value: (function () {
                  var e = Object(x.a)(
                    O.a.mark(function e() {
                      return O.a.wrap(
                        function (e) {
                          for (;;)
                            switch ((e.prev = e.next)) {
                              case 0:
                                return e.abrupt("return", this.currentChainId);
                              case 1:
                              case "end":
                                return e.stop();
                            }
                        },
                        e,
                        this
                      );
                    })
                  );
                  return function () {
                    return e.apply(this, arguments);
                  };
                })(),
              },
              {
                key: "getAccount",
                value: (function () {
                  var e = Object(x.a)(
                    O.a.mark(function e() {
                      return O.a.wrap(function (e) {
                        for (;;)
                          switch ((e.prev = e.next)) {
                            case 0:
                              return e.abrupt("return", null);
                            case 1:
                            case "end":
                              return e.stop();
                          }
                      }, e);
                    })
                  );
                  return function () {
                    return e.apply(this, arguments);
                  };
                })(),
              },
              {
                key: "deactivate",
                value: function () {
                  return null;
                },
              },
            ]),
            t
          );
        })(bn.AbstractConnector),
        jn = "connecterId";
      !(function (e) {
        (e.Injected = "injected"),
          (e.WalletConnect = "walletconnect"),
          (e.BSC = "bsc");
      })(tn || (tn = {}));
      var gn = "https://bsc-dataseed.binance.org/",
        On = parseInt(("56", "56"));
      var _n = new hn({ urls: Object(an.a)({}, On, gn) });
      var An = new sn.a({ supportedChainIds: [56, 97] }),
        Cn = new pn.BscConnector({ supportedChainIds: [56] }),
        vn = new rn.b({
          rpc: Object(an.a)({}, On, gn),
          bridge: "https://bridge.walletconnect.org",
          qrcode: !0,
        }),
        En =
          (new on.a({
            url: gn,
            appName: "Uniswap",
            appLogoUrl:
              "https://mpng.pngfly.com/20181202/bex/kisspng-emoji-domain-unicorn-pin-badges-sticker-unicorn-tumblr-emoji-unicorn-iphoneemoji-5c046729264a77.5671679315437924251569.jpg",
          }),
          (nn = {}),
          Object(an.a)(nn, tn.Injected, An),
          Object(an.a)(nn, tn.WalletConnect, vn),
          Object(an.a)(nn, tn.BSC, Cn),
          nn),
        wn = function () {
          var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : 575,
            n = Object(s.useState)(function () {
              return window.matchMedia("(max-width: ".concat(e, "px)")).matches;
            }),
            t = Object(j.a)(n, 2),
            a = t[0],
            i = t[1];
          return (
            Object(s.useEffect)(
              function () {
                function n() {
                  var n = window.matchMedia("(max-width: ".concat(e, "px)")),
                    t = function (e) {
                      i(e.matches);
                    };
                  return (
                    n.addEventListener && n.addEventListener("change", t),
                    function () {
                      n.removeEventListener &&
                        n.removeEventListener("change", t);
                    }
                  );
                }
                return (
                  n(),
                  function () {
                    n();
                  }
                );
              },
              [e]
            ),
            a
          );
        };
      var Pn,
        Mn,
        Rn,
        In,
        kn = ["size", "stroke"],
        Nn = Object(y.e)(
          Pn ||
            (Pn = Object(d.a)([
              "\n  from {\n    transform: rotate(0deg);\n  }\n  to {\n    transform: rotate(360deg);\n  }\n",
            ]))
        ),
        Bn = y.d.svg(
          Mn ||
            (Mn = Object(d.a)([
              "\n  animation: 2s ",
              " linear infinite;\n  height: ",
              ";\n  width: ",
              ";\n  path {\n    stroke: ",
              ";\n  }\n",
            ])),
          Nn,
          function (e) {
            return e.size;
          },
          function (e) {
            return e.size;
          },
          function (e) {
            var n = e.stroke,
              t = e.theme;
            return null !== n && void 0 !== n ? n : t.colors.primary;
          }
        );
      function Sn(e) {
        var n = e.size,
          t = void 0 === n ? "16px" : n,
          a = e.stroke,
          i = Object(ke.a)(e, kn);
        return Object(P.jsx)(
          Bn,
          Object(h.a)(
            Object(h.a)(
              {
                viewBox: "0 0 24 24",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                size: t,
                stroke: a,
              },
              i
            ),
            {},
            {
              children: Object(P.jsx)("path", {
                d: "M12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 9.27455 20.9097 6.80375 19.1414 5",
                strokeWidth: "2.5",
                strokeLinecap: "round",
                strokeLinejoin: "round",
              }),
            }
          )
        );
      }
      var Ln = y.d.div(
          Rn ||
            (Rn = Object(d.a)([
              "\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  height: 20rem;\n",
            ]))
        ),
        Dn = y.d.h2(
          In || (In = Object(d.a)(["\n  color: ", ";\n"])),
          function (e) {
            return e.theme.colors.primaryDark;
          }
        );
      function Fn(e) {
        var n = e.children,
          t = N().t,
          a = Object(f.d)().active,
          i = Object(f.d)(B.p),
          r = i.active,
          o = i.error,
          p = i.activate,
          u = (function () {
            var e = Object(f.d)(),
              n = e.activate,
              t = e.active,
              a = wn(),
              i = Object(s.useState)(!1),
              r = Object(j.a)(i, 2),
              o = r[0],
              p = r[1];
            return (
              Object(s.useEffect)(
                function () {
                  An.isAuthorized().then(function (e) {
                    var t = window.localStorage.getItem(jn);
                    (e && t) || (a && window.ethereum && t)
                      ? n(An, void 0, !0).catch(function () {
                          p(!0);
                        })
                      : p(!0);
                  });
                },
                [n, a]
              ),
              Object(s.useEffect)(
                function () {
                  t && p(!0);
                },
                [t]
              ),
              o
            );
          })();
        Object(s.useEffect)(
          function () {
            !u || r || o || a || p(_n);
          },
          [u, r, o, p, a]
        ),
          (function () {
            var e =
                arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
              n = Object(f.d)(),
              t = n.active,
              a = n.error,
              i = n.activate;
            Object(s.useEffect)(
              function () {
                var n = window.ethereum;
                if (n && n.on && !t && !a && !e) {
                  var s = function () {
                      i(An, void 0, !0).catch(function (e) {
                        console.error(
                          "Failed to activate after chain changed",
                          e
                        );
                      });
                    },
                    r = function (e) {
                      e.length > 0 &&
                        i(An, void 0, !0).catch(function (e) {
                          console.error(
                            "Failed to activate after accounts changed",
                            e
                          );
                        });
                    };
                  return (
                    n.on("chainChanged", s),
                    n.on("accountsChanged", r),
                    function () {
                      n.removeListener &&
                        (n.removeListener("chainChanged", s),
                        n.removeListener("accountsChanged", r));
                    }
                  );
                }
              },
              [t, a, e, i]
            );
          })(!u);
        var l = Object(s.useState)(!1),
          c = Object(j.a)(l, 2),
          d = c[0],
          y = c[1];
        return (
          Object(s.useEffect)(function () {
            var e = setTimeout(function () {
              y(!0);
            }, 600);
            return function () {
              clearTimeout(e);
            };
          }, []),
          u
            ? !a && o
              ? Object(P.jsx)(Ln, {
                  children: Object(P.jsx)(Dn, { children: t("unknownError") }),
                })
              : a || r
              ? n
              : d
              ? Object(P.jsx)(Ln, { children: Object(P.jsx)(Sn, {}) })
              : null
            : null
        );
      }
      var Un,
        Kn = t(819),
        Wn = t(822),
        zn = t(823),
        Hn = function () {
          var e = Object(f.d)(),
            n = e.activate,
            t = e.deactivate,
            a = Object(s.useCallback)(function (e) {
              var t = En[e];
              t
                ? n(
                    t,
                    (function () {
                      var e = Object(x.a)(
                        O.a.mark(function e(n) {
                          return O.a.wrap(function (e) {
                            for (;;)
                              switch ((e.prev = e.next)) {
                                case 0:
                                  window.localStorage.removeItem(jn),
                                    n instanceof f.a
                                      ? Se.b.error("Unsupported Chain Id")
                                      : n instanceof sn.b ||
                                        n instanceof pn.NoBscProviderError
                                      ? Se.b.error(
                                          "Provider Error, No provider was found"
                                        )
                                      : n instanceof sn.c || n instanceof rn.a
                                      ? (t instanceof rn.b &&
                                          (t.walletConnectProvider = void 0),
                                        Se.b.error(
                                          "Authorization Error, Please authorize to access your account"
                                        ))
                                      : Se.b.error(n.name + n.message);
                                case 2:
                                case "end":
                                  return e.stop();
                              }
                          }, e);
                        })
                      );
                      return function (n) {
                        return e.apply(this, arguments);
                      };
                    })()
                  )
                : Se.b.error(
                    "Can't find connector, The connector config is wrong"
                  );
            }, []);
          return {
            login: a,
            logout: Object(s.useCallback)(
              function () {
                window.localStorage.removeItem(jn), t();
              },
              [t]
            ),
          };
        },
        Zn = t(815),
        Vn = [
          "loading",
          "disabled",
          "background",
          "onClick",
          "disableHover",
          "children",
        ],
        Gn = y.d.button(
          Un ||
            (Un = Object(d.a)([
              "\n  padding: 10px 24px;\n  border: unset;\n  cursor: pointer;\n  background: linear-gradient(99.46deg, #fa00ff -10.9%, #00e0ff 97.13%, #2ad4f9 97.14%);\n  border-radius: 12px;\n  position: relative;\n  font-size: 14px;\n\n  &:disabled {\n    filter: grayscale(100%);\n  }\n\n  & > div {\n    font-style: normal;\n    font-weight: 600;\n    font-size: 14px;\n    line-height: 150%;\n    color: #ffffff;\n\n    @media (min-width: 991px) {\n      font-size: 16px;\n      line-height: 24px;\n    }\n  }\n\n  &[data-hover='true'],\n  &[data-loading='true'] {\n    cursor: default;\n  }\n\n  .ant-spin {\n    position: absolute;\n    top: 50%;\n    left: 50%;\n    transform: translate(-50%, -50%);\n  }\n\n  &[disabled],\n  &[disabled='true'] {\n    cursor: not-allowed;\n  }\n",
            ]))
        ),
        Yn = function (e) {
          var n = e.loading,
            t = e.disabled,
            a = e.background,
            i = e.onClick,
            s = e.disableHover,
            r = e.children,
            o = Object(ke.a)(e, Vn);
          return Object(P.jsxs)(
            Gn,
            Object(h.a)(
              Object(h.a)(
                {
                  type: "button",
                  background: a,
                  "data-loading": n.toString(),
                  "data-hover": s.toString(),
                  disabled: t,
                  onClick: function () {
                    n || t || !i || i();
                  },
                },
                o
              ),
              {},
              {
                children: [
                  Object(P.jsx)("div", { children: r }),
                  n && Object(P.jsx)(Zn.a, { spinning: !0 }),
                ],
              }
            )
          );
        };
      Yn.defaultProps = { loading: !1, disabled: !1, disableHover: !1 };
      var Jn,
        qn,
        Xn,
        Qn = Yn,
        $n = t(42),
        et = y.d.div(
          Jn ||
            (Jn = Object(d.a)(["\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n"])),
          $n.a,
          $n.b,
          $n.d,
          $n.e,
          $n.f
        ),
        nt =
          (Object(y.d)(et)(
            qn || (qn = Object(d.a)(["\n  display: flex;\n  ", "\n"])),
            $n.c
          ),
          "sm"),
        tt = "md",
        at = function (e) {
          return e.scale === nt ? "24px" : "28px";
        },
        it = y.d.input.attrs({ border: 1, checkedWidth: 4, type: "checkbox" })(
          Xn ||
            (Xn = Object(d.a)([
              "\n  appearance: none;\n  display: flex;\n  align-items: center;\n  width: 24px;\n  height: 24px;\n  min-width: 24px;\n  min-height: 24px;\n\n  position: relative;\n  padding: 30% 2em;\n  box-sizing: border-box;\n\n  color: #fff;\n  background: #19183e;\n  background-clip: padding-box;\n  border: ",
              "px solid transparent;\n  border-radius: 5px;\n  cursor: pointer;\n  transition: background-color 0.2s ease-in-out;\n\n  &:before {\n    content: '';\n    position: absolute;\n    top: 0;\n    right: 0;\n    bottom: 0;\n    left: 0;\n    z-index: -1;\n    margin: -",
              "px;\n    border-radius: inherit;\n    background: #424082;\n  }\n\n  &:after {\n    content: '';\n    position: absolute;\n    border-bottom: ",
              "px solid;\n    border-left: ",
              "px solid;\n    border-color: transparent;\n    top: 27%;\n    left: 2%;\n    right: 0;\n    width: 60%;\n    height: 36%;\n    margin: auto;\n    transform: rotate(-50deg);\n    transition: border-color 0.2s ease-in-out;\n  }\n\n  &:checked {\n    &:before {\n      background: ",
              ";\n    }\n    &:after {\n      border-color: #51fbff;\n    }\n  }\n\n  &:disabled {\n    cursor: default;\n    opacity: 0.6;\n  }\n\n  ",
              " {\n    width: ",
              ";\n    height: ",
              ";\n    min-width: ",
              ";\n    min-height: ",
              ";\n  }\n",
            ])),
          function (e) {
            return e.border;
          },
          function (e) {
            return e.border;
          },
          function (e) {
            return e.checkedWidth;
          },
          function (e) {
            return e.checkedWidth;
          },
          function (e) {
            return e.theme.colors.textGradient;
          },
          function (e) {
            return e.theme.mediaQueries.sm;
          },
          at,
          at,
          at,
          at
        );
      it.defaultProps = { scale: tt };
      var st,
        rt = "sm",
        ot = "md",
        pt = function (e) {
          return e.scale === rt ? "24px" : "32px";
        },
        ut = function (e) {
          return e.scale === rt ? "12px" : "20px";
        },
        lt = y.d.input.attrs({ type: "radio" })(
          st ||
            (st = Object(d.a)([
              "\n  appearance: none;\n  overflow: hidden;\n  cursor: pointer;\n  position: relative;\n  display: inline-block;\n  height: ",
              ";\n  width: ",
              ";\n  vertical-align: middle;\n  transition: background-color 0.2s ease-in-out;\n  border: 0;\n  border-radius: 50%;\n  background-color: ",
              ";\n  box-shadow: ",
              ";\n\n  &:after {\n    border-radius: 50%;\n    content: '';\n    height: ",
              ";\n    left: 6px;\n    position: absolute;\n    top: 6px;\n    width: ",
              ";\n  }\n\n  &:hover:not(:disabled):not(:checked) {\n    box-shadow: ",
              ";\n  }\n\n  &:focus {\n    outline: none;\n    box-shadow: ",
              ";\n  }\n\n  &:checked {\n    background-color: ",
              ";\n    &:after {\n      background-color: ",
              ";\n    }\n  }\n\n  &:disabled {\n    cursor: default;\n    opacity: 0.6;\n  }\n  ",
              "\n",
            ])),
          pt,
          pt,
          function (e) {
            return e.theme.colors.input;
          },
          function (e) {
            return e.theme.shadows.inset;
          },
          ut,
          ut,
          function (e) {
            return e.theme.shadows.focus;
          },
          function (e) {
            return e.theme.shadows.focus;
          },
          function (e) {
            return e.theme.colors.success;
          },
          function (e) {
            return e.theme.radio.handleBackground;
          },
          $n.f
        );
      lt.defaultProps = { scale: ot, m: 0 };
      var ct,
        dt,
        yt,
        mt = t(370),
        bt = t.n(mt),
        ft = function (e, n) {
          return function (t) {
            return bt()(t, e, n);
          };
        },
        Tt = Object(y.e)(
          ct ||
            (ct = Object(d.a)([
              "\n  from {\n    transform: rotate(0deg);\n  } \n  to {\n    transform: rotate(360deg);\n  }\n",
            ]))
        ),
        xt = Object(y.c)(
          dt ||
            (dt = Object(d.a)(["\n  animation: ", " 2s linear infinite;\n"])),
          Tt
        ),
        ht = y.d.svg(
          yt ||
            (yt = Object(d.a)([
              "\n  fill: ",
              ";\n  flex-shrink: 0;\n\n  ",
              "\n  ",
              "\n",
            ])),
          function (e) {
            var n = e.theme,
              t = e.color;
            return ft("colors.".concat(t), t)(n);
          },
          function (e) {
            return e.spin && xt;
          },
          $n.f
        );
      ht.defaultProps = {
        color: "text",
        width: "20px",
        xmlns: "http://www.w3.org/2000/svg",
        spin: !1,
      };
      var jt,
        gt = ht,
        Ot = function (e) {
          return Object(P.jsx)(
            gt,
            Object(h.a)(
              Object(h.a)({ viewBox: "0 0 24 24" }, e),
              {},
              {
                children: Object(P.jsx)("path", {
                  d: "M15 1H4C2.9 1 2 1.9 2 3V16C2 16.55 2.45 17 3 17C3.55 17 4 16.55 4 16V4C4 3.45 4.45 3 5 3H15C15.55 3 16 2.55 16 2C16 1.45 15.55 1 15 1ZM19 5H8C6.9 5 6 5.9 6 7V21C6 22.1 6.9 23 8 23H19C20.1 23 21 22.1 21 21V7C21 5.9 20.1 5 19 5ZM18 21H9C8.45 21 8 20.55 8 20V8C8 7.45 8.45 7 9 7H18C18.55 7 19 7.45 19 8V20C19 20.55 18.55 21 18 21Z",
                }),
              }
            )
          );
        },
        _t = y.d.div(
          jt ||
            (jt = Object(d.a)([
              "\n  color: ",
              ";\n  font-size: ",
              ";\n  font-weight: ",
              ";\n  line-height: 1.5;\n  ",
              "\n  ",
              "\n  ",
              "\n",
            ])),
          function (e) {
            var n = e.color,
              t = e.theme;
            return ft("colors.".concat(n), n)(t);
          },
          function (e) {
            var n = e.fontSize;
            return e.small ? "14px" : n || "16px";
          },
          function (e) {
            return e.bold ? 600 : 400;
          },
          function (e) {
            var n = e.textTransform;
            return n && "text-transform: ".concat(n, ";");
          },
          $n.f,
          $n.g
        );
      _t.defaultProps = { color: "text", small: !1 };
      var At,
        Ct = _t,
        vt = y.d.div(
          At ||
            (At = Object(d.a)([
              "\n  background-image: ",
              ";\n  background-size: 100%;\n  background-repeat: repeat;\n  -webkit-background-clip: text;\n  -moz-background-clip: text;\n  -webkit-text-fill-color: transparent;\n  -moz-text-fill-color: transparent;\n\n  font-size: ",
              ";\n  font-weight: ",
              ";\n  margin: auto 0;\n  line-height: 120%;\n\n  ",
              "\n  ",
              "\n  ",
              "\n",
            ])),
          function (e) {
            var n = e.color,
              t = e.theme;
            return ft("colors.".concat(n), n)(t);
          },
          function (e) {
            var n = e.fontSize;
            return e.small ? "14px" : n || "16px";
          },
          function (e) {
            return e.bold ? 600 : 400;
          },
          function (e) {
            var n = e.textTransform;
            return n && "text-transform: ".concat(n, ";");
          },
          $n.f,
          $n.g
        );
      vt.defaultProps = { color: "textGradient", small: !1 };
      Object(y.d)(Ct)(
        Et ||
          (Et = Object(d.a)([
            "\n  display: flex;\n  align-items: center;\n  width: fit-content;\n  &:hover {\n    text-decoration: underline;\n  }\n",
          ]))
      );
      var Et,
        wt,
        Pt,
        Mt,
        Rt,
        It,
        kt,
        Nt,
        Bt,
        St,
        Lt,
        Dt,
        Ft,
        Ut,
        Kt,
        Wt,
        zt,
        Ht,
        Zt,
        Vt,
        Gt = "circle",
        Yt = Object(y.e)(
          wt ||
            (wt = Object(d.a)([
              "\n   from {\n        left: -150px;\n    }\n    to   {\n        left: 100%;\n    }\n",
            ]))
        ),
        Jt = Object(y.e)(
          Pt ||
            (Pt = Object(d.a)([
              "\n  0% {\n    opacity: 1;\n  } \n  50% {\n    opacity: 0.4;\n  }\n  100% {\n    opacity: 1;\n  }\n",
            ]))
        ),
        qt = y.d.div(
          Mt ||
            (Mt = Object(d.a)([
              "\n  min-height: 20px;\n  display: block;\n  background-color: ",
              ";\n  border-radius: ",
              ";\n\n  ",
              "\n  ",
              "\n",
            ])),
          function (e) {
            return e.theme.colors.backgroundDisabled;
          },
          function (e) {
            var n = e.variant,
              t = e.theme;
            return n === Gt ? t.radii.circle : t.radii.small;
          },
          $n.d,
          $n.f
        ),
        Xt =
          (Object(y.d)(qt)(
            Rt ||
              (Rt = Object(d.a)([
                "\n  animation: ",
                " 2s infinite ease-out;\n  transform: translate3d(0, 0, 0);\n",
              ])),
            Jt
          ),
          Object(y.d)(qt)(
            It ||
              (It = Object(d.a)([
                "\n  position: relative;\n  overflow: hidden;\n  transform: translate3d(0, 0, 0);\n  &:before {\n    content: '';\n    position: absolute;\n    background-image: linear-gradient(90deg, transparent, rgba(243, 243, 243, 0.5), transparent);\n    top: 0;\n    left: -150px;\n    height: 100%;\n    width: 150px;\n    animation: ",
                " 2s cubic-bezier(0.4, 0, 0.2, 1) infinite;\n  }\n",
              ])),
            Yt
          ),
          "sm"),
        Qt = "md",
        $t = "lg",
        ea = function (e) {
          var n = e.scale;
          switch (void 0 === n ? Qt : n) {
            case Xt:
              return "20px";
            case Qt:
              return "28px";
            case $t:
              return "42px";
            default:
              return "28px";
          }
        },
        na =
          (y.d.div(
            kt ||
              (kt = Object(d.a)([
                "\n  font-size: 16px;\n  color: ",
                ";\n\n  display: flex;\n  align-items: center;\n  flex-direction: row;\n  flex-wrap: nowrap;\n\n  width: 100%;\n  padding: 4px 12px;\n  border: 2px solid #ffa802;\n  border-radius: 5px;\n  box-shadow: ",
                ";\n\n  &::placeholder {\n    color: ",
                ";\n  }\n\n  &:disabled {\n    background-color: ",
                ";\n    box-shadow: none;\n    color: ",
                ";\n    cursor: not-allowed;\n  }\n\n  &:focus:not(:disabled) {\n    box-shadow: ",
                ";\n  }\n\n  input {\n    color: #ffffff;\n    font-weight: 500;\n    font-size: 16px;\n    line-height: 100%;\n    letter-spacing: 0.04em;\n    // text-shadow: 1px 7px 4px rgba(111, 27, 47, 0.35), 0px -1px 0px #b64034;\n\n    flex: 1 0 auto;\n    height: ",
                ";\n\n    background: transparent;\n    border: unset;\n    outline: unset;\n    &:hover,\n    &:focus {\n      border: unset;\n      outline: unset;\n    }\n\n    &::placeholder {\n      color: #fff;\n      font-size: 12px;\n      font-family: 'Helvetica';\n    }\n  }\n\n  .prefix {\n    height: 100%;\n    flex: 0 0 auto;\n    display: flex;\n    align-items: center;\n    & > div {\n      color: #ffffff;\n      font-weight: 500;\n      font-size: 16px;\n      line-height: 100%;\n      letter-spacing: 0.04em;\n      text-shadow: 1px 7px 4px rgba(111, 27, 47, 0.35), 0px -1px 0px #b64034;\n      margin-right: 8px;\n    }\n    img {\n      width: auto;\n      height: calc(",
                " - 2px);\n    }\n  }\n",
              ])),
            function (e) {
              return e.theme.colors.text;
            },
            function (e) {
              var n = e.isSuccess,
                t = void 0 !== n && n,
                a = e.isWarning,
                i = void 0 !== a && a,
                s = e.theme;
              return i
                ? s.shadows.warning
                : t
                ? s.shadows.success
                : s.shadows.inset;
            },
            function (e) {
              return e.theme.colors.textSubtle;
            },
            function (e) {
              return e.theme.colors.backgroundDisabled;
            },
            function (e) {
              return e.theme.colors.textDisabled;
            },
            function (e) {
              return e.theme.shadows.focus;
            },
            ea,
            ea
          ),
          ["title", "value", "height", "children"]),
        ta = y.d.div(Nt || (Nt = Object(d.a)([""]))),
        aa = Object(y.d)(Ct).attrs({ role: "button" })(
          Bt ||
            (Bt = Object(d.a)([
              "\n  position: relative;\n  display: flex;\n  align-items: center;\n  color: ",
              ";\n\n  padding: 5px 10px;\n  border-radius: 6px;\n  background-color: rgba(255, 255, 255, 0.1);\n  font-size: 20px;\n  font-weight: 300;\n",
            ])),
          function (e) {
            return e.theme.colors.primary;
          }
        ),
        ia = y.d.div(
          St ||
            (St = Object(d.a)([
              "\n  display: ",
              ";\n  position: absolute;\n  bottom: -22px;\n  right: 0;\n  left: 0;\n  text-align: center;\n  background-color: ",
              ";\n  color: ",
              ";\n  border-radius: 16px;\n  opacity: 0.7;\n",
            ])),
          function (e) {
            return e.isTooltipDisplayed ? "block" : "none";
          },
          function (e) {
            return e.theme.colors.contrast;
          },
          function (e) {
            return e.theme.colors.invertedContrast;
          }
        ),
        sa = Object(y.d)(Ct)(
          Lt || (Lt = Object(d.a)(["\n  font-size: 20px;\n"]))
        ),
        ra = y.d.span(
          Dt ||
            (Dt = Object(d.a)([
              "\n  display: flex;\n  align-items: center;\n  margin-left: auto;\n",
            ]))
        ),
        oa = y.d.div(
          Ft ||
            (Ft = Object(d.a)([
              "\n  font-family: 'Helvetica';\n  font-size: 16px;\n  font-weight: bold;\n  white-space: nowrap;\n  overflow: hidden;\n",
            ]))
        ),
        pa = function (e) {
          var n = e.title,
            t = e.value,
            a = e.height,
            i = e.children,
            r = Object(ke.a)(e, na),
            o = Object(s.useState)(!1),
            p = Object(j.a)(o, 2),
            u = p[0],
            l = p[1];
          return Object(P.jsxs)(ta, {
            children: [
              Object(P.jsx)(sa, { children: n }),
              Object(P.jsxs)(
                aa,
                Object(h.a)(
                  Object(h.a)(
                    {
                      small: !0,
                      bold: !0,
                      onClick: function () {
                        navigator.clipboard &&
                          (navigator.clipboard.writeText(t),
                          l(!0),
                          setTimeout(function () {
                            l(!1);
                          }, 1e3));
                      },
                      title: t,
                      style: { height: a },
                    },
                    r
                  ),
                  {},
                  {
                    children: [
                      Object(P.jsx)(oa, { children: i }),
                      Object(P.jsx)(ra, {
                        children: Object(P.jsx)(Ot, {
                          width: "20px",
                          color: "primary",
                          ml: "4px",
                        }),
                      }),
                      Object(P.jsx)(ia, {
                        isTooltipDisplayed: u,
                        children: "Copied",
                      }),
                    ],
                  }
                )
              ),
            ],
          });
        },
        ua = function (e) {
          return Object(P.jsxs)(
            gt,
            Object(h.a)(
              Object(h.a)({ viewBox: "0 0 96 96" }, e),
              {},
              {
                children: [
                  Object(P.jsx)("circle", {
                    cx: "48",
                    cy: "48",
                    r: "48",
                    fill: "white",
                  }),
                  Object(P.jsx)("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M66.4573 43.7107C64.8919 42.1452 64.8919 39.6071 66.4573 38.0416C68.0228 36.4762 70.5609 36.4762 72.1264 38.0416C73.6918 39.6071 73.6918 42.1452 72.1264 43.7107C70.5609 45.2762 68.0228 45.2762 66.4573 43.7107ZM52.9933 57.1747C51.8192 56.0006 51.8192 54.097 52.9933 52.9229C54.1674 51.7488 56.071 51.7488 57.2451 52.9229C58.4192 54.097 58.4192 56.0006 57.2451 57.1747C56.071 58.3488 54.1674 58.3488 52.9933 57.1747ZM74.2523 50.0884C73.0782 48.9143 73.0782 47.0107 74.2523 45.8366C75.4263 44.6625 77.3299 44.6625 78.504 45.8366C79.6781 47.0107 79.6781 48.9143 78.504 50.0884C77.3299 51.2625 75.4263 51.2625 74.2523 50.0884ZM67.166 57.1747C65.9919 56.0006 65.9919 54.097 67.166 52.9229C68.34 51.7488 70.2436 51.7488 71.4177 52.9229C72.5918 54.097 72.5918 56.0006 71.4177 57.1747C70.2436 58.3488 68.34 58.3488 67.166 57.1747ZM82.0472 56.466C81.2645 55.6833 81.2645 54.4142 82.0472 53.6315C82.8299 52.8488 84.099 52.8488 84.8817 53.6315C85.6644 54.4142 85.6644 55.6833 84.8817 56.466C84.099 57.2488 82.8299 57.2488 82.0472 56.466ZM74.9609 63.5523C74.1782 62.7696 74.1782 61.5005 74.9609 60.7178C75.7436 59.9351 77.0127 59.9351 77.7954 60.7178C78.5781 61.5005 78.5781 62.7696 77.7954 63.5523C77.0127 64.3351 75.7436 64.3351 74.9609 63.5523ZM59.371 50.797C57.8056 49.2315 57.8056 46.6934 59.371 45.1279C60.9365 43.5625 63.4746 43.5625 65.0401 45.1279C66.6055 46.6934 66.6055 49.2315 65.0401 50.797C63.4746 52.3625 60.9365 52.3625 59.371 50.797ZM59.371 36.6244C57.8056 35.0589 57.8056 32.5208 59.371 30.9553C60.9365 29.3899 63.4746 29.3899 65.0401 30.9553C66.6055 32.5208 66.6055 35.0589 65.0401 36.6244C63.4746 38.1898 60.9365 38.1898 59.371 36.6244ZM52.2847 43.7107C50.7193 42.1452 50.7193 39.6071 52.2847 38.0416C53.8502 36.4762 56.3883 36.4762 57.9538 38.0416C59.5192 39.6071 59.5192 42.1452 57.9538 43.7107C56.3883 45.2762 53.8502 45.2762 52.2847 43.7107ZM38.0462 43.7107C36.4808 42.1452 36.4808 39.6071 38.0462 38.0416C39.6117 36.4762 42.1498 36.4762 43.7153 38.0416C45.2807 39.6071 45.2807 42.1452 43.7153 43.7107C42.1498 45.2762 39.6117 45.2762 38.0462 43.7107ZM24.5823 57.1747C23.4082 56.0006 23.4082 54.097 24.5823 52.9229C25.7564 51.7488 27.66 51.7488 28.8341 52.9229C30.0081 54.097 30.0081 56.0006 28.8341 57.1747C27.66 58.3488 25.7564 58.3488 24.5823 57.1747ZM45.8412 50.0884C44.6671 48.9143 44.6671 47.0107 45.8412 45.8366C47.0153 44.6625 48.9189 44.6625 50.093 45.8366C51.2671 47.0107 51.2671 48.9143 50.093 50.0884C48.9189 51.2625 47.0153 51.2625 45.8412 50.0884ZM38.7549 57.1747C37.5808 56.0006 37.5808 54.097 38.7549 52.9229C39.929 51.7488 41.8326 51.7488 43.0067 52.9229C44.1807 54.097 44.1807 56.0006 43.0067 57.1747C41.8326 58.3488 39.929 58.3488 38.7549 57.1747ZM11.1183 56.466C10.3356 55.6833 10.3356 54.4142 11.1183 53.6315C11.901 52.8488 13.1701 52.8488 13.9528 53.6315C14.7356 54.4142 14.7356 55.6833 13.9528 56.466C13.1701 57.2488 11.901 57.2488 11.1183 56.466ZM18.2046 63.5523C17.4219 62.7696 17.4219 61.5005 18.2046 60.7178C18.9873 59.9351 20.2564 59.9351 21.0391 60.7178C21.8219 61.5005 21.8219 62.7696 21.0391 63.5523C20.2564 64.3351 18.9873 64.3351 18.2046 63.5523ZM46.5498 63.5523C45.7671 62.7696 45.7671 61.5005 46.5498 60.7178C47.3325 59.9351 48.6016 59.9351 49.3843 60.7178C50.1671 61.5005 50.1671 62.7696 49.3843 63.5523C48.6016 64.3351 47.3325 64.3351 46.5498 63.5523ZM17.496 50.0884C16.3219 48.9143 16.3219 47.0107 17.496 45.8366C18.6701 44.6625 20.5737 44.6625 21.7478 45.8366C22.9218 47.0107 22.9218 48.9143 21.7478 50.0884C20.5737 51.2625 18.6701 51.2625 17.496 50.0884ZM30.9599 50.797C29.3945 49.2315 29.3945 46.6934 30.9599 45.1279C32.5254 43.5625 35.0635 43.5625 36.629 45.1279C38.1944 46.6934 38.1944 49.2315 36.629 50.797C35.0635 52.3625 32.5254 52.3625 30.9599 50.797ZM30.9599 36.6244C29.3945 35.0589 29.3945 32.5208 30.9599 30.9553C32.5254 29.3899 35.0635 29.3899 36.629 30.9553C38.1944 32.5208 38.1944 35.0589 36.629 36.6244C35.0635 38.1898 32.5254 38.1898 30.9599 36.6244ZM23.8736 43.7107C22.3082 42.1452 22.3082 39.6071 23.8736 38.0416C25.4391 36.4762 27.9772 36.4762 29.5427 38.0416C31.1081 39.6071 31.1081 42.1452 29.5427 43.7107C27.9772 45.2762 25.4391 45.2762 23.8736 43.7107Z",
                    fill: "#1D222A",
                  }),
                ],
              }
            )
          );
        },
        la = function (e) {
          return Object(P.jsxs)(
            gt,
            Object(h.a)(
              Object(h.a)({ viewBox: "0 0 96 96" }, e),
              {},
              {
                children: [
                  Object(P.jsx)("circle", {
                    cx: "48",
                    cy: "48",
                    r: "48",
                    fill: "white",
                  }),
                  Object(P.jsx)("path", {
                    d: "M44.3288 35.3546V21.7134H19.0926C18.581 21.7134 18.24 22.0544 18.24 22.566V41.8342C18.24 42.3457 18.581 42.6867 19.0926 42.6867H28.8119V77.8129C28.8119 78.3244 29.153 78.6654 29.6645 78.6654H45.5224C46.0339 78.6654 46.375 78.3244 46.375 77.8129V35.3546H44.3288Z",
                    fill: "#29AEFF",
                  }),
                  Object(P.jsx)("path", {
                    d: "M61.8919 17.2798H55.7534H39.2134C38.7019 17.2798 38.3608 17.6208 38.3608 18.1324V73.3792C38.3608 73.8908 38.7019 74.2318 39.2134 74.2318H55.0713C55.5829 74.2318 55.9239 73.8908 55.9239 73.3792V59.397H62.0624C73.6575 59.397 83.0358 50.0187 83.0358 38.4237C83.0358 26.6581 73.487 17.2798 61.8919 17.2798Z",
                    fill: "#2761E7",
                  }),
                ],
              }
            )
          );
        },
        ca = function (e) {
          return Object(P.jsxs)(
            gt,
            Object(h.a)(
              Object(h.a)({ viewBox: "0 0 96 96" }, e),
              {},
              {
                children: [
                  Object(P.jsxs)("g", {
                    clipPath: "url(#clip0)",
                    children: [
                      Object(P.jsx)("path", {
                        d: "M48.0048 96.0097C74.5172 96.0097 96.0097 74.5172 96.0097 48.0048C96.0097 21.4925 74.5172 0 48.0048 0C21.4925 0 0 21.4925 0 48.0048C0 74.5172 21.4925 96.0097 48.0048 96.0097Z",
                        fill: "#3375BB",
                      }),
                      Object(P.jsx)("path", {
                        d: "M48.0048 22.8922L49.3179 21.1833C48.9399 20.8928 48.4766 20.7354 48 20.7354C47.5233 20.7354 47.06 20.8928 46.682 21.1833L48.0048 22.8922ZM70.5783 29.5252H72.7313C72.7352 29.2396 72.6824 28.9561 72.576 28.6909C72.4696 28.4258 72.3118 28.1844 72.1116 27.9806C71.9114 27.7769 71.6729 27.6148 71.4097 27.5037C71.1465 27.3926 70.8639 27.3348 70.5783 27.3335V29.5252ZM48.0048 75.6377L46.8076 77.4335C47.1604 77.6697 47.5754 77.7958 48 77.7958C48.4245 77.7958 48.8395 77.6697 49.1924 77.4335L48.0048 75.6377ZM25.4506 29.5252V27.3625C25.165 27.3638 24.8824 27.4216 24.6192 27.5327C24.356 27.6437 24.1175 27.8058 23.9173 28.0096C23.7171 28.2134 23.5593 28.4548 23.4529 28.7199C23.3465 28.985 23.2937 29.2686 23.2976 29.5542L25.4506 29.5252ZM46.6917 24.5915C56.4626 32.1611 67.6528 31.6783 70.5879 31.6783V27.3625C67.5466 27.3625 57.8047 27.7487 49.3468 21.1833L46.6917 24.5915ZM68.4348 29.4866C68.2707 39.4892 67.8459 46.5471 67.0349 51.7704C66.2238 56.9938 65.1039 60.0448 63.6266 62.2268C62.1494 64.4089 60.257 65.8282 57.486 67.4792C54.715 69.1302 51.1716 70.9646 46.8076 73.8515L49.2406 77.4335C53.373 74.6818 56.8102 72.9246 59.7357 71.1771C62.6835 69.5717 65.2416 67.3367 67.228 64.6309C69.159 61.7344 70.4817 57.8724 71.3314 52.427C72.181 46.9815 72.6155 39.6534 72.7796 29.5542L68.4348 29.4866ZM49.2406 73.8515C44.9055 70.955 41.3718 69.1592 38.6201 67.4888C35.8684 65.8185 33.976 64.4861 32.4892 62.2268C31.0023 59.9676 29.7954 56.9648 28.9651 51.7704C28.1347 46.576 27.7678 39.4892 27.6037 29.4866L23.2976 29.5542C23.4617 39.6534 23.9058 47.0009 24.7458 52.427C25.5858 57.8531 26.8699 61.7151 28.8395 64.6309C30.8164 67.3382 33.3686 69.5739 36.3125 71.1771C39.2091 72.9246 42.6752 74.6818 46.8076 77.4335L49.2406 73.8515ZM25.4506 31.6783C28.3471 31.6783 39.547 32.1611 49.3179 24.5915L46.682 21.1833C38.2049 27.7487 28.463 27.3625 25.441 27.3625L25.4506 31.6783Z",
                        fill: "white",
                      }),
                    ],
                  }),
                  Object(P.jsx)("defs", {
                    children: Object(P.jsx)("clipPath", {
                      id: "clip0",
                      children: Object(P.jsx)("rect", {
                        width: "96",
                        height: "96",
                        fill: "white",
                      }),
                    }),
                  }),
                ],
              }
            )
          );
        },
        da = function (e) {
          return Object(P.jsxs)(
            gt,
            Object(h.a)(
              Object(h.a)({ viewBox: "0 0 96 96" }, e),
              {},
              {
                children: [
                  Object(P.jsx)("path", {
                    d: "M96 48C96 21.4903 74.5097 0 48 0C21.4903 0 0 21.4903 0 48C0 74.5097 21.4903 96 48 96C74.5097 96 96 74.5097 96 48Z",
                    fill: "#3389FB",
                  }),
                  Object(P.jsx)("path", {
                    d: "M29.6927 35.4245C39.8036 25.5252 56.1965 25.5252 66.3074 35.4245L67.5242 36.6159C68.0298 37.1109 68.0298 37.9134 67.5242 38.4084L63.3616 42.4839C63.1088 42.7314 62.699 42.7314 62.4462 42.4839L60.7717 40.8444C53.7181 33.9384 42.282 33.9384 35.2284 40.8444L33.4351 42.6002C33.1823 42.8477 32.7725 42.8477 32.5197 42.6002L28.3571 38.5247C27.8515 38.0297 27.8515 37.2272 28.3571 36.7322L29.6927 35.4245ZM74.9161 43.8532L78.6208 47.4805C79.1264 47.9755 79.1264 48.778 78.6208 49.2729L61.9159 65.6288C61.4103 66.1237 60.5907 66.1237 60.0851 65.6288C60.0851 65.6288 60.0851 65.6288 60.0851 65.6288L48.229 54.0206C48.1026 53.8968 47.8977 53.8968 47.7713 54.0206C47.7713 54.0206 47.7713 54.0206 47.7713 54.0206L35.9153 65.6288C35.4098 66.1237 34.5902 66.1237 34.0846 65.6288C34.0846 65.6288 34.0846 65.6288 34.0846 65.6288L17.3792 49.2727C16.8736 48.7778 16.8736 47.9753 17.3792 47.4803L21.0839 43.853C21.5895 43.3581 22.4091 43.3581 22.9146 43.853L34.771 55.4614C34.8974 55.5851 35.1023 55.5851 35.2287 55.4614C35.2287 55.4614 35.2287 55.4614 35.2287 55.4614L47.0844 43.853C47.59 43.358 48.4096 43.358 48.9152 43.853C48.9152 43.853 48.9152 43.853 48.9152 43.853L60.7715 55.4614C60.8979 55.5851 61.1028 55.5851 61.2292 55.4614L73.0854 43.8532C73.5909 43.3583 74.4105 43.3583 74.9161 43.8532Z",
                    fill: "white",
                  }),
                ],
              }
            )
          );
        },
        ya = function (e) {
          return Object(P.jsxs)(
            gt,
            Object(h.a)(
              Object(h.a)({ viewBox: "0 0 32 32" }, e),
              {},
              {
                children: [
                  Object(P.jsx)("path", {
                    d: "M24 0H8C3.58172 0 0 3.58172 0 8V24C0 28.4183 3.58172 32 8 32H24C28.4183 32 32 28.4183 32 24V8C32 3.58172 28.4183 0 24 0Z",
                    fill: "#1E2026",
                  }),
                  Object(P.jsx)("path", {
                    d: "M16.2857 4L9.97035 7.6761L12.2922 9.03415L16.2857 6.7161L20.2792 9.03415L22.6011 7.6761L16.2857 4Z",
                    fill: "#F0B90B",
                  }),
                  Object(P.jsx)("path", {
                    d: "M20.2792 10.9541L22.6011 12.3122V15.0283L18.6075 17.3463V21.9824L16.2857 23.3405L13.9639 21.9824V17.3463L9.97035 15.0283V12.3122L12.2922 10.9541L16.2857 13.2722L20.2792 10.9541Z",
                    fill: "#F0B90B",
                  }),
                  Object(P.jsx)("path", {
                    d: "M22.6011 16.9483V19.6644L20.2792 21.0224V18.3063L22.6011 16.9483Z",
                    fill: "#F0B90B",
                  }),
                  Object(P.jsx)("path", {
                    d: "M20.2561 22.9424L24.2496 20.6244V15.9883L26.5714 14.6302V21.9824L20.2561 25.6585V22.9424Z",
                    fill: "#F0B90B",
                  }),
                  Object(P.jsx)("path", {
                    d: "M24.2496 11.3522L21.9278 9.99414L24.2496 8.63609L26.5714 9.99414V12.7102L24.2496 14.0683V11.3522Z",
                    fill: "#F0B90B",
                  }),
                  Object(P.jsx)("path", {
                    d: "M13.9639 26.642V23.9259L16.2857 25.2839L18.6075 23.9259V26.642L16.2857 28L13.9639 26.642Z",
                    fill: "#F0B90B",
                  }),
                  Object(P.jsx)("path", {
                    d: "M12.2922 21.0224L9.97035 19.6644V16.9483L12.2922 18.3063V21.0224Z",
                    fill: "#F0B90B",
                  }),
                  Object(P.jsx)("path", {
                    d: "M16.2857 11.3522L13.9639 9.99414L16.2857 8.63609L18.6075 9.99414L16.2857 11.3522Z",
                    fill: "#F0B90B",
                  }),
                  Object(P.jsx)("path", {
                    d: "M10.6437 9.99414L8.32183 11.3522V14.0683L6 12.7102V9.99414L8.32183 8.63609L10.6437 9.99414Z",
                    fill: "#F0B90B",
                  }),
                  Object(P.jsx)("path", {
                    d: "M6 14.6302L8.32183 15.9883V20.6244L12.3154 22.9424V25.6585L6 21.9824V14.6302Z",
                    fill: "#F0B90B",
                  }),
                ],
              }
            )
          );
        },
        ma = function (e) {
          return Object(P.jsx)(
            gt,
            Object(h.a)(
              Object(h.a)({ viewBox: "0 0 32 32" }, e),
              {},
              {
                style: { background: "#fff", borderRadius: "50%" },
                children: Object(P.jsx)("path", {
                  transform: "translate(5, 5)",
                  d: "M13.7636 0.0369041C13.7496 0.0537556 13.66 0.193684 13.5648 0.347835C12.9585 1.32847 12.1173 2.51156 11.2294 3.63232C11.0358 3.87677 11.0049 3.91175 10.9819 3.91234C10.9691 3.91265 10.5371 3.36648 10.2197 2.94867C9.52868 2.03896 8.94656 1.20264 8.45957 0.419884C8.26801 0.111983 8.23492 0.0675592 8.19711 0.0675592C8.09867 0.0675592 6.33455 1.64979 5.24484 2.71542C5.08274 2.87395 5.08249 2.87295 5.31298 3.01922C6.52744 3.79 9.25501 5.95574 9.17035 6.08202C9.00096 6.3347 6.16792 9.29498 5.82858 9.57386L5.78186 9.61227L5.74657 9.56706C5.72714 9.5422 5.57181 9.34561 5.40136 9.13023C4.43996 7.91531 3.54229 6.6371 2.93656 5.62053C2.76597 5.33426 2.75942 5.32621 2.71624 5.35036C2.57742 5.42799 0.0971073 8.39047 0.0439775 8.54209C0.0318392 8.57676 0.0534335 8.59753 0.212186 8.70385C0.974129 9.21412 1.87065 9.88627 2.68453 10.5575C3.17436 10.9615 3.74132 11.4513 3.74108 11.4704C3.73913 11.6105 1.27663 13.5516 0.195421 14.2653C0.0256195 14.3774 0.0033384 14.3971 0.00286897 14.4356C0.00181274 14.5252 2.63291 17.6636 2.709 17.6636C2.73964 17.6636 2.76407 17.6291 2.92002 17.3659C3.52198 16.3495 4.42876 15.0601 5.48236 13.7223C5.62273 13.544 5.75211 13.3876 5.76985 13.3746C5.80587 13.3483 5.89318 13.4304 6.76728 14.3114C7.5125 15.0625 9.12167 16.7816 9.18021 16.8892C9.19937 16.9245 9.16472 16.9577 8.64205 17.404C7.41046 18.456 6.25733 19.3318 5.25022 19.9798C5.01451 20.1316 5.01126 20.1114 5.32062 20.4173C6.17403 21.2614 7.97426 22.9006 8.13199 22.9773C8.1803 23.0008 8.15207 23.0381 8.44519 22.5623C8.99021 21.6776 9.76259 20.5872 10.6267 19.4829C10.8049 19.2551 10.9613 19.0644 10.9741 19.0593C11.0696 19.021 12.629 21.1363 13.3933 22.3408C13.5614 22.6057 13.7109 22.8402 13.7254 22.8619C13.7845 22.95 14.0713 22.7165 15.4185 21.4829C16.8727 20.1514 16.915 20.1028 16.725 19.9794C16.1806 19.6263 15.3005 18.9931 14.7144 18.5332C13.8429 17.8493 12.8031 16.9656 12.8031 16.909C12.8031 16.8177 14.7239 14.778 15.8418 13.6821C16.0285 13.499 16.1814 13.3432 16.1814 13.3359C16.1814 13.3091 15.3864 12.3561 14.8857 11.7825L14.6211 11.4795L14.8689 11.195C15.2116 10.8017 15.5724 10.3757 15.896 9.98234C16.229 9.57751 16.1502 9.58252 16.5276 9.94217C16.9449 10.3399 17.472 10.826 17.862 11.1731C18.2373 11.5069 18.2305 11.4584 17.9383 11.7165C17.4191 12.1754 16.1981 13.3124 16.1981 13.3371C16.1981 13.3426 16.267 13.4334 16.3514 13.539C17.4495 14.9146 18.3908 16.242 19.0332 17.3206C19.2424 17.6717 19.2263 17.6624 19.3636 17.5125C20.2084 16.5899 21.9481 14.4972 21.9485 14.4031C21.9486 14.3849 21.8477 14.3069 21.6765 14.1928C20.6601 13.5152 18.2436 11.6038 18.2436 11.4774C18.2436 11.4074 19.7434 10.17 20.6388 9.5014C20.9785 9.24769 21.785 8.68163 21.9186 8.60315C22.0352 8.5346 22.0445 8.55512 21.6964 8.11384C21.031 7.27034 19.9473 5.98966 19.3811 5.37767C19.2587 5.24549 19.2788 5.22971 19.015 5.66559C18.3847 6.70717 17.6 7.82759 16.6663 9.01888C16.3152 9.4669 16.1976 9.6085 16.1815 9.60233C16.071 9.55984 12.8231 6.16725 12.7817 6.05114C12.7729 6.02658 13.718 5.21974 14.3455 4.7161C15.202 4.0286 15.9336 3.49576 16.7762 2.9456C16.8616 2.88981 16.9022 2.85242 16.9022 2.82977C16.9022 2.74851 15.0898 1.07965 14.0394 0.193737C13.7983 -0.00958677 13.801 -0.00806281 13.7636 0.0369041ZM11.1782 4.17098C11.5497 4.63138 12.3708 5.60078 12.6383 5.89474C12.7786 6.0488 12.7925 6.02099 12.3965 6.37642C11.8585 6.8593 11.0167 7.64704 11.0043 7.67909C10.9993 7.69213 11.0174 7.71056 11.537 8.2229C12.5739 9.24535 14.6054 11.4005 14.6054 11.478C14.6054 11.5277 13.159 13.0914 12.3423 13.9247C11.9125 14.3632 11.1362 15.1339 11.0222 15.2353L10.9853 15.268L10.621 14.9112C9.66196 13.9717 8.59944 12.8615 7.70043 11.8596L7.35917 11.4793L7.55793 11.2569C8.55753 10.138 9.74462 8.89676 10.7451 7.92428C10.8673 7.80553 10.9673 7.69866 10.9673 7.68679C10.9673 7.6528 10.359 7.07579 9.6059 6.39541C9.4058 6.21464 9.23744 6.05887 9.23176 6.04927C9.22608 6.03966 9.33381 5.90379 9.47117 5.74734C9.83634 5.33142 10.257 4.83511 10.6364 4.37244C11.0288 3.89409 10.9719 3.91525 11.1782 4.17098ZM6.05937 9.95289C6.41537 10.3847 6.77145 10.8055 7.08166 11.1611C7.39639 11.5219 7.38912 11.4416 7.1337 11.7353C6.78593 12.1351 6.41734 12.5702 6.0994 12.9561C5.74342 13.3882 5.82982 13.3761 5.48098 13.0431C5.05035 12.632 4.59985 12.2158 4.18142 11.8424C3.72885 11.4385 3.72602 11.5231 4.20657 11.0925C4.64279 10.7016 5.22016 10.1667 5.56038 9.83824C5.68026 9.72252 5.78412 9.6313 5.79118 9.63551C5.79826 9.63972 5.91895 9.78255 6.05937 9.95289ZM11.221 15.4945C11.559 15.8161 12.0957 16.3122 12.4384 16.62C12.7974 16.9424 12.7823 16.894 12.5916 17.1122C12.2533 17.4992 11.6426 18.2196 11.3447 18.5834C11.1711 18.7952 11.0194 18.9747 11.0077 18.982C10.9771 19.0012 10.9408 18.9622 10.5963 18.5395C10.264 18.132 9.73626 17.5096 9.4193 17.1516C9.31021 17.0284 9.22345 16.9203 9.2265 16.9116C9.22953 16.9026 9.38292 16.7601 9.56733 16.5946C9.95244 16.2491 10.482 15.7587 10.7745 15.4771C11.017 15.2434 10.9545 15.241 11.221 15.4945Z",
                  fillRule: "evenodd",
                  clipRule: "evenodd",
                  fill: "black",
                }),
              }
            )
          );
        },
        ba = function (e) {
          return Object(P.jsxs)(
            gt,
            Object(h.a)(
              Object(h.a)({ viewBox: "0 0 96 96" }, e),
              {},
              {
                children: [
                  Object(P.jsx)("circle", {
                    cx: "48",
                    cy: "48",
                    r: "48",
                    fill: "#F5F5F5",
                  }),
                  Object(P.jsx)("path", {
                    d: "M56.5504425,41.9387033 L56.5504425,50.4659601 L47.3948342,50.4659601 L47.3948342,85.5971142 L45.0078131,84.7075452 C43.8992633,84.2955753 42.1136272,83.5937969 39.9052997,82.5918134 L38.8675775,82.1177881 L38.8675775,14.6817622 L47.9569067,11.8769231 L56.5504425,14.5267861 L56.5504425,23.7259307 L47.9569067,21.0669705 L47.3948342,21.2411155 L47.3948342,41.9387033 L56.5504425,41.9387033 Z M16,50.4659926 L16,21.7739797 L36.1702794,15.548296 L36.1702794,24.7052039 L24.526282,28.3200122 L24.526282,41.9387358 L36.1702794,41.9387358 L36.1702794,81.3806284 L33.591244,80.0543973 C25.5662786,75.923652 16,68.9585019 16,59.2339983 L16,54.6496962 L24.526282,54.6496962 L24.526282,59.2339983 C24.526282,61.2460878 25.5734263,63.3605199 27.6426978,65.5373324 L27.6426978,50.4659926 L16,50.4659926 Z M59.1389325,15.3302574 L79.8040306,21.7261873 L79.8040306,50.4659601 L67.6710627,50.4659601 L67.6710627,62.9111544 C67.6710627,62.9111544 64.9581695,66.4674811 59.1464051,69.4451657 C59.1464051,67.0682164 59.1389325,15.3302574 59.1389325,15.3302574 Z M71.2780734,41.9387033 L71.2780734,28.2783928 L67.6710627,27.1649695 L67.6710627,41.9387033 L71.2780734,41.9387033 Z M71.2780734,59.8661186 L71.2780734,54.6495662 L79.8040306,54.6495662 L79.8040306,59.8661186 C79.8040306,74.3588162 58.7760221,82.7005566 52.330058,84.9127828 L49.9859233,85.7230769 L49.9859233,76.7068496 L51.1311866,76.2744112 C61.1591444,72.5004032 71.2780734,65.962818 71.2780734,59.8661186 Z",
                    fill: "#000000",
                  }),
                ],
              }
            )
          );
        },
        fa = [
          {
            title: "Metamask",
            icon: function (e) {
              return Object(P.jsxs)(
                gt,
                Object(h.a)(
                  Object(h.a)({ viewBox: "0 0 96 96" }, e),
                  {},
                  {
                    children: [
                      Object(P.jsx)("circle", {
                        cx: "48",
                        cy: "48",
                        r: "48",
                        fill: "white",
                      }),
                      Object(P.jsx)("path", {
                        d: "M77.7602 16.9155L51.9419 36.0497L56.7382 24.7733L77.7602 16.9155Z",
                        fill: "#E17726",
                      }),
                      Object(P.jsx)("path", {
                        d: "M18.2656 16.9155L43.8288 36.2283L39.2622 24.7733L18.2656 16.9155Z",
                        fill: "#E27625",
                      }),
                      Object(P.jsx)("path", {
                        d: "M68.4736 61.2808L61.6108 71.7918L76.3059 75.8482L80.4899 61.5104L68.4736 61.2808Z",
                        fill: "#E27625",
                      }),
                      Object(P.jsx)("path", {
                        d: "M15.5356 61.5104L19.6941 75.8482L34.3892 71.7918L27.5519 61.2808L15.5356 61.5104Z",
                        fill: "#E27625",
                      }),
                      Object(P.jsx)("path", {
                        d: "M33.5984 43.5251L29.491 49.699L44.0584 50.3624L43.5482 34.6724L33.5984 43.5251Z",
                        fill: "#E27625",
                      }),
                      Object(P.jsx)("path", {
                        d: "M62.4274 43.525L52.2991 34.4937L51.9419 50.3622L66.5094 49.6989L62.4274 43.525Z",
                        fill: "#E27625",
                      }),
                      Object(P.jsx)("path", {
                        d: "M34.3892 71.7922L43.1654 67.5316L35.6137 61.6128L34.3892 71.7922Z",
                        fill: "#E27625",
                      }),
                      Object(P.jsx)("path", {
                        d: "M52.8345 67.5316L61.6107 71.7922L60.3861 61.6128L52.8345 67.5316Z",
                        fill: "#E27625",
                      }),
                      Object(P.jsx)("path", {
                        d: "M61.6107 71.7923L52.8345 67.5317L53.5233 73.2465L53.4468 75.6446L61.6107 71.7923Z",
                        fill: "#D5BFB2",
                      }),
                      Object(P.jsx)("path", {
                        d: "M34.3892 71.7923L42.5531 75.6446L42.502 73.2465L43.1654 67.5317L34.3892 71.7923Z",
                        fill: "#D5BFB2",
                      }),
                      Object(P.jsx)("path", {
                        d: "M42.7062 57.8369L35.4097 55.6939L40.5631 53.3213L42.7062 57.8369Z",
                        fill: "#233447",
                      }),
                      Object(P.jsx)("path", {
                        d: "M53.2937 57.8369L55.4367 53.3213L60.6412 55.6939L53.2937 57.8369Z",
                        fill: "#233447",
                      }),
                      Object(P.jsx)("path", {
                        d: "M34.3893 71.7918L35.6649 61.2808L27.552 61.5104L34.3893 71.7918Z",
                        fill: "#CC6228",
                      }),
                      Object(P.jsx)("path", {
                        d: "M60.3352 61.2808L61.6108 71.7918L68.4736 61.5104L60.3352 61.2808Z",
                        fill: "#CC6228",
                      }),
                      Object(P.jsx)("path", {
                        d: "M66.5094 49.6987L51.9419 50.362L53.294 57.8371L55.4371 53.3215L60.6416 55.6941L66.5094 49.6987Z",
                        fill: "#CC6228",
                      }),
                      Object(P.jsx)("path", {
                        d: "M35.4098 55.6941L40.5633 53.3215L42.7063 57.8371L44.0584 50.362L29.491 49.6987L35.4098 55.6941Z",
                        fill: "#CC6228",
                      }),
                      Object(P.jsx)("path", {
                        d: "M29.491 49.6987L35.6139 61.6129L35.4098 55.6941L29.491 49.6987Z",
                        fill: "#E27525",
                      }),
                      Object(P.jsx)("path", {
                        d: "M60.6414 55.6941L60.3862 61.6129L66.5092 49.6987L60.6414 55.6941Z",
                        fill: "#E27525",
                      }),
                      Object(P.jsx)("path", {
                        d: "M44.0584 50.3618L42.7063 57.8369L44.4156 66.6641L44.7728 55.0305L44.0584 50.3618Z",
                        fill: "#E27525",
                      }),
                      Object(P.jsx)("path", {
                        d: "M51.9415 50.3618L51.2527 55.005L51.5843 66.6641L53.2937 57.8369L51.9415 50.3618Z",
                        fill: "#E27525",
                      }),
                      Object(P.jsx)("path", {
                        d: "M53.2938 57.8374L51.5845 66.6646L52.8346 67.532L60.3862 61.6132L60.6413 55.6943L53.2938 57.8374Z",
                        fill: "#F5841F",
                      }),
                      Object(P.jsx)("path", {
                        d: "M35.4097 55.6943L35.6138 61.6132L43.1654 67.532L44.4155 66.6646L42.7062 57.8374L35.4097 55.6943Z",
                        fill: "#F5841F",
                      }),
                      Object(P.jsx)("path", {
                        d: "M53.4468 75.6443L53.5233 73.2462L52.8855 72.6849H43.1143L42.502 73.2462L42.5531 75.6443L34.3892 71.792L37.2465 74.1391L43.0378 78.1445H52.962L58.7533 74.1391L61.6107 71.792L53.4468 75.6443Z",
                        fill: "#C0AC9D",
                      }),
                      Object(P.jsx)("path", {
                        d: "M52.8346 67.5315L51.5845 66.6641H44.4156L43.1655 67.5315L42.5022 73.2462L43.1145 72.6849H52.8857L53.5235 73.2462L52.8346 67.5315Z",
                        fill: "#161616",
                      }),
                      Object(P.jsx)("path", {
                        d: "M78.8314 37.2998L80.9999 26.7377L77.7599 16.9155L52.8345 35.4119L62.4271 43.5247L75.9485 47.4791L78.9335 43.984L77.6323 43.04L79.7243 41.1521L78.1426 39.902L80.2091 38.3458L78.8314 37.2998Z",
                        fill: "#763E1A",
                      }),
                      Object(P.jsx)("path", {
                        d: "M15 26.7377L17.194 37.2998L15.7909 38.3458L17.8574 39.902L16.2756 41.1521L18.3676 43.04L17.0665 43.984L20.0514 47.4791L33.5984 43.5247L43.1655 35.4119L18.2656 16.9155L15 26.7377Z",
                        fill: "#763E1A",
                      }),
                      Object(P.jsx)("path", {
                        d: "M75.9487 47.4793L62.4272 43.5249L66.5092 49.6989L60.3862 61.613L68.4736 61.511H80.4898L75.9487 47.4793Z",
                        fill: "#F5841F",
                      }),
                      Object(P.jsx)("path", {
                        d: "M33.5983 43.5249L20.0513 47.4793L15.5356 61.511H27.5519L35.6137 61.613L29.4908 49.6989L33.5983 43.5249Z",
                        fill: "#F5841F",
                      }),
                      Object(P.jsx)("path", {
                        d: "M51.9415 50.3617L52.8344 35.4115L56.7378 24.7729H39.262L43.1653 35.4115L44.0583 50.3617L44.3899 55.0559L44.4154 66.664H51.5843L51.6099 55.0559L51.9415 50.3617Z",
                        fill: "#F5841F",
                      }),
                    ],
                  }
                )
              );
            },
            connectorId: tn.Injected,
          },
          { title: "TrustWallet", icon: ca, connectorId: tn.Injected },
          { title: "MathWallet", icon: ua, connectorId: tn.Injected },
          { title: "TokenPocket", icon: la, connectorId: tn.Injected },
          { title: "WalletConnect", icon: da, connectorId: tn.WalletConnect },
          { title: "Binance Chain Wallet", icon: ya, connectorId: tn.BSC },
          { title: "Martian Wallet", icon: ma, connectorId: tn.BSC },
          { title: "SafePal Wallet", icon: ba, connectorId: tn.BSC },
        ],
        Ta = y.d.div(
          Ut ||
            (Ut = Object(d.a)([
              "\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  row-gap: 6px;\n  width: 100%;\n  height: 114px;\n  padding: 10px 14px;\n  border-radius: 10px;\n  cursor: pointer;\n  background: rgba(255, 255, 255, 0.1);\n\n  .modal-title {\n    color: #fff;\n    font-weight: 500;\n    font-size: 13px;\n    line-height: 20px;\n    letter-spacing: 0.04em;\n    text-shadow: 1px 7px 4px rgb(111 27 47 / 35%), 0px -1px 0px #b64034;\n    text-align: center;\n    transition: 0.3s ease;\n  }\n  svg {\n    transition: 0.3s ease;\n  }\n\n  &:hover {\n    .modal-title {\n      font-size: 15px;\n    }\n    svg {\n      width: 42px;\n    }\n  }\n\n  ",
              " {\n    .modal-title {\n      font-size: 16px;\n      line-height: 100%;\n    }\n\n    &:hover {\n      .modal-title {\n        font-size: 18px;\n      }\n      svg {\n        width: 42px;\n      }\n    }\n  }\n",
            ])),
          function (e) {
            return e.theme.mediaQueries.sm;
          }
        ),
        xa = function (e) {
          var n = e.login,
            t = e.walletConfig,
            a = e.onDismiss,
            i = t.title,
            s = t.icon;
          return Object(P.jsxs)(Ta, {
            id: "wallet-connect-".concat(i.toLocaleLowerCase()),
            onClick: function () {
              n(t.connectorId),
                window.localStorage.setItem(jn, t.connectorId),
                a();
            },
            children: [
              Object(P.jsx)("div", { className: "modal-title", children: i }),
              Object(P.jsx)(s, { width: "40px" }),
            ],
          });
        },
        ha = y.d.div(
          Kt ||
            (Kt = Object(d.a)([
              "\n  padding: 30px 0px 40px;\n  ",
              " {\n    padding: 40px 14px 60px;\n  }\n\n  .title {\n    font-family: 'Monument Extended';\n    font-style: normal;\n    font-weight: 400;\n    font-size: 18px;\n    line-height: 32px;\n    /* identical to box height, or 152% */\n    color: #fcfcfd;\n    margin-bottom: 32px;\n    ",
              " {\n      font-size: 21px;\n      line-height: 100%;\n    }\n  }\n\n  .description {\n    font-style: normal;\n    font-weight: 400;\n    font-size: 14px;\n    line-height: 16px;\n    text-align: center;\n    color: #f1f1f1;\n    margin-bottom: 32px;\n\n    a {\n      color: #3772ff;\n    }\n  }\n",
            ])),
          function (e) {
            return e.theme.mediaQueries.sm;
          },
          function (e) {
            return e.theme.mediaQueries.sm;
          }
        ),
        ja = y.d.div(
          Wt ||
            (Wt = Object(d.a)([
              "\n  display: flex;\n  flex-direction: column;\n  row-gap: 20px;\n  .btn-logout {\n    width: fit-content;\n    margin: 0 auto;\n  }\n",
            ]))
        ),
        ga = function () {
          var e = Object(T.b)(),
            n = Hn(),
            t = n.login,
            a = n.logout,
            i = Object(f.d)().account,
            s = Object(T.c)(function (e) {
              return e.modal.modalConnect;
            }).toggle,
            r = function () {
              e(V({ toggle: !1 }));
            };
          return Object(P.jsx)(
            Kn.a,
            {
              visible: s,
              centered: !0,
              width: 530,
              footer: null,
              closeIcon: Object(P.jsx)("img", {
                src: "/images/icons/close.png",
                alt: "",
              }),
              onCancel: r,
              className: "modal-connect-wallet",
              children: Object(P.jsx)(ha, {
                children: i
                  ? Object(P.jsxs)(ja, {
                      children: [
                        Object(P.jsx)("div", {
                          className: "title",
                          children: "YOUR WALLET",
                        }),
                        Object(P.jsx)(pa, {
                          title: "Your address",
                          value: i,
                          height: "44px",
                          children: i,
                        }),
                        Object(P.jsx)(Qn, {
                          className: "btn-logout",
                          onClick: function () {
                            a(), r();
                          },
                          children: "Logout",
                        }),
                      ],
                    })
                  : Object(P.jsx)(P.Fragment, {
                      children: Object(P.jsx)("div", {
                        className: "bg-modal",
                        children: Object(P.jsxs)("div", {
                          className: "content-modal",
                          children: [
                            Object(P.jsx)("div", {
                              className: "title",
                              children: "Connect to a Wallet",
                            }),
                            Object(P.jsx)(Wn.a, {
                              gutter: [24, 24],
                              children: fa.map(function (e) {
                                return Object(P.jsx)(
                                  zn.a,
                                  {
                                    span: 12,
                                    children: Object(P.jsx)(
                                      xa,
                                      {
                                        walletConfig: e,
                                        login: t,
                                        onDismiss: r,
                                      },
                                      e.title
                                    ),
                                  },
                                  e.title
                                );
                              }),
                            }),
                          ],
                        }),
                      }),
                    }),
              }),
            },
            "modal-connect"
          );
        },
        Oa = r.a.memo(ga),
        _a = (t(740), t(820)),
        Aa = ["item"],
        Ca = y.d.div(
          zt ||
            (zt = Object(d.a)([
              "\n  display: none;\n\n  &.active {\n    display: block;\n  }\n\n  p {\n    a {\n      position: relative;\n      padding-bottom: 6px;\n\n      &:hover,\n      &.active {\n        color: #786bff;\n\n        &:before {\n          content: '';\n          position: absolute;\n          height: 2px;\n          width: 100%;\n          bottom: 0;\n          background: linear-gradient(99.46deg, #fa00ff -10.9%, #00e0ff 97.13%, #2ad4f9 97.14%);\n          border-radius: 8px;\n        }\n      }\n    }\n  }\n",
            ]))
        ),
        va = function (e) {
          var n = e.item,
            t = Object(ke.a)(e, Aa),
            a = Object(Ne.g)();
          return Object(P.jsx)(P.Fragment, {
            children: Object(P.jsx)(
              Ca,
              Object(h.a)(
                Object(h.a)({}, t),
                {},
                {
                  children: Object(P.jsx)("div", {
                    className: "menu-child",
                    children: n.map(function (e) {
                      return Object(P.jsx)(
                        "p",
                        {
                          children: e.target
                            ? Object(P.jsx)("a", {
                                href: e.url,
                                target: "_blank",
                                rel: "noreferrer",
                                children: e.name,
                              })
                            : Object(P.jsx)(Be.b, {
                                className: "".concat(
                                  e.active.indexOf(a.pathname) > -1
                                    ? "active"
                                    : ""
                                ),
                                to: e.url,
                                children: e.name,
                              }),
                        },
                        "child-".concat(e.id)
                      );
                    }),
                  }),
                }
              )
            ),
          });
        },
        Ea = ["item"],
        wa = y.d.div(
          Ht ||
            (Ht = Object(d.a)([
              "\n  &:not(:last-child) {\n    margin-bottom: 25px;\n  }\n\n  .menu-item {\n    a {\n      display: flex;\n      align-items: center;\n\n      &:hover,\n      &.active {\n        > p {\n          color: #786bff;\n\n          &:before {\n            content: '';\n            position: absolute;\n            height: 2px;\n            width: 100%;\n            bottom: -5px;\n            background: linear-gradient(99.46deg, #fa00ff -10.9%, #00e0ff 97.13%, #2ad4f9 97.14%);\n            border-radius: 8px;\n          }\n        }\n      }\n\n      p {\n        position: relative;\n        font-size: 14px;\n        line-height: 21px;\n      }\n\n      img {\n        width: 30px;\n        height: 30px;\n        margin-right: 20px;\n      }\n    }\n  }\n\n  .menu-child {\n    padding-top: 10px;\n    padding-left: 40px;\n\n    p {\n      &:not(:last-child) {\n        margin-bottom: 24px;\n      }\n    }\n  }\n",
            ]))
        ),
        Pa = function (e) {
          var n,
            t,
            a = e.item,
            i = Object(ke.a)(e, Ea),
            r = Object(s.useState)(!0),
            o = Object(j.a)(r, 2),
            p = o[0],
            u = o[1],
            l = Object(Ne.g)();
          return Object(P.jsx)(P.Fragment, {
            children: Object(P.jsxs)(
              wa,
              Object(h.a)(
                Object(h.a)({}, i),
                {},
                {
                  children: [
                    Object(P.jsx)("div", {
                      className: "menu-item",
                      onClick: function () {
                        return u(function (e) {
                          return !e;
                        });
                      },
                      children: a.child
                        ? Object(P.jsxs)("a", {
                            children: [
                              Object(P.jsx)("img", {
                                src: a.icon,
                                alt: a.name,
                              }),
                              Object(P.jsx)("p", { children: a.name }),
                            ],
                          })
                        : Object(P.jsx)(P.Fragment, {
                            children: a.target
                              ? Object(P.jsxs)("a", {
                                  href: a.url,
                                  target: "_blank",
                                  rel: "noreferrer",
                                  className: "".concat(
                                    (null === a ||
                                    void 0 === a ||
                                    null === (n = a.active) ||
                                    void 0 === n
                                      ? void 0
                                      : n.indexOf(l.pathname)) > -1 ||
                                      (null === a ||
                                      void 0 === a ||
                                      null === (t = a.active) ||
                                      void 0 === t
                                        ? void 0
                                        : t.indexOf("all")) > -1
                                      ? "active"
                                      : ""
                                  ),
                                  children: [
                                    Object(P.jsx)("img", {
                                      src: a.icon,
                                      alt: a.name,
                                    }),
                                    Object(P.jsx)("p", { children: a.name }),
                                  ],
                                })
                              : Object(P.jsxs)(Be.b, {
                                  to: a.url,
                                  children: [
                                    Object(P.jsx)("img", {
                                      src: a.icon,
                                      alt: a.name,
                                    }),
                                    Object(P.jsx)("p", { children: a.name }),
                                    " ",
                                    a.upComing &&
                                      Object(P.jsx)("span", {
                                        style: {
                                          marginLeft: "10px",
                                          fontSize: "9px",
                                        },
                                        children: "Upcoming",
                                      }),
                                  ],
                                }),
                          }),
                    }),
                    a.child &&
                      Object(P.jsx)(va, {
                        className: "".concat(p ? "active" : ""),
                        item: a.child,
                      }),
                  ],
                }
              )
            ),
          });
        },
        Ma = y.d.div(
          Zt ||
            (Zt = Object(d.a)([
              "\n  position: relative;\n  z-index: 0;\n  max-width: 100%;\n  width: 100%;\n\n  .header-top {\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    text-align: center;\n    background: #5868e9;\n    min-height: 35px;\n    padding: 8px 15px;\n    font-family: 'Poppins', sans-serif;\n    font-style: normal;\n    font-weight: 400;\n    font-size: 14px;\n    color: #bdcadb;\n  }\n\n  .content {\n    display: flex;\n    min-height: calc(100vh - 46px);\n\n    .sidebar-menu {\n      position: fixed;\n      top: 0;\n      z-index: 10;\n      transform: translateX(-100%);\n      padding: 24px 32px;\n      width: 60%;\n      min-width: 320px;\n      height: 100%;\n      background: #0c131f;\n      transition: 0.5s;\n      height: calc(100vh - 35px);\n\n      @media (min-width: 991px) {\n        position: relative;\n        transform: unset;\n        width: 250px;\n        min-width: unset;\n      }\n\n      &.active {\n        transform: translateX(0%);\n      }\n\n      p {\n        font-family: 'Poppins', sans-serif;\n        font-style: normal;\n        font-weight: 600;\n        font-size: 14px;\n        line-height: 21px;\n        color: #ffffff;\n      }\n\n      .logo {\n        margin-bottom: 50px;\n      }\n\n      .menu {\n        padding-top: 20px;\n\n        .wrap-menu-item {\n          &:not(:last-child) {\n            margin-bottom: 25px;\n          }\n\n          .menu-item {\n            display: flex;\n            align-items: center;\n\n            &.active {\n              p {\n                color: #786bff;\n              }\n            }\n\n            p {\n              font-size: 14px;\n              line-height: 21px;\n            }\n\n            img {\n              width: 30px;\n              height: 30px;\n              margin-right: 20px;\n            }\n          }\n\n          .menu-child {\n            padding-top: 10px;\n            padding-left: 40px;\n\n            p {\n              &:not(:last-child) {\n                margin-bottom: 24px;\n              }\n            }\n          }\n        }\n\n        @media (min-width: 991px) {\n          &.sticky-menu {\n            position: fixed;\n            top: 0;\n          }\n        }\n      }\n\n      .menu-toggle {\n        right: 0;\n        top: 0;\n        margin-left: 0;\n        margin-right: 24px;\n\n        @media (min-width: 991px) {\n          display: none;\n        }\n      }\n    }\n\n    .content-page {\n      padding: 24px;\n      width: 100%;\n      flex: 1;\n\n      .button-connect {\n        padding: 0 0 25px 0;\n        text-align: right;\n\n        button {\n          height: 44px;\n          background: linear-gradient(99.46deg, #fa00ff -10.9%, #00e0ff 97.13%, #2ad4f9 97.14%);\n          border-radius: 12px;\n        }\n      }\n    }\n\n    .menu-toggle {\n      position: absolute;\n      display: flex;\n      flex-direction: column;\n      margin-top: 36px;\n      margin-left: 24px;\n      justify-content: space-between;\n      width: 30px;\n      height: 20px;\n\n      @media (min-width: 991px) {\n        display: none;\n      }\n\n      span {\n        display: block;\n        width: 100%;\n        height: 15%;\n        background: #fff;\n        transform: rotate(0deg) translate(0%, 0%);\n        transition: 0.25s;\n      }\n\n      &.active {\n        span {\n          &:nth-child(1) {\n            transform: rotate(45deg) translate(19%, 210%);\n          }\n\n          &:nth-child(2) {\n            opacity: 0;\n          }\n\n          &:nth-child(3) {\n            transform: rotate(-45deg) translate(17%, -212%);\n          }\n        }\n      }\n    }\n  }\n",
            ]))
        ),
        Ra = [
          {
            id: 1,
            name: "Exchage",
            icon: "/images/menu/1.png",
            url: "",
            child: [
              {
                id: 1,
                name: "Swap",
                url: "https://swap.krakenpad.io/",
                active: [""],
                target: "_blank",
              },
              {
                id: 2,
                name: "Liquidity",
                url: "https://swap.krakenpad.io/pool",
                active: [""],
                target: "_blank",
              },
            ],
          },
          {
            id: 2,
            name: "LaunchPad",
            icon: "/images/menu/2.png",
            target: "_blank",
            active: ["all"],
          },
          {
            id: 3,
            name: "Yield Farming",
            icon: "/images/menu/3.png",
            url: "https://farm.krakenpad.io",
            target: "_blank",
          },
          { id: 4, name: "Staking", icon: "/images/menu/4.png", upComing: !0 },
          {
            id: 5,
            name: "Prediction",
            icon: "/images/menu/5.png",
            upComing: !0,
          },
          { id: 6, name: "Lottery", icon: "/images/menu/6.png", upComing: !0 },
        ],
        Ia = function (e) {
          var n = e.children,
            t = Object(T.b)(),
            a = Object(f.d)().account,
            i = Object(s.useState)(window.scrollY),
            r = Object(j.a)(i, 2),
            o = r[0],
            p = r[1],
            u = Object(s.useState)(!1),
            l = Object(j.a)(u, 2),
            c = l[0],
            d = l[1],
            y = Object(s.useState)(!1),
            m = Object(j.a)(y, 2),
            b = m[0],
            x = m[1],
            h = a
              ? ""
                  .concat(a.substring(0, 4), "...")
                  .concat(a.substring(a.length - 4))
              : void 0,
            g = Object(s.useCallback)(
              function (e) {
                var n = e.currentTarget;
                d(o > 155.5), p(n.scrollY);
              },
              [o]
            );
          return (
            Object(s.useEffect)(function () {
              p(window.scrollY);
            }, []),
            Object(s.useEffect)(
              function () {
                return (
                  window.addEventListener("scroll", function (e) {
                    return g(e);
                  }),
                  function () {
                    window.removeEventListener("scroll", function (e) {
                      return g(e);
                    });
                  }
                );
              },
              [g, o]
            ),
            Object(P.jsxs)(Ma, {
              children: [
                Object(P.jsx)("div", {
                  className: "header-top",
                  children:
                    "Always make sure the URL is krakenpad.io - bookmark it to be safe.",
                }),
                Object(P.jsxs)("div", {
                  className: "content",
                  children: [
                    Object(P.jsxs)("div", {
                      className: "sidebar-menu ".concat(b ? "active" : ""),
                      children: [
                        Object(P.jsx)("div", {
                          className: "logo",
                          children: Object(P.jsx)("img", {
                            src: "/images/logo.png",
                            alt: "logo",
                          }),
                        }),
                        Object(P.jsx)("div", {
                          className: "menu ".concat(c ? "sticky-menu" : ""),
                          children: Ra.map(function (e) {
                            return Object(P.jsx)(
                              Pa,
                              { item: e },
                              "menu-".concat(e.id)
                            );
                          }),
                        }),
                        Object(P.jsxs)("div", {
                          className: "menu-toggle ".concat(b ? "active" : ""),
                          onClick: function () {
                            return x(function (e) {
                              return !e;
                            });
                          },
                          children: [
                            Object(P.jsx)("span", {}),
                            Object(P.jsx)("span", {}),
                            Object(P.jsx)("span", {}),
                          ],
                        }),
                      ],
                    }),
                    Object(P.jsxs)("div", {
                      className: "menu-toggle ".concat(b ? "active" : ""),
                      onClick: function () {
                        return x(function (e) {
                          return !e;
                        });
                      },
                      children: [
                        Object(P.jsx)("span", {}),
                        Object(P.jsx)("span", {}),
                        Object(P.jsx)("span", {}),
                      ],
                    }),
                    Object(P.jsxs)("div", {
                      className: "content-page",
                      children: [
                        Object(P.jsx)("div", {
                          className: "button-connect",
                          children: Object(P.jsx)(Qn, {
                            onClick: function () {
                              t(V({ toggle: !0 }));
                            },
                            children: Object(P.jsx)("div", {
                              children: h || "CONNECT WALLET",
                            }),
                          }),
                        }),
                        Object(P.jsx)("div", { children: n }),
                      ],
                    }),
                  ],
                }),
              ],
            })
          );
        },
        ka = y.d.div(
          Vt ||
            (Vt = Object(d.a)([
              "\n  position: relative;\n  background: linear-gradient(#0b1742, #0d1420);\n\n  .container {\n    width: 100%;\n    max-width: 1164px;\n    margin: auto;\n    padding: 0 15px;\n  }\n\n  .banner {\n    .banner-content {\n      background-image: url('/images/footer/bg-banner.png');\n      background-size: 100% 100%;\n      padding: 30px 15px;\n\n      @media (min-width: 991px) {\n        padding: 65px;\n      }\n\n      p {\n        font-style: normal;\n        font-weight: 400;\n        font-size: 14px;\n        line-height: 150%;\n        color: #64609f;\n\n        @media (min-width: 991px) {\n          font-size: 16px;\n          line-height: 24px;\n        }\n\n        &.banner-title {\n          font-family: 'Monument Extended';\n          font-style: normal;\n          font-weight: 400;\n          font-size: 18px;\n          line-height: 150%;\n          color: #f2f2f2;\n          margin-bottom: 11px;\n\n          @media (min-width: 991px) {\n            font-size: 24px;\n            line-height: 48px;\n          }\n        }\n\n        &.title-contact {\n          font-style: normal;\n          font-weight: 600;\n          font-size: 16px;\n          line-height: 24px;\n          color: #f0f6ff;\n        }\n      }\n\n      button {\n        font-style: normal;\n        font-weight: 600;\n        font-size: 16px;\n        line-height: 24px;\n        color: #5868e9;\n        background: #fafcff;\n        border-radius: 12px;\n        padding: 6px 16px;\n        cursor: pointer;\n        margin-top: 16px;\n        border: none;\n\n        @media (min-width: 991px) {\n          padding: 8px 24px;\n          margin-top: 24px;\n        }\n      }\n    }\n  }\n\n  .footer-content {\n    margin: auto;\n    max-width: 1164px;\n    padding: 0 15px;\n    padding-top: 88px;\n\n    .logo-footer {\n      width: 153px;\n      max-width: 100%;\n      margin-bottom: 27px;\n    }\n\n    .description-footer {\n      font-style: normal;\n      font-weight: 400;\n      font-size: 14px;\n      line-height: 22px;\n      color: #bdcadb;\n    }\n\n    p {\n      font-style: normal;\n      font-weight: 400;\n      font-size: 14px;\n      line-height: 22px;\n      color: #bdcadb;\n\n      &.title-menu {\n        font-style: normal;\n        font-weight: 600;\n        font-size: 16px;\n        line-height: 24px;\n        color: #f0f6ff;\n        margin-bottom: 24px;\n      }\n    }\n\n    ul {\n      padding: 0;\n      margin: 0;\n      list-style-type: none;\n\n      li {\n        &:not(:last-child) {\n          margin-bottom: 16px;\n        }\n\n        a {\n          font-style: normal;\n          font-weight: 400;\n          font-size: 14px;\n          line-height: 21px;\n          color: #bdcadb;\n        }\n      }\n\n      &.menu-social {\n        display: flex;\n        align-items: center;\n\n        li {\n          margin-bottom: 0;\n\n          &:not(last-child) {\n            margin-right: 16px;\n          }\n        }\n\n        img {\n          width: 20px;\n          height: 20px;\n          object-fit: contain;\n        }\n      }\n    }\n\n    .copy-right {\n      font-style: normal;\n      font-weight: 400;\n      font-size: 14px;\n      line-height: 22px;\n      color: #64609f;\n      text-align: center;\n      margin-top: 30px;\n      padding-bottom: 22px;\n    }\n  }\n\n  .join-us {\n    padding-top: 32px;\n\n    @media (min-width: 991px) {\n      padding-top: 0;\n    }\n\n    .content-left {\n      max-width: 365px;\n\n      p {\n        &:nth-child(1) {\n          font-style: normal;\n          font-weight: 400;\n          font-size: 16px;\n          line-height: 24px;\n          color: #64609f;\n          margin-bottom: 11px;\n        }\n\n        &:nth-child(2) {\n          font-family: 'Monument Extended';\n          font-style: normal;\n          font-weight: 400;\n          font-size: 24px;\n          line-height: 48px;\n          color: #f2f2f2;\n          margin-bottom: 11px;\n        }\n      }\n\n      button {\n        padding-right: 8px;\n\n        img {\n          margin-left: 16px;\n          width: 20px;\n\n          @media (min-width: 991px) {\n            width: 30px;\n          }\n        }\n      }\n    }\n  }\n",
            ]))
        ),
        Na = function (e) {
          var n = Object.assign({}, e);
          return Object(P.jsx)(ka, Object(h.a)({}, n));
        },
        Ba = function (e) {
          var n = e.children;
          return Object(P.jsxs)(_a.a, {
            className: "public-layout",
            children: [
              Object(P.jsx)(Ia, {
                children: Object(P.jsx)("div", { children: n }),
              }),
              Object(P.jsx)(Na, {}),
            ],
          });
        },
        Sa = t(373),
        La = new Sa.a();
      var Da,
        Fa,
        Ua = t(821),
        Ka = t(818),
        Wa = y.d.div(
          Da ||
            (Da = Object(d.a)([
              "\n  width: 100%;\n\n  .item-pool {\n    background: #0c131f;\n    border-radius: 10px;\n    padding: 32px 15px;\n\n    @media (min-width: 991px) {\n      padding: 45px 32px;\n    }\n\n    .header-info {\n      margin-bottom: 33px;\n\n      display: flex;\n      align-items: center;\n\n      .logo {\n        margin-right: 17px;\n\n        img {\n          width: 65px;\n        }\n      }\n\n      .name {\n        p {\n          &:nth-child(1) {\n            font-family: 'Monument Extended';\n            font-style: normal;\n            font-weight: 400;\n            font-size: 16px;\n            line-height: 100%;\n            text-transform: capitalize;\n            color: #f0f6ff;\n            margin-bottom: 15px;\n          }\n          &:nth-child(2) {\n            position: relative;\n            display: flex;\n            align-items: center;\n            justify-content: center;\n            font-style: normal;\n            font-weight: 600;\n            font-size: 12px;\n            line-height: 100%;\n            text-align: center;\n            color: #44c99c;\n            background: #d5f3e9;\n            border-radius: 3px;\n            width: 95px;\n            height: 24px;\n\n            &:before {\n              content: '';\n              position: relative;\n              width: 6px;\n              height: 6px;\n              margin-right: 5px;\n              border-radius: 50%;\n              background: #44c99c;\n            }\n\n            &.upcoming {\n              color: #f9aa4b;\n              background: #ffe6c8;\n\n              &:before {\n                background: #f9aa4b;\n              }\n            }\n\n            &.completed {\n              color: #fc3868;\n              background: #ffeaef;\n\n              &:before {\n                background: #fc3868;\n              }\n            }\n          }\n        }\n      }\n    }\n\n    .item-body {\n      display: flex;\n      flex-direction: column;\n      row-gap: 16px;\n      text-align: center;\n\n      > div {\n        display: flex;\n        flex-direction: column;\n        row-gap: 8px;\n\n        p {\n          &:first-child {\n            font-style: normal;\n            font-weight: 400;\n            font-size: 14px;\n            line-height: 22px;\n            color: #bdcadb;\n          }\n\n          &:nth-child(2) {\n            font-family: 'Monument Extended';\n            font-style: normal;\n            font-weight: 400;\n            font-size: 16px;\n            line-height: 19px;\n            letter-spacing: -0.02em;\n            color: #f0f6ff;\n          }\n\n          &.total {\n            font-family: 'Monument Extended';\n            font-style: normal;\n            font-weight: 400;\n            font-size: 26px;\n            line-height: 38px;\n            letter-spacing: -0.02em;\n            color: #776bff;\n\n            @media (min-width: 991px) {\n              font-size: 32px;\n            }\n          }\n        }\n\n        button {\n          width: 126px;\n          margin: auto;\n        }\n      }\n    }\n  }\n",
            ]))
        ),
        za = y.d.div(
          Fa ||
            (Fa = Object(d.a)([
              "\n  padding: 1px;\n  background: linear-gradient(to right, #fa00ff, #00e0ff, #2ad4f9);\n  border-radius: 10px;\n",
            ]))
        ),
        Ha = function (e) {
          var n = e.data,
            t = e.setDataDetail,
            a = e.setView;
          return Object(P.jsx)(Wa, {
            children: Object(P.jsx)(Wn.a, {
              gutter: [32, 32],
              children: n.map(function (e, n) {
                return Object(P.jsx)(
                  zn.a,
                  {
                    span: 24,
                    lg: { span: 8 },
                    children: Object(P.jsx)(za, {
                      children: Object(P.jsxs)("div", {
                        className: "item-pool",
                        children: [
                          Object(P.jsxs)("div", {
                            className: "header-info",
                            children: [
                              Object(P.jsx)("div", {
                                className: "logo",
                                children: Object(P.jsx)("img", {
                                  src: e.logo,
                                  alt: "",
                                }),
                              }),
                              Object(P.jsxs)("div", {
                                className: "name",
                                children: [
                                  Object(P.jsx)("p", { children: e.name }),
                                  Object(P.jsx)("p", {
                                    className: "".concat(
                                      "Upcoming" === e.status
                                        ? "upcoming"
                                        : "Completed" === e.status
                                        ? "completed"
                                        : ""
                                    ),
                                    children: e.status,
                                  }),
                                ],
                              }),
                            ],
                          }),
                          Object(P.jsxs)("div", {
                            className: "item-body",
                            children: [
                              Object(P.jsxs)("div", {
                                children: [
                                  Object(P.jsx)("p", {
                                    children: "Total Raise",
                                  }),
                                  Object(P.jsx)("p", {
                                    className: "total",
                                    children: e.total,
                                  }),
                                ],
                              }),
                              Object(P.jsxs)("div", {
                                children: [
                                  Object(P.jsx)("p", {
                                    children: "Sale Price",
                                  }),
                                  Object(P.jsx)("p", {
                                    className: "price",
                                    children: e.price,
                                  }),
                                ],
                              }),
                              Object(P.jsxs)("div", {
                                children: [
                                  Object(P.jsx)("p", {
                                    children: "Sale Start In",
                                  }),
                                  Object(P.jsx)("p", {
                                    className: "time",
                                    children: e.timeStart,
                                  }),
                                ],
                              }),
                              Object(P.jsx)("div", {
                                children: Object(P.jsx)(Qn, {
                                  onClick: function () {
                                    return (function (e) {
                                      t(e), a(null);
                                    })(e);
                                  },
                                  children: "View Pool",
                                }),
                              }),
                            ],
                          }),
                        ],
                      }),
                    }),
                  },
                  n
                );
              }),
            }),
          });
        };
      var Za,
        Va,
        Ga,
        Ya,
        Ja,
        qa = ["remains", "onFinish"],
        Xa = y.d.div(
          Za ||
            (Za = Object(d.a)(["\n  display: flex;\n  align-items: center;\n"]))
        ),
        Qa = y.d.div(
          Va ||
            (Va = Object(d.a)([
              "\n  display: flex;\n  align-items: center;\n  margin-left: 2px;\n  margin-right: 2px;\n\n  > div {\n    font-size: 14px;\n  }\n",
            ]))
        ),
        $a = function (e) {
          var n = e.remains,
            t = e.onFinish,
            a = Object(ke.a)(e, qa),
            i = Object(s.useState)({
              weekdays: 0,
              days: 0,
              hours: 0,
              minutes: 0,
              seconds: 0,
              totalRemain: 0,
            }),
            r = Object(j.a)(i, 2),
            o = r[0],
            p = r[1];
          return (
            Object(s.useEffect)(
              function () {
                var e = 0;
                function a() {
                  var a = new Date().getTime(),
                    i = new Date(n).getTime();
                  i - a > 0
                    ? p(
                        Object(h.a)(
                          Object(h.a)(
                            {},
                            (function (e, n) {
                              var t = new Date(n) - new Date(e),
                                a = Math.floor(t / 1e3 / 60 / 60 / 24 / 7),
                                i = Math.floor(t / 1e3 / 60 / 60 / 24 - 7 * a),
                                s = Math.floor(
                                  t / 1e3 / 60 / 60 - 7 * a * 24 - 24 * i
                                ),
                                r = Math.floor(
                                  t / 1e3 / 60 -
                                    7 * a * 24 * 60 -
                                    24 * i * 60 -
                                    60 * s
                                ),
                                o = Math.floor(
                                  t / 1e3 -
                                    7 * a * 24 * 60 * 60 -
                                    24 * i * 60 * 60 -
                                    60 * s * 60 -
                                    60 * r
                                ),
                                p = Math.floor(
                                  t -
                                    7 * a * 24 * 60 * 60 * 1e3 -
                                    24 * i * 60 * 60 * 1e3 -
                                    60 * s * 60 * 1e3 -
                                    60 * r * 1e3 -
                                    1e3 * o
                                ),
                                u = {};
                              return (
                                Object.entries({
                                  weekdays: a,
                                  days: i,
                                  hours: s,
                                  minutes: r,
                                  seconds: o,
                                  milliseconds: p,
                                }).forEach(function (e) {
                                  var n = Object(j.a)(e, 2),
                                    t = n[0],
                                    a = n[1];
                                  u[t] = a > 0 ? a : 0;
                                }),
                                u
                              );
                            })(a, i)
                          ),
                          {},
                          { totalRemain: i - a }
                        )
                      )
                    : (p({
                        weekdays: 0,
                        days: 0,
                        hours: 0,
                        minutes: 0,
                        seconds: 0,
                        totalRemain: 0,
                      }),
                      t && t(),
                      clearInterval(e));
                }
                return (
                  a(),
                  (e = setInterval(function () {
                    return a();
                  }, 1e3)),
                  function () {
                    clearInterval(e);
                  }
                );
              },
              [t, n]
            ),
            Object(P.jsxs)(
              Xa,
              Object(h.a)(
                Object(h.a)({}, a),
                {},
                {
                  children: [
                    Object(P.jsx)(Qa, {
                      children: Object(P.jsx)("div", {
                        children: (o.days + 7 * o.weekdays)
                          .toString()
                          .padStart(2, "0"),
                      }),
                    }),
                    Object(P.jsx)(Qa, {
                      children: Object(P.jsx)("div", {
                        children: o.hours.toString().padStart(2, "0"),
                      }),
                    }),
                    Object(P.jsx)(Qa, {
                      children: Object(P.jsx)("div", {
                        children: o.minutes.toString().padStart(2, "0"),
                      }),
                    }),
                    Object(P.jsx)(Qa, {
                      children: Object(P.jsx)("div", {
                        children: o.seconds.toString().padStart(2, "0"),
                      }),
                    }),
                  ],
                }
              )
            )
          );
        },
        ei = r.a.memo($a),
        ni = Ua.a.Option,
        ti = y.d.div(
          Ga ||
            (Ga = Object(d.a)([
              "\n  .wrapper-footer {\n    p {\n      font-style: normal;\n      font-weight: 400;\n      font-size: 14px;\n      line-height: 22px;\n      color: #bdcadb;\n      text-align: center;\n    }\n  }\n\n  .wrapper-menu-control-view {\n    overflow: auto;\n    -ms-overflow-style: none;\n    scrollbar-width: none;\n\n    ::-webkit-scrollbar {\n      display: none;\n    }\n  }\n\n  .menu-control-view {\n    display: flex;\n    align-items: center;\n    width: 100%;\n    height: 71px;\n    background: #0c131f;\n    border-radius: 10px;\n    padding: 16px 0;\n    margin-bottom: 24px;\n    width: max-content;\n\n    @media (min-width: 991px) {\n      width: 100%;\n    }\n\n    ul {\n      display: flex;\n      align-items: center;\n      justify-content: space-around;\n      width: 100%;\n      list-style-type: none;\n      margin: 0;\n      padding: 0;\n\n      li {\n        &:not(:last-child) {\n          margin-right: 5px;\n        }\n\n        button {\n          position: relative;\n          font-family: 'Monument Extended';\n          font-style: normal;\n          font-weight: 400;\n          font-size: 12px;\n          line-height: 100%;\n          color: #6f6a79;\n          background: none;\n          border: none;\n          cursor: pointer;\n\n          &.active {\n            color: #776bff;\n\n            &:before {\n              content: '';\n              position: absolute;\n              bottom: -7px;\n              left: 50%;\n              transform: translate(-50%, 0);\n              width: 100%;\n              height: 2px;\n              background: linear-gradient(99.46deg, #fa00ff -10.9%, #00e0ff 97.13%, #2ad4f9 97.14%);\n              border-radius: 8px;\n            }\n          }\n        }\n\n        .ant-select-selector {\n          display: flex;\n          align-items: center;\n          height: 34px;\n          background: transparent;\n          border: 1px solid #3d424c;\n          border-radius: 8px;\n\n          .ant-select-selection-item {\n            color: #fff;\n\n            img {\n              margin-right: 5px;\n            }\n          }\n        }\n\n        .ant-select-arrow .anticon > svg {\n          fill: #fff;\n        }\n      }\n    }\n  }\n\n  .content-launch-pad {\n    width: 100%;\n    min-height: 320px;\n  }\n\n  .content-pool-detail {\n    .content-left {\n      display: flex;\n      padding: 26px 15px;\n      background: #0c131f;\n      border-radius: 10px;\n      flex-direction: column;\n\n      @media (min-width: 991px) {\n        flex-direction: row;\n        padding: 26px;\n      }\n\n      .content-left-left {\n        width: 65px;\n        margin-right: 0;\n        margin-bottom: 16px;\n\n        @media (min-width: 991px) {\n          margin-right: 17px;\n          margin-bottom: 0;\n        }\n\n        img {\n          width: 100%;\n        }\n      }\n      .content-left-right {\n        flex: 1;\n\n        .name {\n          font-family: 'Monument Extended';\n          font-style: normal;\n          font-weight: 400;\n          font-size: 16px;\n          line-height: 100%;\n          color: #f0f6ff;\n          margin-bottom: 20px;\n        }\n\n        .social {\n          margin-bottom: 16px;\n\n          ul {\n            display: flex;\n            align-items: center;\n            list-style-type: none;\n            padding: 0;\n            margin: 0;\n\n            li {\n              &:not(:last-child) {\n                margin-right: 16px;\n              }\n            }\n          }\n        }\n\n        .text-content {\n          font-style: normal;\n          font-weight: 400;\n          font-size: 14px;\n          line-height: 22px;\n          color: #bdcadb;\n          margin-bottom: 44px;\n        }\n\n        .box-information {\n          > div {\n            &:not(:last-child) {\n              margin-bottom: 8px;\n            }\n          }\n\n          .information-item {\n            display: flex;\n            align-items: flex-start;\n            justify-content: space-between;\n            flex-direction: column;\n\n            @media (min-width: 768px) {\n              align-items: center;\n              flex-direction: row;\n            }\n\n            &.contact {\n              .box-address {\n                position: relative;\n\n                input {\n                  background: rgba(24, 32, 63, 0.05);\n                  min-height: 44px;\n                  padding: 12px 4px 12px 12px;\n                  background: transparent;\n                  border: none;\n                  outline: none;\n                  width: 100%;\n                  max-width: 100%;\n                  border: 1px solid rgba(255, 255, 255, 0.05);\n                  border-radius: 12px;\n                  padding-right: 47px;\n\n                  @media (min-width: 991px) {\n                    width: 440px;\n                  }\n\n                  &::placeholder {\n                    font-weight: 400;\n                    font-size: 16px;\n                    line-height: 24px;\n                    color: #9d9bb9;\n                  }\n                }\n\n                img {\n                  position: absolute;\n                  width: 39px;\n                  right: 4px;\n                  top: 50%;\n                  transform: translate(0, -50%);\n                  cursor: pointer;\n                }\n              }\n            }\n\n            p {\n              &:first-child {\n                font-style: normal;\n                font-weight: 500;\n                font-size: 14px;\n                line-height: 100%;\n                color: #bdcadb;\n              }\n\n              &:last-child {\n                font-style: normal;\n                font-weight: 500;\n                font-size: 14px;\n                line-height: 21px;\n                letter-spacing: -0.02em;\n                color: #776bff;\n              }\n            }\n          }\n        }\n      }\n    }\n\n    .content-right {\n      padding: 24px 15px;\n      background: #0c131f;\n      border-radius: 10px;\n\n      @media (min-width: 991px) {\n        padding: 24px;\n      }\n\n      .title {\n        font-family: 'Monument Extended';\n        font-style: normal;\n        font-weight: 400;\n        font-size: 16px;\n        line-height: 100%;\n        text-transform: capitalize;\n        color: #f0f6ff;\n        text-align: center;\n        margin-bottom: 19px;\n      }\n\n      .countdown {\n        justify-content: center;\n        margin-bottom: 42px;\n\n        > div {\n          align-items: center;\n          justify-content: center;\n          width: 55px;\n          height: 50px;\n          background: #776bff;\n          border: 1px solid #776bff;\n          border-radius: 8px;\n          margin-left: 0;\n          margin-right: 0;\n\n          &:not(:last-child) {\n            margin-right: 9px;\n          }\n\n          div {\n            font-family: 'Monument Extended';\n            font-style: normal;\n            font-weight: 400;\n            font-size: 24px;\n            line-height: 29px;\n            letter-spacing: -0.02em;\n            color: #ffffff;\n          }\n        }\n      }\n\n      .price-claim {\n        display: flex;\n        align-items: center;\n        justify-content: center;\n        font-family: 'Monument Extended';\n        font-style: normal;\n        font-weight: 400;\n        font-size: 24px;\n        line-height: 29px;\n        text-align: center;\n        letter-spacing: -0.02em;\n        color: #ffffff;\n        background: #776bff;\n        border: 1px solid #776bff;\n        border-radius: 8px;\n        width: 218px;\n        height: 50px;\n        max-width: 100%;\n        margin: auto;\n        margin-bottom: 19px;\n      }\n\n      .process {\n        margin-bottom: 11px;\n\n        .process-top {\n          display: flex;\n          align-items: center;\n          justify-content: space-between;\n          margin-bottom: 7px;\n\n          p {\n            font-style: normal;\n            font-weight: 400;\n            font-size: 14px;\n            line-height: 22px;\n            color: #bdcadb;\n          }\n        }\n\n        .process-content {\n          margin-bottom: 10px;\n\n          .ant-slider-handle {\n            display: none;\n          }\n\n          .ant-slider {\n            margin: 0;\n          }\n\n          .ant-slider-rail,\n          .ant-slider-track,\n          .ant-slider-step {\n            height: 8px !important;\n            background: rgba(102, 102, 102, 0.29) !important;\n            border-radius: 20px !important;\n          }\n\n          .ant-slider-track {\n            background: #a57ff6 !important;\n          }\n        }\n\n        > p {\n          font-style: normal;\n          font-weight: 500;\n          font-size: 12px;\n          line-height: 18px;\n          letter-spacing: -0.02em;\n          color: #d1ff4f;\n          margin-bottom: 11px;\n        }\n\n        .box-input-amount {\n          margin-bottom: 32px;\n\n          .box-input-top {\n            display: flex;\n            align-items: center;\n            justify-content: space-between;\n            margin-bottom: 7px;\n\n            p {\n              &:first-child {\n                font-style: normal;\n                font-weight: 400;\n                font-size: 14px;\n                line-height: 22px;\n                color: #bdcadb;\n              }\n\n              &:last-child {\n                font-style: normal;\n                font-weight: 400;\n                font-size: 14px;\n                line-height: 22px;\n                color: #a57ff6;\n                cursor: pointer;\n              }\n            }\n          }\n          .box-input-content {\n            input {\n              font-weight: 400;\n              font-size: 16px;\n              line-height: 24px;\n              width: 100%;\n              height: 40px;\n              padding: 8px 15px;\n              background: transparent;\n              border: 1px solid #262b34;\n              border-radius: 5px;\n              outline: none;\n            }\n          }\n        }\n\n        .box-info-claim {\n          padding-top: 11px;\n          margin-bottom: 24px;\n\n          > div {\n            display: flex;\n            justify-content: space-between;\n\n            &:not(:last-child) {\n              margin-bottom: 8px;\n            }\n\n            p {\n              &:first-child {\n                font-style: normal;\n                font-weight: 500;\n                font-size: 14px;\n                line-height: 100%;\n                color: #bdcadb;\n                width: 115px;\n              }\n\n              &:last-child {\n                font-style: normal;\n                font-weight: 500;\n                font-size: 14px;\n                line-height: 21px;\n                letter-spacing: -0.02em;\n                color: #776bff;\n                flex: 1;\n                text-align: right;\n              }\n            }\n          }\n        }\n      }\n    }\n  }\n",
            ]))
        ),
        ai = y.d.div(
          Ya ||
            (Ya = Object(d.a)([
              "\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  flex-wrap: wrap;\n  width: 100%;\n  background: #0c131f;\n  border-radius: 5px;\n  margin-bottom: 33px;\n  padding: 0 15px;\n\n  @media (min-width: 991px) {\n    padding: 0 56px;\n  }\n\n  .banner-text {\n    padding: 40px 0;\n    height: max-content;\n\n    p {\n      max-width: 539px;\n      width: 100%;\n\n      &:first-child {\n        font-family: 'Monument Extended';\n        font-style: normal;\n        font-weight: 400;\n        font-size: 24px;\n        line-height: 48px;\n        text-transform: capitalize;\n        color: #f0f6ff;\n\n        @media (min-width: 991px) {\n          font-size: 32px;\n        }\n      }\n\n      &:last-child {\n        font-weight: 400;\n        font-size: 14px;\n        line-height: 22px;\n        color: #bdcadb;\n      }\n    }\n  }\n\n  .content-right {\n    width: 300px;\n\n    .wrap-image {\n      position: relative;\n\n      img {\n        display: block;\n        width: 100%;\n        margin-bottom: -34px;\n      }\n    }\n  }\n",
            ]))
        ),
        ii = y.d.div(
          Ja ||
            (Ja = Object(d.a)([
              "\n  padding: 1px;\n  background: linear-gradient(to right, #fa00ff, #00e0ff, #2ad4f9);\n  border-radius: 10px;\n  height: 100%;\n\n  > div {\n    height: 100%;\n  }\n",
            ]))
        ),
        si = [
          {
            name: "ANNOUNCEMENT SOON",
            logo: "/images/main-deploy/logo.png",
            status: "Upcoming",
            total: "---",
            price: "---",
            timeStart: "---",
            description:
              "A potential project, with the first collaboration with KrakenPad, supported by media and advise on technology, is expected to bring a new breeze in the blockchain field.",
            contract: "0x0000000000000000000000000000000000000",
            swapRate: "---",
            IDOSupply: "---",
            startPool: "---",
            endPool: "---",
          },
        ],
        ri = [],
        oi = function () {
          var e = Object(s.useState)(0),
            n = Object(j.a)(e, 2),
            t = n[0],
            a = n[1],
            i = Object(s.useState)(!0),
            r = Object(j.a)(i, 2),
            o = (r[0], r[1], Object(s.useState)()),
            p = Object(j.a)(o, 2),
            u = p[0],
            l = p[1],
            c = function (e) {
              a(e), l(null);
            };
          return Object(P.jsxs)(ti, {
            children: [
              Object(P.jsxs)(ai, {
                children: [
                  Object(P.jsxs)("div", {
                    className: "banner-text",
                    children: [
                      Object(P.jsx)("p", {
                        children:
                          "LauncPad platform across all main blockchain networks",
                      }),
                      Object(P.jsx)("p", {
                        children:
                          "Kraken Launchpad enables $KRP token holders to take part in some of the most exclusive opportunities in the crypto industry.",
                      }),
                    ],
                  }),
                  Object(P.jsx)("div", {
                    className: "content-right",
                    children: Object(P.jsx)("div", {
                      className: "wrap-image",
                      children: Object(P.jsx)("img", {
                        src: "/images/banner.png",
                        alt: "",
                      }),
                    }),
                  }),
                ],
              }),
              Object(P.jsx)("div", {
                className: "wrapper-menu-control-view",
                children: Object(P.jsx)("div", {
                  className: "menu-control-view",
                  children: Object(P.jsxs)("ul", {
                    children: [
                      Object(P.jsx)("li", {
                        children: Object(P.jsxs)("button", {
                          onClick: function () {
                            return c(0);
                          },
                          className: "".concat(0 === t ? "active" : ""),
                          children: ["All (", si.length, ")"],
                        }),
                      }),
                      Object(P.jsx)("li", {
                        children: Object(P.jsxs)("button", {
                          onClick: function () {
                            return c(1);
                          },
                          className: "".concat(1 === t ? "active" : ""),
                          children: [
                            "On Going (",
                            si.filter(function (e) {
                              return "On Going" === e.status;
                            }).length,
                            ")",
                          ],
                        }),
                      }),
                      Object(P.jsx)("li", {
                        children: Object(P.jsxs)("button", {
                          onClick: function () {
                            return c(2);
                          },
                          className: "".concat(2 === t ? "active" : ""),
                          children: [
                            "Upcoming (",
                            si.filter(function (e) {
                              return "Upcoming" === e.status;
                            }).length,
                            ")",
                          ],
                        }),
                      }),
                      Object(P.jsx)("li", {
                        children: Object(P.jsxs)("button", {
                          onClick: function () {
                            return c(3);
                          },
                          className: "".concat(3 === t ? "active" : ""),
                          children: [
                            "Completed (",
                            si.filter(function (e) {
                              return "Completed" === e.status;
                            }).length,
                            ")",
                          ],
                        }),
                      }),
                      Object(P.jsx)("li", {
                        children: Object(P.jsxs)("button", {
                          onClick: function () {
                            return c(4);
                          },
                          className: "".concat(4 === t ? "active" : ""),
                          children: ["Participated (", ri.length, ")"],
                        }),
                      }),
                      Object(P.jsx)("li", {
                        children: Object(P.jsx)("button", {
                          onClick: function () {
                            return c(5);
                          },
                          className: "".concat(5 === t ? "active" : ""),
                          children: "BNB Chain",
                        }),
                      }),
                      Object(P.jsx)("li", {
                        children: Object(P.jsxs)(Ua.a, {
                          defaultValue: "Ethereum",
                          style: { width: 145 },
                          children: [
                            Object(P.jsxs)(ni, {
                              value: "Ethereum",
                              children: [
                                Object(P.jsx)("img", {
                                  src: "/images/icons/1.png",
                                  alt: "",
                                }),
                                " Ethereum",
                              ],
                            }),
                            Object(P.jsxs)(ni, {
                              value: "BNB Chain",
                              children: [
                                Object(P.jsx)("img", {
                                  src: "/images/icons/2.png",
                                  alt: "",
                                }),
                                " BNB Chain",
                              ],
                            }),
                            Object(P.jsxs)(ni, {
                              value: "Solana",
                              children: [
                                Object(P.jsx)("img", {
                                  src: "/images/icons/3.png",
                                  alt: "",
                                }),
                                " Solana",
                              ],
                            }),
                            Object(P.jsxs)(ni, {
                              value: "Avalanche",
                              children: [
                                Object(P.jsx)("img", {
                                  src: "/images/icons/4.png",
                                  alt: "",
                                }),
                                " Avalanche",
                              ],
                            }),
                            Object(P.jsxs)(ni, {
                              value: "Matic (polygon)",
                              children: [
                                Object(P.jsx)("img", {
                                  src: "/images/icons/5.png",
                                  alt: "",
                                }),
                                " Matic (polygon)",
                              ],
                            }),
                            Object(P.jsxs)(ni, {
                              value: "Aptos Chain",
                              children: [
                                Object(P.jsx)("img", {
                                  src: "/images/icons/6.png",
                                  alt: "",
                                }),
                                " Aptos Chain",
                              ],
                            }),
                            Object(P.jsxs)(ni, {
                              value: "BNB Chain test",
                              styles: { position: "relative" },
                              children: [
                                Object(P.jsx)("img", {
                                  src: "/images/icons/7.png",
                                  alt: "",
                                }),
                                " BNB Chain",
                                Object(P.jsx)("span", {
                                  style: {
                                    position: "absolute",
                                    right: "0",
                                    background:
                                      "linear-gradient(99.46deg, #FA00FF -10.9%, #00E0FF 97.13%, #2AD4F9 97.14%)",
                                    borderRadius: "5px",
                                  },
                                  children: "Testnet",
                                }),
                              ],
                            }),
                            Object(P.jsxs)(ni, {
                              value: "Matic Mumbai test",
                              styles: { position: "relative" },
                              children: [
                                Object(P.jsx)("img", {
                                  src: "/images/icons/8.png",
                                  alt: "",
                                }),
                                " Matic Mumbai",
                                Object(P.jsx)("span", {
                                  style: {
                                    position: "absolute",
                                    right: "0",
                                    background:
                                      "linear-gradient(99.46deg, #FA00FF -10.9%, #00E0FF 97.13%, #2AD4F9 97.14%)",
                                    borderRadius: "5px",
                                  },
                                  children: "Testnet",
                                }),
                              ],
                            }),
                            Object(P.jsxs)(ni, {
                              value: "Aptos Chain test",
                              styles: { position: "relative" },
                              children: [
                                Object(P.jsx)("img", {
                                  src: "/images/icons/9.png",
                                  alt: "",
                                }),
                                " Aptos Chain",
                                Object(P.jsx)("span", {
                                  style: {
                                    position: "absolute",
                                    right: "0",
                                    background:
                                      "linear-gradient(99.46deg, #FA00FF -10.9%, #00E0FF 97.13%, #2AD4F9 97.14%)",
                                    borderRadius: "5px",
                                  },
                                  children: "Testnet",
                                }),
                              ],
                            }),
                          ],
                        }),
                      }),
                    ],
                  }),
                }),
              }),
              Object(P.jsxs)("div", {
                className: "content-launch-pad",
                children: [
                  0 === t
                    ? Object(P.jsx)(Ha, {
                        setView: a,
                        setDataDetail: l,
                        data: si,
                      })
                    : 1 === t
                    ? Object(P.jsx)(Ha, {
                        setView: a,
                        setDataDetail: l,
                        data: si.filter(function (e) {
                          return "On Going" === e.status;
                        }),
                      })
                    : 2 === t
                    ? Object(P.jsx)(Ha, {
                        setView: a,
                        setDataDetail: l,
                        data: si.filter(function (e) {
                          return "Upcoming" === e.status;
                        }),
                      })
                    : 3 === t
                    ? Object(P.jsx)(Ha, {
                        setView: a,
                        setDataDetail: l,
                        data: si.filter(function (e) {
                          return "Completed" === e.status;
                        }),
                      })
                    : "",
                  u
                    ? Object(P.jsx)("div", {
                        className: "content-pool-detail",
                        children: Object(P.jsxs)(Wn.a, {
                          gutter: [20, 20],
                          children: [
                            Object(P.jsx)(zn.a, {
                              span: 24,
                              order: 2,
                              lg: { span: 16, order: 1 },
                              children: Object(P.jsx)(ii, {
                                children: Object(P.jsxs)("div", {
                                  className: "content-left",
                                  children: [
                                    Object(P.jsx)("div", {
                                      className: "content-left-left",
                                      children: Object(P.jsx)("img", {
                                        src: u.logo,
                                        alt: "",
                                      }),
                                    }),
                                    Object(P.jsxs)("div", {
                                      className: "content-left-right",
                                      children: [
                                        Object(P.jsx)("p", {
                                          className: "name",
                                          children: u.name,
                                        }),
                                        Object(P.jsx)("div", {
                                          className: "social",
                                          children: Object(P.jsxs)("ul", {
                                            children: [
                                              Object(P.jsx)("li", {
                                                children: Object(P.jsx)("a", {
                                                  href: "",
                                                  children: Object(P.jsx)(
                                                    "img",
                                                    {
                                                      src: "/images/icons/web.png",
                                                      alt: "",
                                                    }
                                                  ),
                                                }),
                                              }),
                                              Object(P.jsx)("li", {
                                                children: Object(P.jsx)("a", {
                                                  href: "",
                                                  children: Object(P.jsx)(
                                                    "img",
                                                    {
                                                      src: "/images/icons/youtube.png",
                                                      alt: "",
                                                    }
                                                  ),
                                                }),
                                              }),
                                              Object(P.jsx)("li", {
                                                children: Object(P.jsx)("a", {
                                                  href: "",
                                                  children: Object(P.jsx)(
                                                    "img",
                                                    {
                                                      src: "/images/icons/twitter.png",
                                                      alt: "",
                                                    }
                                                  ),
                                                }),
                                              }),
                                              Object(P.jsx)("li", {
                                                children: Object(P.jsx)("a", {
                                                  href: "",
                                                  children: Object(P.jsx)(
                                                    "img",
                                                    {
                                                      src: "/images/icons/tele.png",
                                                      alt: "",
                                                    }
                                                  ),
                                                }),
                                              }),
                                            ],
                                          }),
                                        }),
                                        Object(P.jsx)("p", {
                                          className: "text-content",
                                          children: u.description,
                                        }),
                                        Object(P.jsxs)("div", {
                                          className: "box-information",
                                          children: [
                                            Object(P.jsxs)("div", {
                                              className:
                                                "information-item contact",
                                              children: [
                                                Object(P.jsx)("p", {
                                                  children: "Contract:",
                                                }),
                                                Object(P.jsxs)("div", {
                                                  className: "box-address",
                                                  children: [
                                                    Object(P.jsx)("input", {
                                                      value: u.contract,
                                                      readOnly: !0,
                                                    }),
                                                    Object(P.jsx)("img", {
                                                      src: "/images/icons/copy.png",
                                                      alt: "",
                                                    }),
                                                  ],
                                                }),
                                              ],
                                            }),
                                            Object(P.jsxs)("div", {
                                              className: "information-item",
                                              children: [
                                                Object(P.jsx)("p", {
                                                  children: "Swap Rate:",
                                                }),
                                                Object(P.jsx)("p", {
                                                  children: u.swapRate,
                                                }),
                                              ],
                                            }),
                                            Object(P.jsxs)("div", {
                                              className: "information-item",
                                              children: [
                                                Object(P.jsx)("p", {
                                                  children: "IDO Supply:",
                                                }),
                                                Object(P.jsx)("p", {
                                                  children: u.IDOSupply,
                                                }),
                                              ],
                                            }),
                                            Object(P.jsxs)("div", {
                                              className: "information-item",
                                              children: [
                                                Object(P.jsx)("p", {
                                                  children: "Start Pool:",
                                                }),
                                                Object(P.jsx)("p", {
                                                  children: u.startPool,
                                                }),
                                              ],
                                            }),
                                            Object(P.jsxs)("div", {
                                              className: "information-item",
                                              children: [
                                                Object(P.jsx)("p", {
                                                  children: "End Pool:",
                                                }),
                                                Object(P.jsx)("p", {
                                                  children: u.endPool,
                                                }),
                                              ],
                                            }),
                                          ],
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              }),
                            }),
                            Object(P.jsx)(zn.a, {
                              span: 24,
                              order: 1,
                              lg: { span: 8, order: 2 },
                              children: Object(P.jsx)(ii, {
                                children: Object(P.jsxs)("div", {
                                  className: "content-right",
                                  children: [
                                    Object(P.jsx)("p", {
                                      className: "title",
                                      children: "End In",
                                    }),
                                    Object(P.jsx)("div", {
                                      children: Object(P.jsx)(ei, {
                                        className: "countdown",
                                        remains: u ? 1e3 * +u.timeStart : 0,
                                      }),
                                    }),
                                    Object(P.jsxs)("div", {
                                      className: "process",
                                      children: [
                                        Object(P.jsxs)("div", {
                                          className: "process-top",
                                          children: [
                                            Object(P.jsx)("p", {
                                              children: "0%",
                                            }),
                                            Object(P.jsx)("p", {
                                              children: "--/--BNB",
                                            }),
                                          ],
                                        }),
                                        Object(P.jsx)("div", {
                                          className: "process-content",
                                          children: Object(P.jsx)(Ka.a, {
                                            defaultValue: 0,
                                            disabled: !0,
                                          }),
                                        }),
                                        Object(P.jsx)("p", {
                                          children:
                                            "You\u2019re not whitelisted",
                                        }),
                                        Object(P.jsxs)("div", {
                                          className: "box-input-amount",
                                          children: [
                                            Object(P.jsxs)("div", {
                                              className: "box-input-top",
                                              children: [
                                                Object(P.jsx)("p", {
                                                  children: "Amount",
                                                }),
                                                Object(P.jsx)("p", {
                                                  children: "Max",
                                                }),
                                              ],
                                            }),
                                            Object(P.jsx)("div", {
                                              className: "box-input-content",
                                              children: Object(P.jsx)("input", {
                                                type: "text",
                                                placeholder: "0",
                                              }),
                                            }),
                                          ],
                                        }),
                                        Object(P.jsx)("div", {
                                          style: { textAlign: "center" },
                                          children: Object(P.jsx)(Qn, {
                                            disabled: !0,
                                            children: "Buy",
                                          }),
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              }),
                            }),
                          ],
                        }),
                      })
                    : "",
                  4 === t && ri
                    ? Object(P.jsx)(P.Fragment, {
                        children: ri.map(function (e, n) {
                          return Object(P.jsx)(
                            "div",
                            {
                              className: "content-pool-detail",
                              children: Object(P.jsxs)(Wn.a, {
                                gutter: [20, 20],
                                children: [
                                  Object(P.jsx)(zn.a, {
                                    span: 24,
                                    order: 2,
                                    lg: { span: 16, order: 1 },
                                    children: Object(P.jsx)(ii, {
                                      children: Object(P.jsxs)("div", {
                                        className: "content-left",
                                        children: [
                                          Object(P.jsx)("div", {
                                            className: "content-left-left",
                                            children: Object(P.jsx)("img", {
                                              src: e.logo,
                                              alt: "",
                                            }),
                                          }),
                                          Object(P.jsxs)("div", {
                                            className: "content-left-right",
                                            children: [
                                              Object(P.jsx)("p", {
                                                className: "name",
                                                children: e.name,
                                              }),
                                              Object(P.jsx)("div", {
                                                className: "social",
                                                children: Object(P.jsxs)("ul", {
                                                  children: [
                                                    Object(P.jsx)("li", {
                                                      children: Object(P.jsx)(
                                                        "a",
                                                        {
                                                          href: "",
                                                          children: Object(
                                                            P.jsx
                                                          )("img", {
                                                            src: "/images/icons/web.png",
                                                            alt: "",
                                                          }),
                                                        }
                                                      ),
                                                    }),
                                                    Object(P.jsx)("li", {
                                                      children: Object(P.jsx)(
                                                        "a",
                                                        {
                                                          href: "",
                                                          children: Object(
                                                            P.jsx
                                                          )("img", {
                                                            src: "/images/icons/youtube.png",
                                                            alt: "",
                                                          }),
                                                        }
                                                      ),
                                                    }),
                                                    Object(P.jsx)("li", {
                                                      children: Object(P.jsx)(
                                                        "a",
                                                        {
                                                          href: "",
                                                          children: Object(
                                                            P.jsx
                                                          )("img", {
                                                            src: "/images/icons/twitter.png",
                                                            alt: "",
                                                          }),
                                                        }
                                                      ),
                                                    }),
                                                    Object(P.jsx)("li", {
                                                      children: Object(P.jsx)(
                                                        "a",
                                                        {
                                                          href: "",
                                                          children: Object(
                                                            P.jsx
                                                          )("img", {
                                                            src: "/images/icons/tele.png",
                                                            alt: "",
                                                          }),
                                                        }
                                                      ),
                                                    }),
                                                  ],
                                                }),
                                              }),
                                              Object(P.jsx)("p", {
                                                className: "text-content",
                                                children: e.description,
                                              }),
                                              Object(P.jsxs)("div", {
                                                className: "box-information",
                                                children: [
                                                  Object(P.jsxs)("div", {
                                                    className:
                                                      "information-item contact",
                                                    children: [
                                                      Object(P.jsx)("p", {
                                                        children: "Contract:",
                                                      }),
                                                      Object(P.jsxs)("div", {
                                                        className:
                                                          "box-address",
                                                        children: [
                                                          Object(P.jsx)(
                                                            "input",
                                                            {
                                                              value: e.contract,
                                                              readOnly: !0,
                                                            }
                                                          ),
                                                          Object(P.jsx)("img", {
                                                            src: "/images/icons/copy.png",
                                                            alt: "",
                                                          }),
                                                        ],
                                                      }),
                                                    ],
                                                  }),
                                                  Object(P.jsxs)("div", {
                                                    className:
                                                      "information-item",
                                                    children: [
                                                      Object(P.jsx)("p", {
                                                        children: "Swap Rate:",
                                                      }),
                                                      Object(P.jsx)("p", {
                                                        children: e.swapRate,
                                                      }),
                                                    ],
                                                  }),
                                                  Object(P.jsxs)("div", {
                                                    className:
                                                      "information-item",
                                                    children: [
                                                      Object(P.jsx)("p", {
                                                        children: "IDO Supply:",
                                                      }),
                                                      Object(P.jsx)("p", {
                                                        children: e.IDOSupply,
                                                      }),
                                                    ],
                                                  }),
                                                  Object(P.jsxs)("div", {
                                                    className:
                                                      "information-item",
                                                    children: [
                                                      Object(P.jsx)("p", {
                                                        children: "Start Pool:",
                                                      }),
                                                      Object(P.jsx)("p", {
                                                        children: e.startPool,
                                                      }),
                                                    ],
                                                  }),
                                                  Object(P.jsxs)("div", {
                                                    className:
                                                      "information-item",
                                                    children: [
                                                      Object(P.jsx)("p", {
                                                        children: "End Pool:",
                                                      }),
                                                      Object(P.jsx)("p", {
                                                        children: e.endPool,
                                                      }),
                                                    ],
                                                  }),
                                                ],
                                              }),
                                            ],
                                          }),
                                        ],
                                      }),
                                    }),
                                  }),
                                  Object(P.jsx)(zn.a, {
                                    span: 24,
                                    order: 1,
                                    lg: { span: 8, order: 2 },
                                    children: Object(P.jsx)(ii, {
                                      children: Object(P.jsxs)("div", {
                                        className: "content-right",
                                        children: [
                                          Object(P.jsx)("p", {
                                            className: "title",
                                            children: "Claim (1/5)",
                                          }),
                                          Object(P.jsx)("div", {
                                            className: "price-claim",
                                            children: "500 WOOF",
                                          }),
                                          Object(P.jsxs)("div", {
                                            className: "process",
                                            children: [
                                              Object(P.jsxs)("div", {
                                                className: "process-top",
                                                children: [
                                                  Object(P.jsx)("p", {
                                                    children: "0%",
                                                  }),
                                                  Object(P.jsx)("p", {
                                                    children: "--/--BNB",
                                                  }),
                                                ],
                                              }),
                                              Object(P.jsx)("div", {
                                                className: "process-content",
                                                children: Object(P.jsx)(Ka.a, {
                                                  defaultValue: 0,
                                                  disabled: !0,
                                                }),
                                              }),
                                              Object(P.jsx)("p", {
                                                children:
                                                  "You\u2019re not whitelisted",
                                              }),
                                              Object(P.jsxs)("div", {
                                                className: "box-info-claim",
                                                children: [
                                                  Object(P.jsxs)("div", {
                                                    children: [
                                                      Object(P.jsx)("p", {
                                                        children: "Investment:",
                                                      }),
                                                      Object(P.jsx)("p", {
                                                        children: "5BNB",
                                                      }),
                                                    ],
                                                  }),
                                                  Object(P.jsxs)("div", {
                                                    children: [
                                                      Object(P.jsx)("p", {
                                                        children: "Claimed",
                                                      }),
                                                      Object(P.jsx)("p", {
                                                        children: "500 WOOF",
                                                      }),
                                                    ],
                                                  }),
                                                  Object(P.jsxs)("div", {
                                                    children: [
                                                      Object(P.jsx)("p", {
                                                        children:
                                                          "Your Allowcation",
                                                      }),
                                                      Object(P.jsx)("p", {
                                                        children:
                                                          "500,000,000 WOOF",
                                                      }),
                                                    ],
                                                  }),
                                                  Object(P.jsxs)("div", {
                                                    children: [
                                                      Object(P.jsx)("p", {
                                                        children: "Vesting:",
                                                      }),
                                                      Object(P.jsx)("p", {
                                                        children:
                                                          "25% at TGE, then monthly linear vesting over 4 months",
                                                      }),
                                                    ],
                                                  }),
                                                ],
                                              }),
                                              Object(P.jsx)("div", {
                                                style: { textAlign: "center" },
                                                children: Object(P.jsx)(Qn, {
                                                  children: "Claim",
                                                }),
                                              }),
                                            ],
                                          }),
                                        ],
                                      }),
                                    }),
                                  }),
                                ],
                              }),
                            },
                            n
                          );
                        }),
                      })
                    : "",
                ],
              }),
              Object(P.jsx)("div", {
                className: "wrapper-footer",
                style: { marginTop: "60px" },
                children: Object(P.jsx)("p", {
                  children: "Kraken Launchpad V1.0.4",
                }),
              }),
            ],
          });
        },
        pi = ["component"],
        ui = function () {
          var e = De.a.get(B.d);
          return Boolean(e);
        },
        li = function (e) {
          var n = e.component,
            t = Object(ke.a)(e, pi);
          return Object(P.jsx)(
            Ne.b,
            Object(h.a)(
              Object(h.a)({}, t),
              {},
              {
                render: function (e) {
                  return ui()
                    ? Object(P.jsx)(Ne.a, {
                        to: { pathname: "/", state: { from: e.location } },
                      })
                    : Object(P.jsx)(
                        Ba,
                        Object(h.a)(
                          Object(h.a)({}, t),
                          {},
                          { children: Object(P.jsx)(n, Object(h.a)({}, e)) }
                        )
                      );
                },
              }
            )
          );
        };
      var ci = function () {
          return (
            en(),
            (function () {
              var e = Object(T.b)(),
                n = Object(s.useCallback)(
                  Object(x.a)(
                    O.a.mark(function n() {
                      return O.a.wrap(function (n) {
                        for (;;)
                          switch ((n.prev = n.next)) {
                            case 0:
                              return (
                                (n.next = 2),
                                La.getRepoTreeAtOrgan()
                                  .then(
                                    Object(x.a)(
                                      O.a.mark(function n() {
                                        return O.a.wrap(function (n) {
                                          for (;;)
                                            switch ((n.prev = n.next)) {
                                              case 0:
                                                Promise.all([
                                                  La.getFileData(
                                                    "airdropToken/config.json"
                                                  ),
                                                  La.getFileData(
                                                    "airdropToken/whiteList1.json"
                                                  ),
                                                ])
                                                  .then(function (n) {
                                                    var t = Object(j.a)(n, 2),
                                                      a = {
                                                        airdropToken: t[0],
                                                        whiteListAirdropToken:
                                                          t[1],
                                                      };
                                                    window.localStorage.setItem(
                                                      "u:g:c",
                                                      JSON.stringify(a)
                                                    ),
                                                      e(K(a));
                                                  })
                                                  .catch(console.error);
                                              case 1:
                                              case "end":
                                                return n.stop();
                                            }
                                        }, n);
                                      })
                                    )
                                  )
                                  .catch(console.error)
                              );
                            case 2:
                            case "end":
                              return n.stop();
                          }
                      }, n);
                    })
                  ),
                  [e]
                );
              Object(s.useEffect)(
                function () {
                  n();
                },
                [n]
              );
            })(),
            Object(P.jsx)(s.Suspense, {
              fallback: null,
              children: Object(P.jsxs)(Be.a, {
                children: [
                  Object(P.jsx)(Se.a, {}),
                  Object(P.jsx)(Fn, {
                    children: Object(P.jsxs)(Ne.d, {
                      children: [
                        Object(P.jsx)(li, {
                          exact: !0,
                          path: "/",
                          component: oi,
                        }),
                        Object(P.jsx)(Ne.b, {
                          path: "*",
                          component: function () {
                            return Object(P.jsx)(Ne.a, { to: "/" });
                          },
                        }),
                      ],
                    }),
                  }),
                  Object(P.jsx)(Oa, {}),
                ],
              }),
            })
          );
        },
        di = function (e) {
          e &&
            e instanceof Function &&
            t
              .e(6)
              .then(t.bind(null, 1087))
              .then(function (n) {
                var t = n.getCLS,
                  a = n.getFID,
                  i = n.getFCP,
                  s = n.getLCP,
                  r = n.getTTFB;
                t(e), a(e), i(e), s(e), r(e);
              });
        };
      t(803), t(804);
      "ethereum" in window && (window.ethereum.autoRefreshOnNetworkChange = !1),
        u.a.addDefaultLocale(l),
        u.a.addLocale(c),
        window.addEventListener("error", function () {
          var e;
          null === (e = localStorage) ||
            void 0 === e ||
            e.removeItem("redux_localstorage_simple_lists");
        }),
        p.a.render(
          Object(P.jsx)(r.a.StrictMode, {
            children: Object(P.jsxs)(Ie, {
              children: [
                Object(P.jsx)(m, {}),
                Object(P.jsx)(b, {}),
                Object(P.jsx)(ci, {}),
              ],
            }),
          }),
          document.getElementById("root")
        ),
        di();
    },
  },
  [[805, 1, 2]],
]);
